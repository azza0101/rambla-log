/* RAMBLA Log — one voice note, converted to text without storing audio.
 * Construction is passive. The caller releases any other microphone before
 * start(), and chooses explicitly between native and local recognition.
 */
(function (global, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory(global);
  else global.RamblaVoiceNote = factory(global);
}(typeof window !== 'undefined' ? window : globalThis, function (global) {
  'use strict';

  const noop = function () {};
  const clean = value => String(value || '').replace(/\s+/g, ' ').trim();
  const now = () => global.performance?.now ? global.performance.now() : Date.now();

  function abortError() {
    const error = new Error('Avvio della nota vocale annullato.');
    error.name = 'AbortError';
    return error;
  }

  function nativeError(code) {
    const messages = {
      'not-allowed': 'Accesso al microfono negato. Consenti il microfono nelle impostazioni del sito e riprova.',
      'service-not-allowed': 'La trascrizione vocale del browser non è consentita su questo dispositivo.',
      'audio-capture': 'Il microfono non è disponibile. Chiudi altre registrazioni e riprova.',
      network: 'La trascrizione del browser non raggiunge il servizio. Controlla la connessione e riprova.',
      'no-speech': 'Non ho rilevato voce. Riprova parlando vicino al microfono.',
      'language-not-supported': 'La lingua scelta non è supportata dalla trascrizione del browser.',
      aborted: 'La trascrizione della nota vocale è stata interrotta.',
    };
    const error = new Error(messages[code] || 'La trascrizione della nota vocale si è interrotta. Riprova.');
    error.code = code || 'recognition-error';
    return error;
  }

  class RamblaVoiceNote {
    constructor({ onText, onStatus, onError } = {}) {
      this.onText = typeof onText === 'function' ? onText : noop;
      this.onStatus = typeof onStatus === 'function' ? onStatus : noop;
      this.onError = typeof onError === 'function' ? onError : noop;
      this.state = 'stopped';
      this.text = '';
      this.interim = '';
      this._generation = 0;
      this._finished = true;
      this._destroyed = false;
      this._native = null;
      this._local = null;
      this._startTicket = null;
      this._stopTicket = null;
    }

    _call(callback, value) {
      try { callback(value); }
      catch (error) { global.console?.error('RAMBLA voice note callback', error); }
    }

    _status(state, message) {
      if (this._destroyed) return;
      this.state = state;
      this._call(this.onStatus, { state, message });
    }

    _publish() {
      if (this._destroyed || (this.text === this._publishedText && this.interim === this._publishedInterim)) return;
      this._publishedText = this.text;
      this._publishedInterim = this.interim;
      this._call(this.onText, { text: this.text, interim: this.interim });
    }

    _alive(run) { return !this._destroyed && !this._finished && this._generation === run; }

    _settleStart(error) {
      const ticket = this._startTicket;
      this._startTicket = null;
      this._startPromise = null;
      if (error) ticket?.reject(error);
      else ticket?.resolve(this);
    }

    _settleStop() {
      const ticket = this._stopTicket;
      this._stopTicket = null;
      ticket?.resolve({ text: this.text, interim: '' });
    }

    _report(cause) {
      if (this._error || this._destroyed) return this._error;
      const error = cause instanceof Error ? cause : new Error(cause?.message || String(cause));
      this._error = error;
      this._status('error', error.message);
      this._call(this.onError, error);
      return error;
    }

    _releaseNative() {
      const recognition = this._native;
      this._native = null;
      if (!recognition) return;
      recognition.onresult = recognition.onerror = recognition.onend = null;
      // Retain the guarded onstart: permission may be granted after abort().
      // That late start must abort itself before it can own a microphone.
      try { recognition.abort(); } catch (_) {}
    }

    _finish(run) {
      if (!this._alive(run)) return;
      this._finished = true;
      this._stopping = false;
      clearTimeout(this._stopTimer);
      this._releaseNative();
      this.interim = '';
      this._settleStart(this._error || abortError());
      this._settleStop();
      this._publish();
      this._status(this._error ? 'error' : 'stopped', this._error?.message || 'Nota vocale fermata. Testo confermato pronto.');
    }

    async _failStart(run, cause) {
      if (!this._alive(run)) return;
      const error = this._report(cause);
      const local = this._local;
      this._local = null;
      if (local) { try { await local.destroy(); } catch (_) {} }
      if (!this._alive(run)) return;
      this._settleStart(error);
      this._finish(run);
    }

    start({ mode = 'native', language = 'it-IT' } = {}) {
      if (this._destroyed) return Promise.reject(new Error('La nota vocale è stata chiusa.'));
      if (this._stopping) return Promise.reject(new Error('Attendi il completamento della nota vocale.'));
      if (this._startPromise) return this._startPromise;
      if (!this._finished) return Promise.resolve(this);
      const run = ++this._generation;
      this._finished = false;
      this._stopping = false;
      this._flushRequested = true;
      this._error = null;
      this._stopPromise = null;
      this._finals = new Map();
      this.text = '';
      this.interim = '';
      this._startedAt = now();
      const starting = new Promise((resolve, reject) => { this._startTicket = { resolve, reject }; });
      this._startPromise = starting;
      this._publish();
      this._status('loading', 'Preparo il microfono per la nota vocale.');
      try {
        if (mode === 'native') this._startNative(run, language);
        else if (mode === 'local') this._startLocal(run, language);
        else throw new Error('Modalità della nota vocale non valida.');
      } catch (error) { this._failStart(run, error); }
      return starting;
    }

    _startNative(run, language) {
      const Recognition = global.SpeechRecognition || global.webkitSpeechRecognition;
      if (!Recognition) throw new Error('La trascrizione vocale non è disponibile in questo browser. Puoi scrivere la nota oppure scegliere il motore locale.');
      const recognition = new Recognition();
      this._native = recognition;
      recognition.lang = String(language || 'it-IT');
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      recognition.onstart = () => {
        if (!this._alive(run) || this._native !== recognition || this._stopping) {
          try { recognition.abort(); } catch (_) {}
          if (this._alive(run) && this._stopping) this._finish(run);
          return;
        }
        this._status('listening', 'Detta la nota. Tocca Ferma per completare la trascrizione.');
        this._settleStart();
      };
      recognition.onresult = event => {
        if (!this._alive(run) || this._native !== recognition || (this._stopping && !this._flushRequested)) return;
        const interim = [];
        for (let index = 0; index < (event.results?.length || 0); index += 1) {
          const result = event.results[index];
          const text = clean(result?.[0]?.transcript);
          if (result?.isFinal) {
            if (!this._finals.has(index)) this._finals.set(index, text);
          } else if (text) interim.push(text);
        }
        this.text = Array.from(this._finals.entries()).sort((a, b) => a[0] - b[0]).map(entry => entry[1]).filter(Boolean).join(' ');
        this.interim = interim.join(' ');
        this._publish();
      };
      recognition.onerror = event => {
        if (!this._alive(run) || this._native !== recognition) return;
        if (event.error === 'aborted' && this._stopping) { this._finish(run); return; }
        this._failStart(run, nativeError(event.error));
      };
      recognition.onend = () => { if (this._native === recognition) this._finish(run); };
      recognition.start();
    }

    _startLocal(run, language) {
      if (typeof global.RamblaLocalASR !== 'function') throw new Error('Il motore locale non è disponibile in questa pagina. Puoi scrivere la nota oppure usare la trascrizione del browser.');
      let local;
      const active = () => this._alive(run) && this._local === local;
      local = new global.RamblaLocalASR({
        onSegment: segment => {
          if (!active() || (this._stopping && !this._flushRequested)) return;
          const text = clean(segment?.text);
          if (!text) return;
          this.text = this.text ? this.text + ' ' + text : text;
          this._publish();
        },
        onStatus: status => {
          if (!active()) return;
          if (status.state === 'stopped') {
            if (!this._stopping) this.stop({ flush: true });
          } else if (['loading', 'listening', 'processing', 'error'].includes(status.state) &&
              (!this._error || status.state === 'error') && !(this._stopping && status.state === 'listening')) {
            this._status(status.state, status.message);
          }
        },
        onError: cause => {
          if (!active()) return;
          const error = this._report(cause);
          this._settleStart(error);
          this.stop({ flush: true });
        },
      });
      this._local = local;
      Promise.resolve(local.start({ language, getElapsed: () => Math.max(0, (now() - this._startedAt) / 1000) })).then(() => {
        if (!active() || this._stopping) {
          Promise.resolve(local.destroy()).catch(noop);
          return;
        }
        if (this.state !== 'listening') this._status('listening', 'Ascolto locale della nota vocale attivo.');
        this._settleStart();
      }, error => {
        if (active() && !this._stopping) this._failStart(run, error);
      });
    }

    stop({ flush = true } = {}) {
      if (this._stopPromise) return this._stopPromise;
      if (this._destroyed || this._finished) return Promise.resolve({ text: this.text, interim: '' });
      const run = this._generation;
      this._stopping = true;
      this._flushRequested = flush;
      this._settleStart(this._error || abortError());
      const stopping = new Promise(resolve => { this._stopTicket = { resolve }; });
      this._stopPromise = stopping;
      if (!this._error) this._status('processing', 'Completo le ultime parole della nota vocale.');
      if (this._native) {
        if (!flush) this._finish(run);
        else {
          this._stopTimer = setTimeout(() => this._finish(run), 2500);
          try { this._native.stop(); } catch (_) { this._finish(run); }
        }
      } else if (this._local) {
        const local = this._local;
        (async () => {
          try { await local.stop({ flush }); }
          catch (error) { if (this._alive(run)) this._report(error); }
          if (this._local === local) this._local = null;
          try { await local.destroy(); }
          catch (error) { if (this._alive(run)) this._report(error); }
          this._finish(run);
        })();
      } else this._finish(run);
      return stopping;
    }

    destroy() {
      if (this._destroyPromise) return this._destroyPromise;
      this._destroyed = true;
      this._finished = true;
      this._stopping = false;
      ++this._generation;
      clearTimeout(this._stopTimer);
      this._settleStart(abortError());
      this._releaseNative();
      this.interim = '';
      this._settleStop();
      const local = this._local;
      this._local = null;
      this._destroyPromise = (async () => {
        if (local) { try { await local.destroy(); } catch (_) {} }
      })();
      return this._destroyPromise;
    }
  }

  return RamblaVoiceNote;
}));
