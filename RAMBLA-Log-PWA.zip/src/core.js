/* RAMBLA Log: deterministic timecode, validation and text exports.
 * EDL marker syntax follows Blackmagic Design's example:
 * https://forum.blackmagicdesign.com/viewtopic.php?f=21&t=134578
 * These functions validate file structure; they do not certify a Resolve import.
 */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.RamblaCore = factory();
}(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  const rates = Object.freeze([
    { id: '23.976', label: '23.976 fps · NDF', rate: 24000 / 1001, nominal: 24, drop: false },
    { id: '24', label: '24 fps', rate: 24, nominal: 24, drop: false },
    { id: '25', label: '25 fps', rate: 25, nominal: 25, drop: false },
    { id: '29.97', label: '29.97 fps · NDF', rate: 30000 / 1001, nominal: 30, drop: false },
    { id: '29.97df', label: '29.97 fps · DF', rate: 30000 / 1001, nominal: 30, drop: true },
    { id: '30', label: '30 fps', rate: 30, nominal: 30, drop: false },
    { id: '50', label: '50 fps', rate: 50, nominal: 50, drop: false },
    { id: '59.94', label: '59.94 fps · NDF', rate: 60000 / 1001, nominal: 60, drop: false },
    { id: '59.94df', label: '59.94 fps · DF', rate: 60000 / 1001, nominal: 60, drop: true },
    { id: '60', label: '60 fps', rate: 60, nominal: 60, drop: false },
  ].map(Object.freeze));
  const colors = Object.freeze(['Blue', 'Cyan', 'Green', 'Yellow', 'Red', 'Pink', 'Purple', 'Fuchsia', 'Rose', 'Lavender', 'Sky', 'Mint', 'Lemon', 'Sand', 'Cocoa', 'Cream']);
  const pad2 = value => String(value).padStart(2, '0');

  function rateInfo(id) {
    const found = rates.find(item => item.id === String(id));
    if (!found) throw new Error('Frame rate / fps non supportato: ' + String(id));
    return found;
  }

  function finite(value, label, nonnegative) {
    if (typeof value !== 'number' || !Number.isFinite(value) || (nonnegative && value < 0)) {
      throw new Error(label + ': è necessario un numero finito' + (nonnegative ? ' non negativo.' : '.'));
    }
    return value;
  }

  function integer(value, label) {
    if (!Number.isSafeInteger(value)) throw new Error(label + ': è necessario un numero intero di fotogrammi.');
    return value;
  }

  function dayFrames(info) {
    return info.nominal * 86400 - (info.drop ? (info.nominal / 15) * (1440 - 144) : 0);
  }

  function parseTC(text, rateId) {
    const info = rateInfo(rateId);
    const match = typeof text === 'string' && /^(\d{2}):(\d{2}):(\d{2})([:;])(\d{2})$/.exec(text.trim());
    if (!match) throw new Error('Timecode non valido: usa HH:MM:SS:FF (oppure ;FF per drop-frame).');
    const h = Number(match[1]), m = Number(match[2]), s = Number(match[3]), f = Number(match[5]);
    if (h > 23 || m > 59 || s > 59 || f >= info.nominal || (!info.drop && match[4] === ';')) {
      throw new Error('Timecode non valido per ' + info.label + '.');
    }
    const drops = info.drop ? info.nominal / 15 : 0;
    if (drops && m % 10 !== 0 && s === 0 && f < drops) {
      throw new Error('Timecode drop-frame impossibile: questi numeri di fotogramma vengono saltati.');
    }
    const minutes = h * 60 + m;
    return ((h * 3600 + m * 60 + s) * info.nominal + f) - drops * (minutes - Math.floor(minutes / 10));
  }

  // Camera timecodes roll over at midnight, including a negative inferred origin.
  // Exporters that cannot represent that rollover must check their own bounds.
  function formatTC(frames, rateId) {
    const info = rateInfo(rateId);
    integer(frames, 'Timecode');
    const limit = dayFrames(info);
    let count = ((frames % limit) + limit) % limit;
    if (info.drop) {
      const drops = info.nominal / 15;
      const perMinute = info.nominal * 60 - drops;
      const perTenMinutes = info.nominal * 600 - drops * 9;
      const blocks = Math.floor(count / perTenMinutes);
      const remainder = count % perTenMinutes;
      count += drops * 9 * blocks;
      if (remainder >= drops) count += drops * Math.floor((remainder - drops) / perMinute);
    }
    const f = count % info.nominal;
    const seconds = Math.floor(count / info.nominal);
    return pad2(Math.floor(seconds / 3600)) + ':' + pad2(Math.floor(seconds / 60) % 60) + ':' + pad2(seconds % 60) + (info.drop ? ';' : ':') + pad2(f);
  }

  function secondsToFrames(seconds, rateId) {
    finite(seconds, 'Secondi', false);
    const frames = Math.round(seconds * rateInfo(rateId).rate);
    integer(frames, 'Durata');
    return frames === 0 ? 0 : frames;
  }

  function framesToSeconds(frames, rateId) {
    integer(frames, 'Fotogrammi');
    const info = rateInfo(rateId);
    return info.rate === info.nominal ? frames / info.nominal : frames * 1001 / (info.nominal * 1000);
  }

  function srtTime(seconds) {
    finite(seconds, 'Tempo SRT', true);
    const millis = Math.round(seconds * 1000);
    if (!Number.isSafeInteger(millis)) throw new Error('Tempo SRT troppo grande.');
    const wholeSeconds = Math.floor(millis / 1000);
    return pad2(Math.floor(wholeSeconds / 3600)) + ':' + pad2(Math.floor(wholeSeconds / 60) % 60) + ':' + pad2(wholeSeconds % 60) + ',' + String(millis % 1000).padStart(3, '0');
  }

  function cleanText(value, label, fallback, required) {
    if (value === undefined || value === null) value = fallback;
    if (typeof value !== 'string') throw new Error(label + ': testo non valido.');
    const result = value.replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim();
    if (required && !result) throw new Error(label + ': il testo è obbligatorio.');
    return result;
  }

  function parseSRT(text) {
    if (typeof text !== 'string') throw new Error('SRT non valido: serve un file di testo.');
    const input = text.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n').trim();
    if (!input) throw new Error('SRT vuoto: non contiene sottotitoli.');
    const timePattern = '(\\d{2,}):([0-5]\\d):([0-5]\\d)[,.](\\d{3})';
    const timing = new RegExp('^' + timePattern + '\\s+-->\\s+' + timePattern + '$');
    return input.split(/\n[\t ]*\n+/).map((block, index) => {
      const lines = block.split('\n');
      const match = lines.length >= 3 && /^\d+$/.test(lines[0].trim()) && timing.exec(lines[1].trim());
      if (!match) throw new Error('SRT non valido al sottotitolo ' + (index + 1) + ': controlla numero e intervallo.');
      const value = offset => Number(match[offset]) * 3600 + Number(match[offset + 1]) * 60 + Number(match[offset + 2]) + Number(match[offset + 3]) / 1000;
      const start = value(1), end = value(5);
      if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) throw new Error('SRT: intervallo non valido al sottotitolo ' + (index + 1) + '.');
      const content = cleanText(lines.slice(2).join('\n'), 'SRT', '', true);
      return { id: 'srt-' + (index + 1), start, end, text: content, speaker: '' };
    });
  }

  function record(value, label) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(label + ': oggetto non valido.');
    return value;
  }

  function timestamp(value, label, nullable) {
    if (nullable && (value === null || value === undefined)) return null;
    if (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 && !Number.isNaN(new Date(value).getTime())) return value;
    if (!nullable && typeof value === 'string' && value.trim() && Number.isFinite(Date.parse(value))) return value;
    throw new Error(label + ': data non valida.');
  }

  function colorName(value) {
    const name = cleanText(value, 'Colore marker', 'Blue', true).replace(/^ResolveColor/i, '');
    const color = colors.find(item => item.toLowerCase() === name.toLowerCase());
    if (!color) throw new Error('Colore marker non supportato: ' + name);
    return color;
  }

  function validateSession(obj) {
    if (typeof obj === 'string') {
      try { obj = JSON.parse(obj); } catch (_) { throw new Error('JSON non valido: impossibile leggere la sessione.'); }
    }
    record(obj, 'Sessione');
    const id = cleanText(obj.id, 'ID sessione', '', true);
    const title = cleanText(obj.title, 'Titolo', '', true);
    const info = rateInfo(obj.fps === undefined ? '25' : obj.fps);
    const startTC = formatTC(parseTC(obj.startTC === undefined ? '01:00:00:00' : obj.startTC, info.id), info.id);
    const createdAt = timestamp(obj.createdAt, 'Creazione', false);
    const startedAt = timestamp(obj.startedAt, 'Inizio', true);
    const endedAt = timestamp(obj.endedAt, 'Fine', true);
    if (startedAt !== null && endedAt !== null && endedAt < startedAt) throw new Error('La fine della sessione precede il suo inizio.');
    // These fields are additive: old backups keep their original TC reference.
    const clockSource = obj.clockSource === undefined ? 'timecode' : obj.clockSource;
    if (!['phone', 'timecode'].includes(clockSource)) throw new Error('Riferimento orario non valido.');
    const phoneAnchorMs = timestamp(obj.phoneAnchorMs === undefined && clockSource === 'phone' ? startedAt : obj.phoneAnchorMs, 'Origine ora telefono', true);
    if (clockSource === 'phone' && startedAt !== null && phoneAnchorMs === null) throw new Error('Manca l’origine dell’ora del telefono.');
    const captureState = obj.captureState === undefined ? (endedAt !== null ? 'ended' : startedAt !== null ? 'active' : 'draft') : obj.captureState;
    if (!['draft', 'active', 'paused', 'ended'].includes(captureState)) throw new Error('Stato della sessione non valido.');
    if ((captureState === 'draft' && (startedAt !== null || endedAt !== null)) ||
        (['active', 'paused'].includes(captureState) && (startedAt === null || endedAt !== null)) ||
        (captureState === 'ended' && endedAt === null)) throw new Error('Lo stato della sessione non corrisponde ai suoi tempi.');
    const pausedAt = timestamp(obj.pausedAt, 'Pausa', true);
    const pauseReason = obj.pauseReason === undefined ? null : obj.pauseReason;
    if (captureState === 'paused') {
      if (!['manual', 'background', 'recovery'].includes(pauseReason) || pausedAt === null || pausedAt < startedAt) throw new Error('Metadati della pausa non validi.');
    } else if (pauseReason !== null || pausedAt !== null) throw new Error('Una sessione non in pausa contiene metadati di pausa.');
    let duration = finite(obj.duration, 'Durata sessione', true);
    if (!Array.isArray(obj.segments) || !Array.isArray(obj.markers)) throw new Error('Sessione non valida: segments e markers devono essere elenchi.');
    const segmentIds = new Set();
    const segments = obj.segments.map((raw, index) => {
      record(raw, 'Segmento ' + (index + 1));
      const segmentId = cleanText(raw.id, 'ID segmento', '', true);
      if (segmentIds.has(segmentId)) throw new Error('ID segmento duplicato: ' + segmentId);
      segmentIds.add(segmentId);
      const start = finite(raw.start, 'Inizio segmento', true);
      const end = finite(raw.end, 'Fine segmento', true);
      if (end <= start) throw new Error('Intervallo segmento non valido: la fine deve seguire l’inizio.');
      duration = Math.max(duration, end);
      return { id: segmentId, start, end, text: cleanText(raw.text, 'Testo segmento', '', true), speaker: cleanText(raw.speaker, 'Speaker', '', false) };
    });
    const markerIds = new Set();
    const markers = obj.markers.map((raw, index) => {
      record(raw, 'Marker ' + (index + 1));
      const markerId = cleanText(raw.id, 'ID marker', '', true);
      if (markerIds.has(markerId)) throw new Error('ID marker duplicato: ' + markerId);
      markerIds.add(markerId);
      const start = finite(raw.start, 'Inizio marker', true);
      const end = finite(raw.end === undefined ? start : raw.end, 'Fine marker', true);
      if (end < start) throw new Error('Intervallo marker non valido: la fine precede l’inizio.');
      const links = raw.segmentIds === undefined ? [] : raw.segmentIds;
      if (!Array.isArray(links)) throw new Error('segmentIds del marker deve essere un elenco.');
      duration = Math.max(duration, end);
      return {
        id: markerId, start, end,
        name: cleanText(raw.name, 'Nome marker', 'Marker', true),
        note: cleanText(raw.note, 'Nota marker', '', false), color: colorName(raw.color),
        category: cleanText(raw.category, 'Categoria', '', false),
        ...(raw.autoNote === true ? { autoNote: true } : {}),
        segmentIds: Array.from(new Set(links.map(link => cleanText(link, 'ID segmento collegato', '', true)))),
      };
    });
    const speaker = cleanText(obj.speaker, 'Speaker corrente', 'Speaker A', false);
    const rawSpeakers = obj.speakers === undefined ? ['Speaker A', 'Speaker B'] : obj.speakers;
    if (!Array.isArray(rawSpeakers)) throw new Error('Speakers deve essere un elenco.');
    const speakers = Array.from(new Set(rawSpeakers.map(item => cleanText(item, 'Speaker', '', true)).concat([speaker], segments.map(item => item.speaker)).filter(Boolean)));
    const result = {
      id, title, createdAt, startedAt, endedAt, duration, fps: info.id, startTC,
      clockSource, phoneAnchorMs, captureState, pauseReason, pausedAt,
      language: cleanText(obj.language, 'Lingua', 'it-IT', true),
      lookback: finite(obj.lookback === undefined ? 10 : obj.lookback, 'Lookback', true),
      speaker, speakers, segments, markers, isDemo: obj.isDemo === true,
    };
    if (obj.sync !== undefined && obj.sync !== null) {
      const sync = record(obj.sync, 'Sincronizzazione');
      if (sync.method !== 'camera') throw new Error('Metodo di sincronizzazione non valido.');
      const at = cleanText(sync.at, 'Data sincronizzazione', '', true);
      if (!Number.isFinite(Date.parse(at))) throw new Error('Data sincronizzazione non valida.');
      const readings = integer(sync.readings, 'Letture timecode');
      const confidence = finite(sync.confidence, 'Confidenza OCR', true);
      if (readings < 1 || confidence > 100) throw new Error('Metadati della sincronizzazione non validi.');
      result.sync = { method: 'camera', timecode: formatTC(parseTC(sync.timecode, info.id), info.id), at, readings, confidence };
    }
    return result;
  }

  function edlText(value) {
    return value.replace(/\|/g, '¦').replace(/\s+/g, ' ').trim();
  }

  function byStart(items) {
    return items.map((item, index) => ({ item, index })).sort((a, b) => a.item.start - b.item.start || a.index - b.index).map(entry => entry.item);
  }

  function makeEDL(session, options) {
    const s = validateSession(session);
    const opts = options || {};
    const info = rateInfo(s.fps);
    const origin = parseTC(opts.timelineTC === undefined ? s.startTC : opts.timelineTC, s.fps);
    const offset = finite(opts.offsetSeconds === undefined ? 0 : opts.offsetSeconds, 'Offset', false);
    const limit = dayFrames(info);
    const positions = new Map();
    let collisions = 0;
    const prepared = byStart(s.markers).map(marker => {
      const shiftedStart = marker.start + offset;
      const shiftedEnd = marker.end + offset;
      if (shiftedStart < 0 || shiftedEnd < 0) throw new Error('Il marker «' + marker.name + '» cade prima dello zero dopo l’offset (tempo negativo).');
      const start = origin + secondsToFrames(shiftedStart, s.fps);
      const end = origin + secondsToFrames(shiftedEnd, s.fps);
      const duration = Math.max(1, end - start);
      if (start < 0 || start + duration >= limit || start + 1 >= limit) throw new Error('Il marker «' + marker.name + '» raggiunge il limite di 24 ore. Dividi la sessione o modifica il timecode iniziale.');
      if (positions.has(start)) collisions += 1;
      positions.set(start, true);
      return { marker, start, duration };
    });
    let result = 'TITLE: ' + edlText(s.title) + '\nFCM: ' + (info.drop ? 'DROP FRAME' : 'NON-DROP FRAME') + '\n';
    if (collisions) result += '* RAMBLA WARNING: ' + collisions + ' marker coincidenti nello stesso fotogramma; tutti preservati nel file. Verificare l’importazione in Resolve.\n';
    result += '\n';
    prepared.forEach((entry, index) => {
      // Both source and record columns follow the identical timeline position
      // used by Blackmagic's published marker example; out is exclusive +1 frame.
      const start = formatTC(entry.start, s.fps).replace(';', ':');
      const out = formatTC(entry.start + 1, s.fps).replace(';', ':');
      result += String(index + 1).padStart(3, '0') + '  001      V     C        ' + start + ' ' + out + ' ' + start + ' ' + out + '\n';
      const marker = entry.marker;
      if (marker.category || marker.note) {
        result += (marker.category ? '[' + edlText(marker.category) + '] ' : 'Nota: ') + edlText(marker.note) + '\n';
      }
      result += ' |C:ResolveColor' + marker.color + ' |M:' + edlText(marker.name) + ' |D:' + entry.duration + '\n\n';
    });
    return result;
  }

  function makeSRT(session, options) {
    const s = validateSession(session);
    const selected = new Set(s.markers.flatMap(marker => marker.segmentIds));
    const segments = byStart(s.segments).filter(item => !(options && options.selectedOnly) || selected.has(item.id));
    return segments.map((item, index) => {
      const start = srtTime(item.start), end = srtTime(item.end);
      if (start === end) throw new Error('Il segmento «' + item.id + '» è troppo breve per la precisione al millisecondo di SRT.');
      return String(index + 1) + '\n' + start + ' --> ' + end + '\n' + item.text.replace(/\n[\t ]*\n+/g, '\n');
    }).join('\n\n') + (segments.length ? '\n' : '');
  }

  function csvCell(value) {
    let text = String(value);
    // Quoting alone does not stop a spreadsheet from treating text as a formula.
    if (/^[\s]*[=+@-]/.test(text)) text = "'" + text;
    return '"' + text.replace(/"/g, '""') + '"';
  }

  function makeCSV(session) {
    const s = validateSession(session);
    const headers = ['type', 'id', 'start_seconds', 'end_seconds', 'start_time', 'end_time', 'speaker', 'name', 'text', 'color', 'category', 'segment_ids'];
    const rows = [headers];
    const segmentMap = new Map(s.segments.map(item => [item.id, item]));
    byStart(s.markers).forEach(item => {
      const speakers = Array.from(new Set(item.segmentIds.map(id => segmentMap.get(id)).filter(Boolean).map(segment => segment.speaker).filter(Boolean))).join('; ');
      rows.push(['marker', item.id, item.start, item.end, srtTime(item.start), srtTime(item.end), speakers, item.name, item.note, item.color, item.category, item.segmentIds.join('; ')]);
    });
    byStart(s.segments).forEach(item => rows.push(['segment', item.id, item.start, item.end, srtTime(item.start), srtTime(item.end), item.speaker, '', item.text, '', '', '']));
    return '\uFEFF' + rows.map(row => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
  }

  function makeTXT(session) {
    const s = validateSession(session);
    const time = seconds => srtTime(seconds).replace(',', '.');
    const lines = ['RAMBLA LOG', s.title, 'Creato: ' + s.createdAt, 'Frame rate: ' + rateInfo(s.fps).label, 'Timecode iniziale: ' + s.startTC, 'Durata: ' + time(s.duration), 'Tempi seguenti: relativi all’inizio della sessione.', '', 'MARKER'];
    if (!s.markers.length) lines.push('Nessun marker.');
    byStart(s.markers).forEach(item => {
      lines.push('[' + time(item.start) + ' — ' + time(item.end) + '] ' + item.name);
      if (item.category) lines.push('Categoria: ' + item.category + ' · Colore: ' + item.color);
      if (item.note) lines.push(item.note);
      lines.push('');
    });
    lines.push('', 'TRASCRIZIONE');
    if (!s.segments.length) lines.push('Nessun segmento.');
    byStart(s.segments).forEach(item => {
      lines.push('[' + time(item.start) + ' — ' + time(item.end) + ']' + (item.speaker ? ' ' + item.speaker : ''), item.text, '');
    });
    return lines.join('\n').trimEnd() + '\n';
  }

  return Object.freeze({ rates, rateInfo, parseTC, formatTC, secondsToFrames, framesToSeconds, srtTime, parseSRT, validateSession, makeEDL, makeSRT, makeCSV, makeTXT });
}));
