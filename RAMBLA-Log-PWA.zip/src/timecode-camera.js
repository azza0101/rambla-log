/* RAMBLA optical timecode reader. Images remain in memory; no image upload/storage.
 * Tesseract worker protocol pinned to 6.0.1 (src/createWorker.js), core 6.0.0.
 * Direct worker ownership permits cancellation during model initialization.
 * https://github.com/naptha/tesseract.js/blob/master/docs/api.md
 * https://cdn.jsdelivr.net/npm/tesseract.js@6.0.1/src/createWorker.js
 */
(function (root, factory) {
  'use strict';
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.RamblaTimecodeCamera = api.RamblaTimecodeCamera;
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
  'use strict';
  const WORKER = 'https://cdn.jsdelivr.net/npm/tesseract.js@6.0.1/dist/worker.min.js';
  const CORE = 'https://cdn.jsdelivr.net/npm/tesseract.js-core@6.0.0';
  const LANG = 'https://cdn.jsdelivr.net/npm/@tesseract.js-data/eng@1.0.0/4.0.0_best_int';
  const DEFAULT_ROI = { x: .1, y: .4, width: .8, height: .2 };
  const clamp = (value, lo, hi) => Math.min(hi, Math.max(lo, value));
  const cancelled = () => Object.assign(new Error('Scansione annullata.'), { name: 'AbortError' });
  const asError = value => value instanceof Error ? value : new Error(String(value));
  const stopTracks = stream => { if (stream) stream.getTracks().forEach(track => track.stop()); };

  function normalizeROI(value = DEFAULT_ROI) {
    if (!value || !['x', 'y', 'width', 'height'].every(key => Number.isFinite(value[key])) || value.width <= 0 || value.height <= 0) {
      throw new Error('Il ritaglio deve avere coordinate finite e dimensioni positive.');
    }
    const x = clamp(value.x, 0, .99), y = clamp(value.y, 0, .99);
    return { x, y, width: clamp(value.width, .01, 1 - x), height: clamp(value.height, .01, 1 - y) };
  }

  // Coordinates are in the camera source, including the part outside a CSS
  // object-fit:cover viewport. Keep the reticle and the sampled pixels identical.
  function fixedROI(width, height, viewportAspect = 16 / 9) {
    if (![width, height, viewportAspect].every(value => Number.isFinite(value) && value > 0)) throw new Error('Dimensioni fotocamera non valide.');
    const visibleWidth = Math.min(width, height * viewportAspect);
    const visibleHeight = Math.min(height, width / viewportAspect);
    const cropWidth = Math.min(visibleWidth * .8, visibleHeight * .8 * 5.5), cropHeight = cropWidth / 5.5;
    return { x: (width - cropWidth) / (2 * width), y: (height - cropHeight) / (2 * height), width: cropWidth / width, height: cropHeight / height };
  }

  function percentile(histogram, count, fraction) {
    const target = Math.max(1, Math.ceil(count * fraction));
    let seen = 0;
    for (let i = 0; i < 256; i++) { seen += histogram[i]; if (seen >= target) return i; }
    return 255;
  }

  // The camera supplies a small crop (~528 x 96), never the full sensor image.
  // Percentiles preserve faint digits; border samples identify display polarity.
  // A second Sauvola pass is useful for an unevenly lit display. It is built from
  // the same raw pixels, so neither a second capture nor image storage is needed.
  function preprocessImage(image, { exposure = 0, threshold = false } = {}) {
    const { width, height, data } = image || {};
    if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || !data || data.length !== width * height * 4) throw new Error('Ritaglio OCR non valido.');
    const size = width * height, gray = new Float32Array(size), histogram = new Uint32Array(256), borderHistogram = new Uint32Array(256);
    const gain = Math.pow(2, clamp(Number(exposure) || 0, -2, 2));
    const gamma = Math.pow(2, -clamp(Number(exposure) || 0, -2, 2) * .5);
    const border = Math.max(1, Math.round(Math.min(width, height) * .08));
    let clipped = 0, borderCount = 0;
    for (let y = 0, i = 0; y < height; y++) for (let x = 0; x < width; x++, i++) {
      const p = i * 4, luminance = Math.round((data[p] * 77 + data[p + 1] * 150 + data[p + 2] * 29) / 256);
      if (luminance >= 250) clipped++;
      gray[i] = clamp(luminance * gain, 0, 255); histogram[luminance]++;
      if (x < border || x >= width - border || y < border || y >= height - border) { borderHistogram[luminance]++; borderCount++; }
    }
    let rawLo = percentile(histogram, size, .02), rawHi = percentile(histogram, size, .98);
    // Small, thin digits can occupy less than 2% of the reticle. Widen the
    // sampled tails only when both robust endpoints collapse to background;
    // isolated hot pixels still cannot set the contrast range.
    if (rawLo === rawHi) { rawLo = percentile(histogram, size, .005); rawHi = percentile(histogram, size, .995); }
    const lo = clamp(rawLo * gain, 0, 255), hi = clamp(rawHi * gain, 0, 255), contrast = hi - lo;
    const invert = percentile(borderHistogram, borderCount, .5) < (rawHi + rawLo) / 2;
    const normalized = new Uint8Array(size);
    let edges = 0;
    for (let i = 0; i < size; i++) {
      // Brightness is also applied to the video preview. The gamma adjustment
      // survives automatic contrast and reduces the halo of bright digits.
      const tone = contrast > 0 ? 255 * Math.pow(clamp((gray[i] - lo) / contrast, 0, 1), gamma) : (invert ? 0 : 255);
      normalized[i] = Math.round(invert ? 255 - tone : tone);
      if (i % width) edges += Math.abs(normalized[i] - normalized[i - 1]);
    }
    if (threshold && contrast > 0) {
      const stride = width + 1, integral = new Float64Array(stride * (height + 1)), squared = new Float64Array(integral.length);
      for (let y = 1; y <= height; y++) {
        let sum = 0, sumSquared = 0;
        for (let x = 1; x <= width; x++) {
          const value = normalized[(y - 1) * width + x - 1], p = y * stride + x;
          sum += value; sumSquared += value * value;
          integral[p] = integral[p - stride] + sum; squared[p] = squared[p - stride] + sumSquared;
        }
      }
      const radius = Math.max(6, Math.min(24, Math.round(height * .2)));
      for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
        const x0 = Math.max(0, x - radius), x1 = Math.min(width, x + radius + 1), y0 = Math.max(0, y - radius), y1 = Math.min(height, y + radius + 1);
        const a = y0 * stride + x0, b = y0 * stride + x1, c = y1 * stride + x0, d = y1 * stride + x1, count = (x1 - x0) * (y1 - y0);
        const mean = (integral[d] - integral[b] - integral[c] + integral[a]) / count;
        const variance = Math.max(0, (squared[d] - squared[b] - squared[c] + squared[a]) / count - mean * mean);
        // The subtraction prevents a smooth dark gradient, pushed close to
        // zero by global contrast, from becoming a false foreground stroke.
        const cut = Math.min(mean - 8, mean * (1 + .2 * (Math.sqrt(variance) / 128 - 1)));
        normalized[y * width + x] = normalized[y * width + x] < cut ? 0 : 255;
      }
    }
    const padding = 10, outputWidth = width + padding * 2, outputHeight = height + padding * 2;
    const output = new Uint8ClampedArray(outputWidth * outputHeight * 4); output.fill(255);
    for (let y = 0, i = 0; y < height; y++) for (let x = 0; x < width; x++, i++) {
      const p = ((y + padding) * outputWidth + x + padding) * 4;
      output[p] = output[p + 1] = output[p + 2] = normalized[i];
    }
    return { width: outputWidth, height: outputHeight, data: output, padding, quality: { contrast: rawHi - rawLo, clippedFraction: clipped / size, edgeEnergy: edges / size, polarity: invert ? 'light-on-dark' : 'dark-on-light', threshold: Boolean(threshold) } };
  }

  function parseReading(text, fps, core) {
    // Separators are often the first pixels lost on a small display. Accept four
    // exact pairs only; never substitute letters or search outside the crop.
    const source = String(text || '').trim().replace(/^TC\s+/i, '');
    const match = /^(\d{2})(?:\s*[:.;]\s*|\s*)(\d{2})(?:\s*[:.;]\s*|\s*)(\d{2})(?:\s*[:.;]\s*|\s*)(\d{2})$/.exec(source);
    if (!match) return null;
    try {
      const timecode = match[1] + ':' + match[2] + ':' + match[3] + (core.rateInfo(fps).drop ? ';' : ':') + match[4];
      const frames = core.parseTC(timecode, fps);
      return Number.isInteger(frames) && frames >= 0 ? { timecode, frames } : null;
    } catch (_) { return null; }
  }

  class StabilityFilter {
    constructor(fps, core) {
      const rate = core.rateInfo(fps);
      this.rate = rate.rate;
      this.dayFrames = core.parseTC('23:59:59' + (rate.drop ? ';' : ':') + String(rate.nominal - 1).padStart(2, '0'), fps) + 1;
      this.reset();
    }
    reset() { this.first = this.last = null; this.count = this.misses = 0; this.required = 3; }
    miss(capturedAt) {
      this.misses++;
      if (!this.last || !Number.isFinite(capturedAt) || capturedAt <= this.last.capturedAt || capturedAt - this.last.capturedAt > 5000 || this.misses > 1) this.reset();
      return { stable: false, count: this.count, required: this.required, reason: 'confidence' };
    }
    push(reading) {
      if (!reading || !Number.isInteger(reading.frames) || reading.frames < 0 || reading.frames >= this.dayFrames || !Number.isFinite(reading.capturedAt)) {
        this.reset();
        return { stable: false, count: 0, required: 3, reason: 'invalid' };
      }
      if (!Number.isFinite(reading.confidence) || reading.confidence < 40) return this.miss(reading.capturedAt);
      let reason = 'collecting';
      if (this.last) {
        const gap = (reading.capturedAt - this.last.capturedAt) / 1000;
        const delta = (reading.frames - this.last.frames + this.dayFrames) % this.dayFrames;
        const span = (reading.capturedAt - this.first.capturedAt) / 1000;
        const total = (reading.frames - this.first.frames + this.dayFrames) % this.dayFrames;
        const coherent = gap > 0 && gap <= 15 && delta > 0 && Math.abs(delta - gap * this.rate) <= 3 && Math.abs(total - span * this.rate) <= 3;
        if (!coherent) { reason = delta === 0 ? 'frozen' : 'incoherent'; this.reset(); }
      }
      if (!this.first) this.first = reading;
      this.last = reading;
      this.count++; this.misses = 0;
      this.required = Math.max(this.required, reading.inferredSeparators || reading.confidence < 50 ? 5 : reading.confidence < 60 ? 4 : 3);
      return { stable: this.count >= this.required, count: this.count, required: this.required, reason: this.count >= this.required ? 'stable' : reason };
    }
  }

  // Race an external operation against cancellation/timeout; late camera streams
  // are handled separately, because getUserMedia itself cannot be aborted.
  function abortable(promise, signal, timeout = 60000) {
    return new Promise((resolve, reject) => {
      let timer;
      const finish = (fn, value) => { root.clearTimeout(timer); signal.removeEventListener('abort', abort); fn(value); };
      const abort = () => finish(reject, cancelled());
      signal.addEventListener('abort', abort, { once: true });
      if (signal.aborted) { abort(); return; }
      timer = root.setTimeout(() => finish(reject, new Error('Tempo scaduto: riprova con una connessione attiva.')), timeout);
      Promise.resolve(promise).then(value => finish(resolve, value), error => finish(reject, error));
    });
  }

  class OCRWorker {
    constructor(onProgress) {
      this.pending = new Map(); this.serial = 0;
      this.url = root.URL.createObjectURL(new root.Blob(['importScripts(' + JSON.stringify(WORKER) + ');'], { type: 'application/javascript' }));
      try { this.worker = new root.Worker(this.url); }
      catch (error) { root.URL.revokeObjectURL(this.url); this.url = null; throw error; }
      this.worker.onmessage = ({ data }) => {
        if (data.status === 'progress') { onProgress(data.data || {}); return; }
        const job = this.pending.get(data.jobId);
        if (!job) return;
        root.clearTimeout(job.timer); this.pending.delete(data.jobId);
        if (data.status === 'resolve') job.resolve(data.data);
        else job.reject(asError(data.data || 'Errore del motore OCR.'));
      };
      this.worker.onerror = event => { if (event.preventDefault) event.preventDefault(); this.terminate(new Error(event.message || 'Impossibile caricare il motore OCR.')); };
      this.worker.onmessageerror = () => this.terminate(new Error('Risposta OCR non leggibile.'));
    }
    request(action, payload) {
      if (!this.worker) return Promise.reject(cancelled());
      return new Promise((resolve, reject) => {
        const jobId = 'ocr-' + (++this.serial);
        const timer = root.setTimeout(() => this.terminate(new Error('OCR troppo lento o download interrotto. Riprova.')), 60000);
        this.pending.set(jobId, { resolve, reject, timer });
        try { this.worker.postMessage({ workerId: 'rambla-timecode', jobId, action, payload }); }
        catch (error) { this.terminate(asError(error)); }
      });
    }
    async initialize() {
      await this.request('load', { options: { lstmOnly: true, corePath: CORE, logging: false } });
      await this.request('loadLanguage', { langs: 'eng', options: { langPath: LANG, cachePath: 'rambla-ocr-eng-1.0.0', cacheMethod: 'write', gzip: true, lstmOnly: true } });
      await this.request('initialize', { langs: 'eng', oem: 1, config: { load_system_dawg: '0', load_freq_dawg: '0', load_punc_dawg: '0' } });
      await this.request('setParameters', { params: { tessedit_pageseg_mode: '7', tessedit_char_whitelist: '0123456789:;.', preserve_interword_spaces: '1', user_defined_dpi: '300' } });
    }
    recognize(image) { return this.request('recognize', { image, options: {}, output: { text: true } }); }
    terminate(error = cancelled()) {
      if (this.worker) { this.worker.terminate(); this.worker = null; }
      if (this.url) { root.URL.revokeObjectURL(this.url); this.url = null; }
      this.pending.forEach(job => { root.clearTimeout(job.timer); job.reject(error); });
      this.pending.clear();
    }
  }

  function videoReady(video, signal) {
    if (video.videoWidth && video.videoHeight && video.readyState >= 2) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const events = ['loadedmetadata', 'loadeddata', 'canplay'];
      let timer;
      const finish = error => {
        root.clearTimeout(timer); events.forEach(event => video.removeEventListener(event, ready));
        signal.removeEventListener('abort', abort); video.removeEventListener('error', failed);
        if (error) reject(error); else resolve();
      };
      const ready = () => { if (video.videoWidth && video.videoHeight && video.readyState >= 2) finish(); };
      const abort = () => finish(cancelled()), failed = () => finish(new Error('Anteprima fotocamera non disponibile.'));
      events.forEach(event => video.addEventListener(event, ready));
      video.addEventListener('error', failed); signal.addEventListener('abort', abort, { once: true });
      timer = root.setTimeout(failed, 12000);
      if (signal.aborted) abort(); else ready();
    });
  }

  function canvasBytes(canvas) {
    return new Promise((resolve, reject) => {
      canvas.toBlob(blob => {
        if (!blob) { reject(new Error('Il ritaglio della fotocamera non è leggibile.')); return; }
        blob.arrayBuffer().then(buffer => resolve(new Uint8Array(buffer)), reject);
      }, 'image/png');
    });
  }

  class RamblaTimecodeCamera {
    constructor(options) {
      this.video = options.video; this.canvas = options.canvas;
      this.onStatus = options.onStatus || (() => {});
      this.onReading = options.onReading || (() => {});
      this.onError = options.onError || (() => {});
      this.onCameraControls = options.onCameraControls || (() => {});
      this._viewportAspect = 16 / 9; this._roiOverride = null;
      this.roi = fixedROI(this.video?.videoWidth || 1920, this.video?.videoHeight || 1080, this._viewportAspect);
      this._generation = 0; this._roiRevision = 0;
      this._running = false; this._badReadings = 0;
      this._exposure = this._requestedExposure = this._softwareExposure = 0;
      this._exposureRequest = 0; this._exposureMode = 'software'; this._exposurePending = false;
    }
    _status(state, message, progress, extra = {}) { this.onStatus({ state, message, roi: this.getROI(), ...(Number.isFinite(progress) ? { progress: clamp(progress, 0, 1) } : {}), ...extra }); }
    _alive(run) { return this._running && run === this._generation; }
    _invalidateCapture() {
      this._roiRevision++; this._badReadings = 0;
      if (this._filter) this._filter.reset();
    }
    getROI() {
      const roi = this._roiOverride || fixedROI(this.video?.videoWidth || 1920, this.video?.videoHeight || 1080, this._viewportAspect);
      if (['x', 'y', 'width', 'height'].some(key => Math.abs(roi[key] - this.roi[key]) > 1e-7)) { this.roi = roi; this._invalidateCapture(); }
      return { ...this.roi };
    }
    setViewport(width, height) {
      if (![width, height].every(value => Number.isFinite(value) && value > 0)) return this.getROI();
      this._viewportAspect = width / height;
      return this.getROI();
    }
    // Retained for old callers only; the app uses the fixed viewport reticle.
    setROI(roi) {
      this._roiOverride = roi ? normalizeROI(roi) : null;
      return this.getROI();
    }
    _controlInfo() {
      const cap = this._exposureCap, hardware = this._exposureMode === 'hardware' && cap;
      return { mode: hardware ? 'hardware' : 'software', value: this._exposurePending ? this._requestedExposure : this._exposure,
        min: hardware ? cap.min : -2, max: hardware ? cap.max : 2, step: hardware ? cap.step : .1, pending: this._exposurePending,
        previewFilter: hardware || this._softwareExposure === 0 ? 'none' : 'brightness(' + Math.pow(2, this._softwareExposure).toFixed(3) + ')',
        message: hardware ? 'Esposizione della fotocamera verificata.' : 'Correzione digitale su anteprima e OCR. I bianchi bruciati non si recuperano.' };
    }
    _reportControls() {
      const info = this._controlInfo();
      if (this.video?.style) this.video.style.filter = info.previewFilter;
      this.onCameraControls(info);
      return info;
    }
    _softwareControls(value) {
      this._exposure = this._softwareExposure = value;
      this._exposureMode = 'software'; this._exposurePending = false;
      return this._reportControls();
    }
    // Values are EV for hardware, or equivalent digital brightness stops when
    // the browser cannot expose/verify exposureCompensation. Calls serialize:
    // an older applyConstraints cannot overtake the user's latest slider value.
    setExposure(value) {
      if (!Number.isFinite(Number(value))) return Promise.reject(new Error('Esposizione non valida.'));
      this._requestedExposure = clamp(Number(value), -2, 2); this._exposureRequest++;
      this._invalidateCapture();
      if (!this._running || !this._track || !this._exposureCap) return Promise.resolve(this._softwareControls(this._requestedExposure));
      this._exposurePending = true; this._reportControls();
      if (this._exposureTask) return this._exposureTask;
      const run = this._generation, track = this._track, signal = this._controller.signal;
      const task = this._applyExposure(run, track, signal).finally(() => { if (this._exposureTask === task) this._exposureTask = null; });
      this._exposureTask = task;
      return task;
    }
    async _applyExposure(run, track, signal) {
      while (this._alive(run) && this._track === track) {
        const request = this._exposureRequest, cap = this._exposureCap, wanted = this._requestedExposure;
        if (!cap) return this._softwareControls(wanted);
        const target = Number(clamp(cap.min + Math.round((wanted - cap.min) / cap.step) * cap.step, cap.min, cap.max).toFixed(6));
        try {
          const previous = track.getConstraints ? track.getConstraints() : {}, constraints = { ...previous };
          delete constraints.exposureCompensation;
          const advanced = (previous.advanced || []).map(item => { const copy = { ...item }; delete copy.exposureCompensation; return copy; }).filter(item => Object.keys(item).length);
          advanced.push({ ...(this._continuousFocus ? { focusMode: 'continuous' } : {}), exposureCompensation: target });
          await abortable(track.applyConstraints({ ...constraints, advanced }), signal, 3000);
          if (!this._alive(run) || this._track !== track) return this._controlInfo();
          const actual = track.getSettings().exposureCompensation;
          if (!Number.isFinite(actual) || Math.abs(actual - target) > Math.max(.005, cap.step * .1)) throw new Error('Esposizione hardware non verificabile.');
          if (request !== this._exposureRequest) continue;
          this._exposure = target; this._softwareExposure = 0;
          this._exposureMode = 'hardware'; this._exposurePending = false;
          return this._reportControls();
        } catch (_) {
          if (!this._alive(run) || this._track !== track) return this._controlInfo();
          this._exposureCap = null;
          return this._softwareControls(this._requestedExposure);
        }
      }
      return this._controlInfo();
    }
    async start({ fps = '25', roi = null } = {}) {
      this._release();
      const run = ++this._generation;
      this._controller = new root.AbortController();
      const signal = this._controller.signal;
      this._running = true;
      try {
        if (root.isSecureContext === false || !root.navigator || !root.navigator.mediaDevices || !root.navigator.mediaDevices.getUserMedia) {
          throw new Error('Apri l’app in Safari tramite HTTPS per usare la fotocamera.');
        }
        if (!this.video || !this.canvas || !root.Worker || !root.RamblaCore) throw new Error('Fotocamera o OCR non supportati in questo browser.');
        this._fps = String(fps); this._filter = new StabilityFilter(this._fps, root.RamblaCore);
        this.setROI(roi);
        this._status('camera', 'Consenti la fotocamera e inquadra il timecode della camera.');
        const camera = root.navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 }, frameRate: { ideal: 30 } } });
        camera.then(stream => { if (!this._alive(run)) stopTracks(stream); }, () => {});
        this._stream = await abortable(camera, signal);
        this._track = this._stream.getVideoTracks()[0];
        this._onTrackEnded = () => { if (this._alive(run)) this._fail(new Error('Fotocamera interrotta. Riapri lo scanner.')); };
        if (this._track && this._track.addEventListener) this._track.addEventListener('ended', this._onTrackEnded);
        this.video.playsInline = true; this.video.muted = true; this.video.autoplay = true;
        this.video.setAttribute('playsinline', ''); this.video.setAttribute('muted', '');
        this.video.srcObject = this._stream;
        await abortable(this.video.play(), signal, 12000);
        await videoReady(this.video, signal);
        const track = this._track;
        this._continuousFocus = false; this._exposureCap = null;
        try {
          const capabilities = track && track.getCapabilities ? track.getCapabilities() : {};
          const exposure = capabilities.exposureCompensation;
          if (exposure && Number.isFinite(exposure.min) && Number.isFinite(exposure.max) && exposure.min <= exposure.max && track.applyConstraints && track.getSettings) {
            const step = Number.isFinite(exposure.step) && exposure.step > 0 ? exposure.step : .1;
            const min = Number((exposure.min + Math.ceil((Math.max(-2, exposure.min) - exposure.min) / step - 1e-7) * step).toFixed(6));
            const max = Number((exposure.min + Math.floor((Math.min(2, exposure.max) - exposure.min) / step + 1e-7) * step).toFixed(6));
            if (min <= max) this._exposureCap = { min, max, step };
          }
          if (capabilities.focusMode && capabilities.focusMode.includes('continuous') && track.applyConstraints) {
            const previous = track.getConstraints ? track.getConstraints() : {};
            await abortable(track.applyConstraints({ ...previous, advanced: [...(previous.advanced || []), { focusMode: 'continuous' }] }), signal, 3000);
            this._continuousFocus = true;
          }
        } catch (_) { /* Autofocus is an optional browser/device capability. */ }
        if (!this._alive(run)) return false;
        await this.setExposure(this._requestedExposure);
        if (!this._alive(run)) return false;
        this._status('loading', 'Caricamento OCR locale gratuito. Il primo avvio richiede Internet.');
        this._ocr = new OCRWorker(progress => {
          if (this._alive(run) && progress.status !== 'recognizing text') this._status('loading', 'Preparazione OCR locale…', progress.progress);
        });
        await this._ocr.initialize();
        if (!this._alive(run)) return false;
        this._status('scanning', 'Centra HH:MM:SS:FF nel riquadro. Verifico da tre a cinque letture in avanzamento.');
        this._scan(run);
        return true;
      } catch (error) {
        if (!this._alive(run)) return false;
        this._fail(asError(error));
        throw asError(error);
      }
    }
    async _scan(run) {
      if (!this._alive(run)) return;
      if (this._exposurePending) { this._timer = root.setTimeout(() => this._scan(run), 300); return; }
      try {
        if (!this.video.videoWidth || this.video.readyState < 2) throw new Error('Anteprima interrotta. Riapri lo scanner.');
        const r = this.getROI(), revision = this._roiRevision, w = this.video.videoWidth, h = this.video.videoHeight;
        const sx = Math.floor(r.x * w), sy = Math.floor(r.y * h);
        const sw = Math.max(1, Math.min(w - sx, Math.round(r.width * w)));
        const sh = Math.max(1, Math.min(h - sy, Math.round(r.height * h)));
        // A display filling most of this 96px strip gives ~40–70px digits.
        // Bound both dimensions even for a legacy caller's unusual crop.
        const scale = Math.min(4, 768 / sw, 96 / sh);
        this.canvas.width = Math.max(1, Math.round(sw * scale));
        this.canvas.height = Math.max(1, Math.round(sh * scale));
        const context = this.canvas.getContext('2d', { willReadFrequently: true });
        if (!context) throw new Error('Anteprima del ritaglio non disponibile.');
        // Timestamp the captured image, never the delayed recognition result.
        const capturedAt = root.performance.now();
        context.drawImage(this.video, sx, sy, sw, sh, 0, 0, this.canvas.width, this.canvas.height);
        const raw = context.getImageData(0, 0, this.canvas.width, this.canvas.height), exposure = this._softwareExposure;
        let candidate = null, quality, passes = 0;
        for (let pass = 0; pass < 2; pass++) {
          const processed = preprocessImage(raw, { exposure, threshold: pass === 1 }); quality = processed.quality;
          this.canvas.width = processed.width; this.canvas.height = processed.height;
          const pixels = context.createImageData(processed.width, processed.height); pixels.data.set(processed.data); context.putImageData(pixels, 0, 0);
          const bytes = await abortable(canvasBytes(this.canvas), this._controller.signal, 12000);
          if (!this._alive(run)) return;
          this.getROI(); // Video metadata may change while an async job is pending.
          if (revision !== this._roiRevision) break;
          const data = await this._ocr.recognize(bytes); passes++;
          if (!this._alive(run)) return;
          this.getROI();
          if (revision !== this._roiRevision) break;
          const parsed = parseReading(data.text, this._fps, root.RamblaCore);
          const confidence = Number.isFinite(data.confidence) ? clamp(data.confidence, 0, 100) : 0;
          if (parsed) {
            const next = { text: String(data.text || '').trim(), ...parsed, capturedAt, confidence, inferredSeparators: /^\s*(?:TC\s+)?\d{8}\s*$/i.test(String(data.text || '')) };
            if (candidate && candidate.frames !== next.frames && candidate.confidence >= 40 && confidence >= 40 && Math.abs(candidate.confidence - confidence) < 15) { candidate = null; break; }
            if (!candidate || confidence > candidate.confidence) candidate = next;
            if (confidence >= 60) break;
          }
        }
        if (revision === this._roiRevision) {
          if (!candidate) {
            this._filter.miss(capturedAt);
            const message = quality.clippedFraction > .55 && quality.contrast < 45 ? 'Display troppo chiaro. Riduci l’esposizione ed evita i riflessi.' : 'Centra i numeri nel riquadro fisso, avvicinati e tieni fermo l’iPhone.';
            this._status('searching', message, undefined, { quality });
          } else {
            const reading = candidate;
            const result = this._filter.push(reading);
            this._badReadings = result.reason === 'incoherent' ? this._badReadings + 1 : 0;
            let message = 'Lettura ' + Math.min(result.count, result.required) + '/' + result.required + ': continua a inquadrare il timecode.';
            if (result.reason === 'confidence') message = 'Lettura incerta. Avvicina e metti a fuoco il display.';
            if (result.reason === 'frozen') message = 'Il timecode è fermo. L’aggancio richiede un timecode che avanza.';
            if (this._badReadings >= 2) message = 'Avanzamento incoerente. Controlla gli FPS selezionati e la leggibilità del display.';
            if (result.stable) message = 'Timecode ottico coerente. Precisione legata a display, fotocamera e OCR.';
            else if (root.performance.now() - capturedAt > 1500) message += ' OCR lento: attendo il prossimo fotogramma.';
            this._status(result.stable ? 'stable' : 'scanning', message, undefined, { quality });
            this.onReading({ ...reading, stable: result.stable, readings: result.count, requiredReadings: result.required, passes, quality });
          }
        }
        if (this._alive(run)) this._timer = root.setTimeout(() => this._scan(run), 300);
      } catch (error) { if (this._alive(run)) this._fail(asError(error)); }
    }
    _release() {
      this._running = false;
      root.clearTimeout(this._timer); this._timer = null;
      if (this._controller) { this._controller.abort(); this._controller = null; }
      this._exposureTask = null; this._exposureCap = null; this._exposurePending = false; this._exposureRequest++;
      if (this._ocr) { this._ocr.terminate(); this._ocr = null; }
      if (this._track && this._track.removeEventListener) this._track.removeEventListener('ended', this._onTrackEnded);
      this._track = this._onTrackEnded = null;
      stopTracks(this._stream); this._stream = null;
      if (this.video) { this.video.pause(); this.video.srcObject = null; if (this.video.style) this.video.style.filter = 'none'; }
      if (this._filter) this._filter.reset();
    }
    _fail(error) {
      this._release(); this._generation++;
      const names = { NotAllowedError: 'Consenti la fotocamera nelle impostazioni di Safari, poi riprova.', NotFoundError: 'Nessuna fotocamera disponibile.', NotReadableError: 'La fotocamera è occupata o non disponibile. Chiudi le altre app e riprova.' };
      this._status('error', names[error.name] || error.message);
      this.onError(error);
    }
    stop() {
      const active = this._running;
      this._release(); this._generation++;
      if (active) this._status('stopped', 'Fotocamera chiusa.');
      return Promise.resolve();
    }
  }
  RamblaTimecodeCamera.preprocessImage = preprocessImage;
  RamblaTimecodeCamera.fixedROI = fixedROI;
  return { RamblaTimecodeCamera, parseReading, StabilityFilter, normalizeROI, fixedROI, preprocessImage };
});
