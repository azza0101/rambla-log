/* RAMBLA optical timecode reader. Images remain in memory; no image upload/storage.
 * Tesseract worker protocol pinned to 6.0.1 (src/createWorker.js), core 6.0.0.
 * Direct worker ownership permits cancellation during model initialization.
 * https://github.com/naptha/tesseract.js/blob/master/docs/api.md
 * https://cdn.jsdelivr.net/npm/tesseract.js@6.0.1/src/createWorker.js
 */
(function (root, factory) {
  'use strict';
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.RamblaTimecodeCamera = api.RamblaTimecodeCamera;
})(typeof window !== 'undefined' ? window : globalThis, function (root) {
  'use strict';
  const WORKER = 'https://cdn.jsdelivr.net/npm/tesseract.js@6.0.1/dist/worker.min.js';
  const CORE = 'https://cdn.jsdelivr.net/npm/tesseract.js-core@6.0.0';
  const LANG = 'https://cdn.jsdelivr.net/npm/@tesseract.js-data/eng@1.0.0/4.0.0_best_int';
  const DEFAULT_ROI = { x: .1, y: .4, width: .8, height: .2 };
  const clamp = (value, lo, hi) => Math.min(hi, Math.max(lo, value));
  const cancelled = () => Object.assign(new Error('Scansione annullata.'), { name: 'AbortError' });
  const asError = value => value instanceof Error ? value : new Error(String(value));
  const stopTracks = stream => { if (stream) stream.getTracks().forEach(track => track.stop()); };

  function normalizeROI(value = DEFAULT_ROI) {
    if (!value || !['x', 'y', 'width', 'height'].every(key => Number.isFinite(value[key])) || value.width <= 0 || value.height <= 0) {
      throw new Error('Il ritaglio deve avere coordinate finite e dimensioni positive.');
    }
    const x = clamp(value.x, 0, .99), y = clamp(value.y, 0, .99);
    return { x, y, width: clamp(value.width, .01, 1 - x), height: clamp(value.height, .01, 1 - y) };
  }

  function parseReading(text, fps, core) {
    // No guessing missing separators, letters as digits, or eight-digit numbers.
    const source = String(text || '').trim(), pattern = /\d{2}\s*:\s*\d{2}\s*:\s*\d{2}\s*[:;]\s*\d{2}/g;
    const matches = Array.from(source.matchAll(pattern));
    if (matches.length !== 1) return null;
    const match = matches[0], before = source.slice(0, match.index), after = source.slice(match.index + match[0].length);
    if (/[\d:;]\s*$/.test(before) || /^\s*[\d:;]/.test(after)) return null;
    const timecode = match[0].replace(/\s/g, '');
    try {
      const frames = core.parseTC(timecode, fps);
      return Number.isInteger(frames) && frames >= 0 ? { timecode, frames } : null;
    } catch (_) { return null; }
  }

  class StabilityFilter {
    constructor(fps, core) {
      const rate = core.rateInfo(fps);
      this.rate = rate.rate;
      this.dayFrames = core.parseTC('23:59:59' + (rate.drop ? ';' : ':') + String(rate.nominal - 1).padStart(2, '0'), fps) + 1;
      this.reset();
    }
    reset() { this.first = this.last = null; this.count = 0; }
    push(reading) {
      if (!reading || !Number.isInteger(reading.frames) || reading.frames < 0 || reading.frames >= this.dayFrames || !Number.isFinite(reading.capturedAt) || !Number.isFinite(reading.confidence) || reading.confidence < 60) {
        this.reset();
        return { stable: false, count: 0, reason: 'confidence' };
      }
      let reason = 'collecting';
      if (this.last) {
        const gap = (reading.capturedAt - this.last.capturedAt) / 1000;
        const delta = (reading.frames - this.last.frames + this.dayFrames) % this.dayFrames;
        const span = (reading.capturedAt - this.first.capturedAt) / 1000;
        const total = (reading.frames - this.first.frames + this.dayFrames) % this.dayFrames;
        const coherent = gap > 0 && gap <= 15 && delta > 0 && Math.abs(delta - gap * this.rate) <= 3 && Math.abs(total - span * this.rate) <= 3;
        if (!coherent) { reason = delta === 0 ? 'frozen' : 'incoherent'; this.reset(); }
      }
      if (!this.first) this.first = reading;
      this.last = reading;
      this.count++;
      return { stable: this.count >= 3, count: this.count, reason: this.count >= 3 ? 'stable' : reason };
    }
  }

  // Race an external operation against cancellation/timeout; late camera streams
  // are handled separately, because getUserMedia itself cannot be aborted.
  function abortable(promise, signal, timeout = 60000) {
    return new Promise((resolve, reject) => {
      let timer;
      const finish = (fn, value) => { root.clearTimeout(timer); signal.removeEventListener('abort', abort); fn(value); };
      const abort = () => finish(reject, cancelled());
      signal.addEventListener('abort', abort, { once: true });
      if (signal.aborted) { abort(); return; }
      timer = root.setTimeout(() => finish(reject, new Error('Tempo scaduto: riprova con una connessione attiva.')), timeout);
      Promise.resolve(promise).then(value => finish(resolve, value), error => finish(reject, error));
    });
  }

  class OCRWorker {
    constructor(onProgress) {
      this.pending = new Map(); this.serial = 0;
      this.url = root.URL.createObjectURL(new root.Blob(['importScripts(' + JSON.stringify(WORKER) + ');'], { type: 'application/javascript' }));
      try { this.worker = new root.Worker(this.url); }
      catch (error) { root.URL.revokeObjectURL(this.url); this.url = null; throw error; }
      this.worker.onmessage = ({ data }) => {
        if (data.status === 'progress') { onProgress(data.data || {}); return; }
        const job = this.pending.get(data.jobId);
        if (!job) return;
        root.clearTimeout(job.timer); this.pending.delete(data.jobId);
        if (data.status === 'resolve') job.resolve(data.data);
        else job.reject(asError(data.data || 'Errore del motore OCR.'));
      };
      this.worker.onerror = event => { if (event.preventDefault) event.preventDefault(); this.terminate(new Error(event.message || 'Impossibile caricare il motore OCR.')); };
      this.worker.onmessageerror = () => this.terminate(new Error('Risposta OCR non leggibile.'));
    }
    request(action, payload) {
      if (!this.worker) return Promise.reject(cancelled());
      return new Promise((resolve, reject) => {
        const jobId = 'ocr-' + (++this.serial);
        const timer = root.setTimeout(() => this.terminate(new Error('OCR troppo lento o download interrotto. Riprova.')), 60000);
        this.pending.set(jobId, { resolve, reject, timer });
        try { this.worker.postMessage({ workerId: 'rambla-timecode', jobId, action, payload }); }
        catch (error) { this.terminate(asError(error)); }
      });
    }
    async initialize() {
      await this.request('load', { options: { lstmOnly: true, corePath: CORE, logging: false } });
      await this.request('loadLanguage', { langs: 'eng', options: { langPath: LANG, cachePath: 'rambla-ocr-eng-1.0.0', cacheMethod: 'write', gzip: true, lstmOnly: true } });
      await this.request('initialize', { langs: 'eng', oem: 1, config: { load_system_dawg: '0', load_freq_dawg: '0', load_punc_dawg: '0' } });
      await this.request('setParameters', { params: { tessedit_pageseg_mode: '7', tessedit_char_whitelist: '0123456789:;', preserve_interword_spaces: '1', user_defined_dpi: '150' } });
    }
    recognize(image) { return this.request('recognize', { image, options: {}, output: { text: true } }); }
    terminate(error = cancelled()) {
      if (this.worker) { this.worker.terminate(); this.worker = null; }
      if (this.url) { root.URL.revokeObjectURL(this.url); this.url = null; }
      this.pending.forEach(job => { root.clearTimeout(job.timer); job.reject(error); });
      this.pending.clear();
    }
  }

  function videoReady(video, signal) {
    if (video.videoWidth && video.videoHeight && video.readyState >= 2) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const events = ['loadedmetadata', 'loadeddata', 'canplay'];
      let timer;
      const finish = error => {
        root.clearTimeout(timer); events.forEach(event => video.removeEventListener(event, ready));
        signal.removeEventListener('abort', abort); video.removeEventListener('error', failed);
        if (error) reject(error); else resolve();
      };
      const ready = () => { if (video.videoWidth && video.videoHeight && video.readyState >= 2) finish(); };
      const abort = () => finish(cancelled()), failed = () => finish(new Error('Anteprima fotocamera non disponibile.'));
      events.forEach(event => video.addEventListener(event, ready));
      video.addEventListener('error', failed); signal.addEventListener('abort', abort, { once: true });
      timer = root.setTimeout(failed, 12000);
      if (signal.aborted) abort(); else ready();
    });
  }

  function canvasBytes(canvas) {
    return new Promise((resolve, reject) => {
      canvas.toBlob(blob => {
        if (!blob) { reject(new Error('Il ritaglio della fotocamera non è leggibile.')); return; }
        blob.arrayBuffer().then(buffer => resolve(new Uint8Array(buffer)), reject);
      }, 'image/png');
    });
  }

  class RamblaTimecodeCamera {
    constructor(options) {
      this.video = options.video; this.canvas = options.canvas;
      this.onStatus = options.onStatus || (() => {});
      this.onReading = options.onReading || (() => {});
      this.onError = options.onError || (() => {});
      this.roi = normalizeROI(); this._generation = 0; this._roiRevision = 0;
      this._running = false; this._badReadings = 0;
    }
    _status(state, message, progress) { this.onStatus({ state, message, ...(Number.isFinite(progress) ? { progress: clamp(progress, 0, 1) } : {}) }); }
    _alive(run) { return this._running && run === this._generation; }
    setROI(roi) {
      this.roi = normalizeROI(roi); this._roiRevision++; this._badReadings = 0;
      if (this._filter) this._filter.reset();
      return { ...this.roi };
    }
    async start({ fps = '25', roi = this.roi } = {}) {
      this._release();
      const run = ++this._generation;
      this._controller = new root.AbortController();
      const signal = this._controller.signal;
      this._running = true;
      try {
        if (root.isSecureContext === false || !root.navigator || !root.navigator.mediaDevices || !root.navigator.mediaDevices.getUserMedia) {
          throw new Error('Apri l’app in Safari tramite HTTPS per usare la fotocamera.');
        }
        if (!this.video || !this.canvas || !root.Worker || !root.RamblaCore) throw new Error('Fotocamera o OCR non supportati in questo browser.');
        this._fps = String(fps); this._filter = new StabilityFilter(this._fps, root.RamblaCore);
        this.setROI(roi);
        this._status('camera', 'Consenti la fotocamera e inquadra il timecode della camera.');
        const camera = root.navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 }, frameRate: { ideal: 30 } } });
        camera.then(stream => { if (!this._alive(run)) stopTracks(stream); }, () => {});
        this._stream = await abortable(camera, signal);
        this._track = this._stream.getVideoTracks()[0];
        this._onTrackEnded = () => { if (this._alive(run)) this._fail(new Error('Fotocamera interrotta. Riapri lo scanner.')); };
        if (this._track && this._track.addEventListener) this._track.addEventListener('ended', this._onTrackEnded);
        this.video.playsInline = true; this.video.muted = true; this.video.autoplay = true;
        this.video.setAttribute('playsinline', ''); this.video.setAttribute('muted', '');
        this.video.srcObject = this._stream;
        await abortable(this.video.play(), signal, 12000);
        await videoReady(this.video, signal);
        const track = this._track;
        try {
          const capabilities = track && track.getCapabilities ? track.getCapabilities() : {};
          if (capabilities.focusMode && capabilities.focusMode.includes('continuous') && track.applyConstraints) {
            await abortable(track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }), signal, 3000);
          }
        } catch (_) { /* Autofocus is an optional browser/device capability. */ }
        if (!this._alive(run)) return false;
        this._status('loading', 'Caricamento OCR locale gratuito. Il primo avvio richiede Internet.');
        this._ocr = new OCRWorker(progress => {
          if (this._alive(run) && progress.status !== 'recognizing text') this._status('loading', 'Preparazione OCR locale…', progress.progress);
        });
        await this._ocr.initialize();
        if (!this._alive(run)) return false;
        this._status('scanning', 'Inquadra solo HH:MM:SS:FF. Attendo tre letture in avanzamento.');
        this._scan(run);
        return true;
      } catch (error) {
        if (!this._alive(run)) return false;
        this._fail(asError(error));
        throw asError(error);
      }
    }
    async _scan(run) {
      if (!this._alive(run)) return;
      const revision = this._roiRevision;
      try {
        if (!this.video.videoWidth || this.video.readyState < 2) throw new Error('Anteprima interrotta. Riapri lo scanner.');
        const r = this.roi, w = this.video.videoWidth, h = this.video.videoHeight;
        const sx = Math.floor(r.x * w), sy = Math.floor(r.y * h);
        const sw = Math.max(1, Math.min(w - sx, Math.round(r.width * w)));
        const sh = Math.max(1, Math.min(h - sy, Math.round(r.height * h)));
        const scale = Math.min(3, 1280 / sw, 480 / sh);
        this.canvas.width = Math.max(1, Math.round(sw * scale));
        this.canvas.height = Math.max(1, Math.round(sh * scale));
        const context = this.canvas.getContext('2d');
        if (!context) throw new Error('Anteprima del ritaglio non disponibile.');
        // Timestamp the captured image, never the delayed recognition result.
        const capturedAt = root.performance.now();
        context.drawImage(this.video, sx, sy, sw, sh, 0, 0, this.canvas.width, this.canvas.height);
        const bytes = await abortable(canvasBytes(this.canvas), this._controller.signal, 12000);
        if (!this._alive(run)) return;
        const data = await this._ocr.recognize(bytes);
        if (!this._alive(run)) return;
        if (revision === this._roiRevision) {
          const parsed = parseReading(data.text, this._fps, root.RamblaCore);
          const confidence = Number.isFinite(data.confidence) ? clamp(data.confidence, 0, 100) : 0;
          if (!parsed) {
            this._filter.reset();
            this._status('searching', 'Timecode non leggibile. Stringi il ritaglio, evita riflessi e tieni fermo l’iPhone.');
          } else {
            const reading = { text: String(data.text || '').trim(), ...parsed, capturedAt, confidence };
            const result = this._filter.push(reading);
            this._badReadings = result.reason === 'incoherent' ? this._badReadings + 1 : 0;
            let message = 'Lettura ' + Math.min(result.count, 3) + '/3: continua a inquadrare il timecode.';
            if (result.reason === 'confidence') message = 'Lettura incerta. Avvicina e metti a fuoco il display.';
            if (result.reason === 'frozen') message = 'Il timecode è fermo. L’aggancio richiede un timecode che avanza.';
            if (this._badReadings >= 2) message = 'Avanzamento incoerente. Controlla gli FPS selezionati e la leggibilità del display.';
            if (result.stable) message = 'Timecode ottico coerente. Precisione legata a display, fotocamera e OCR.';
            else if (root.performance.now() - capturedAt > 1500) message += ' OCR lento: attendo il prossimo fotogramma.';
            this._status(result.stable ? 'stable' : 'scanning', message);
            this.onReading({ ...reading, stable: result.stable });
          }
        }
        if (this._alive(run)) this._timer = root.setTimeout(() => this._scan(run), 300);
      } catch (error) { if (this._alive(run)) this._fail(asError(error)); }
    }
    _release() {
      this._running = false;
      root.clearTimeout(this._timer); this._timer = null;
      if (this._controller) { this._controller.abort(); this._controller = null; }
      if (this._ocr) { this._ocr.terminate(); this._ocr = null; }
      if (this._track && this._track.removeEventListener) this._track.removeEventListener('ended', this._onTrackEnded);
      this._track = this._onTrackEnded = null;
      stopTracks(this._stream); this._stream = null;
      if (this.video) { this.video.pause(); this.video.srcObject = null; }
      if (this._filter) this._filter.reset();
    }
    _fail(error) {
      this._release(); this._generation++;
      const names = { NotAllowedError: 'Consenti la fotocamera nelle impostazioni di Safari, poi riprova.', NotFoundError: 'Nessuna fotocamera disponibile.', NotReadableError: 'La fotocamera è occupata o non disponibile. Chiudi le altre app e riprova.' };
      this._status('error', names[error.name] || error.message);
      this.onError(error);
    }
    stop() {
      const active = this._running;
      this._release(); this._generation++;
      if (active) this._status('stopped', 'Fotocamera chiusa.');
      return Promise.resolve();
    }
  }
  return { RamblaTimecodeCamera, parseReading, StabilityFilter, normalizeROI };
});
