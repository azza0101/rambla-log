(function () {
  'use strict';
  const C = window.RamblaCore;
  const $ = id => document.getElementById(id);
  const $$ = selector => Array.from(document.querySelectorAll(selector));
  const esc = text => String(text ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icon = name => `<svg class="icon" aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const uid = () => window.crypto?.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2);
  const KEY = 'rambla-log-v1';
  let storageKey=KEY;
  const CATEGORIES = [
    {id:'keep',name:'Da tenere',color:'Red',icon:'check',bg:'#f8e1db',border:'#eac6bb',ink:'#bd5b47',dot:'#cd6958'},
    {id:'highlight',name:'Highlight',color:'Yellow',icon:'star',bg:'#f4edca',border:'#e4dba8',ink:'#a78f36',dot:'#bda34a'},
    {id:'funny',name:'Divertente',color:'Purple',icon:'smile',bg:'#eee4f1',border:'#dcd0e2',ink:'#93749f',dot:'#9876ad'},
    {id:'emotion',name:'Emozione',color:'Pink',icon:'heart',bg:'#f5e3e8',border:'#e8cdd5',ink:'#b77788',dot:'#bd849a'},
    {id:'turn',name:'Svolta',color:'Green',icon:'turn',bg:'#e3ecdc',border:'#cad9bf',ink:'#73915e',dot:'#7c9a65'},
    {id:'check',name:'Da rivedere',color:'Blue',icon:'flag',bg:'#e2e9ef',border:'#c9d6e2',ink:'#728ca4',dot:'#7899b6'}
  ];
  const catFor = id => CATEGORIES.find(c => c.id === id || c.name === id) || CATEGORIES[0];
  let store = {version:1,sessions:[],activeId:null,prefs:{mode:'native'}};
  let active = false, pendingFlush = false, recovery = false, activeTab = 'transcript';
  let selected = new Set(), native = null, local = null, wake = null, restartTimer = null;
  let clockPerf = 0, clockBase = 0, preSync = null, useWallClock = false;
  let lastSave = 0, lastNativeEnd = [], nativeAllowed = false, speechSuspended = false, nativeRun = 0;
  let interimText = '', toastTimer, noteEdit = null, speechState = 'idle', newSettings = false;
  let scanner = null, scanGeneration = 0, latestReading = null, nativeStopResolve=null, localGeneration=0, latestReadingReceivedAt=0;
  let speakerHistory=[];
  const liveClock = () => performance.now();
  const current = () => store.sessions.find(s => s.id === store.activeId);
  const elapsed = () => active ? Math.max(0,clockBase+(liveClock()-clockPerf)/1000) : Math.max(0,current()?.duration || 0);
  const durationText = seconds => { const n = Math.floor(Math.max(0,seconds));return `${Math.floor(n/3600) ? String(Math.floor(n/3600)).padStart(2,'0')+':' : ''}${String(Math.floor(n/60)%60).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`; };
  const isoDay = date => new Date(date).toLocaleDateString('it-IT',{day:'2-digit',month:'short',year:'numeric'});
  const fileSlug = title => String(title).normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,70) || 'rambla-log';
  function makeSession(title) {
    return {id:uid(),title:title || `Riprese · ${new Date().toLocaleDateString('it-IT',{day:'2-digit',month:'short'})}`,createdAt:new Date().toISOString(),startedAt:null,endedAt:null,duration:0,fps:'25',startTC:'01:00:00:00',language:'it-IT',lookback:10,speaker:'Speaker A',speakers:['Speaker A','Speaker B'],segments:[],markers:[],isDemo:false};
  }
  function notify(message,undo) {
    clearTimeout(toastTimer);$('toast').querySelector('span').textContent=message;
    const btn=$('toast').querySelector('button');btn.hidden=!undo;btn.onclick=undo?()=>{undo();$('toast').hidden=true;}:null;
    $('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,undo?8000:5500);
  }
  function showError(id,message) {$(id).hidden=!message;$(id).textContent=message || '';}
  function persist() {
    if(active && current()) current().duration=elapsed();
    try {localStorage.setItem(storageKey,JSON.stringify(store));$('saveState').classList.remove('error');$('saveState').innerHTML='<span></span>Salvato qui';if(!window.ramblaRecoveryData)$('storageWarning').hidden=true;lastSave=Date.now();return true;}
    catch(e) {$('saveState').classList.add('error');$('saveState').innerHTML='<span></span>Non salvato';$('storageWarning').hidden=false;$('storageWarning').textContent='Il browser non riesce a salvare questa sessione. I dati sono ancora aperti qui: esporta subito il backup JSON e libera spazio.';return false;}
  }
  function loadStore() {
    let raw;
    try {const fresh=localStorage.getItem(KEY+'-fresh');storageKey=fresh?KEY+'-fresh':KEY;raw=fresh||localStorage.getItem(KEY);}catch(e) {showError('storageWarning','Salvataggio locale non disponibile. Esporta un backup prima di chiudere.');}
    if(raw) {
      try {
        const parsed=JSON.parse(raw);if(parsed.version!==1 || !Array.isArray(parsed.sessions))throw Error('Formato archivio non riconosciuto');
        const sessions=parsed.sessions.map(s=>C.validateSession(s));
        store={version:1,sessions,activeId:parsed.activeId,prefs:{mode:['native','local','manual'].includes(parsed.prefs?.mode)?parsed.prefs.mode:'native'}};
      } catch(e) {
        // Never overwrite a damaged archive without giving the user a recovery copy.
        window.ramblaRecoveryData=raw;
        storageKey=KEY+'-fresh';
        showError('storageWarning','L’archivio locale non è leggibile. Ne conservo una copia recuperabile dal pulsante «Recupera archivio». Le nuove sessioni usano un archivio separato fino al download.');
        const b=document.createElement('button');b.className='button button-small';b.textContent='Recupera archivio';b.onclick=()=>saveFile('RAMBLA-archivio-da-recuperare.json',raw,'application/json');$('storageWarning').append(b);
        // The original remains under KEY; new sessions write to a separate key.
      }
    }
    if(!store.sessions.length){const s=makeSession();store.sessions.push(s);store.activeId=s.id;}
    if(!current())store.activeId=store.sessions[0].id;
    recovery=!!(current().startedAt && !current().endedAt && !current().isDemo);
    // Recover a recent optical anchor before a session starts. A stale draft
    // must be scanned again, instead of silently treating an old TC as live.
    const s=current();
    if(!s.startedAt&&s.sync){const age=(Date.now()-Date.parse(s.sync.at))/1000;if(age>=0&&age<300)preSync={frames:C.parseTC(s.sync.timecode,s.fps)+C.secondsToFrames(age,s.fps),capturedAt:liveClock()};else{delete s.sync;notify('Rileggi il timecode della camera prima di iniziare: il precedente sync è scaduto.');}}
  }
  function tcAt(seconds) {const s=current();return C.formatTC(C.parseTC(s.startTC,s.fps)+C.secondsToFrames(seconds,s.fps),s.fps);}
  function displayTC() {
    const s=current();if(!s)return;
    let tc=tcAt(elapsed());
    if(!s.startedAt&&preSync)tc=C.formatTC(preSync.frames+C.secondsToFrames((liveClock()-preSync.capturedAt)/1000,s.fps),s.fps);
    if(!s.startedAt&&useWallClock){const d=new Date();tc=clockTC(d,s.fps);}
    const sep=tc[8] || ':';$('timecode').innerHTML=esc(tc.slice(0,8))+`<span>${sep}${esc(tc.slice(9))}</span>`;
    $('duration').textContent=durationText(elapsed())+' trascorsi';
  }
  function renderSessions() {
    const sorted=[...store.sessions].reverse();$('sessionCount').textContent=String(sorted.length);
    const markup=sorted.map(s=>`<button class="session-item ${s.id===store.activeId?'active':''}" data-session="${esc(s.id)}">${icon(s.isDemo?'play':'folder')}<div><strong>${esc(s.title)}</strong><small>${s.isDemo?'DEMO · ':''}${esc(isoDay(s.createdAt))} · ${s.markers.length} marker</small></div></button>`).join('');
    $('sessionList').innerHTML=markup;$('mobileSessionList').innerHTML=markup;
  }
  function renderSpeakers() {
    const s=current(),options=s.speakers.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');
    $('speakerSelect').innerHTML=options;$('speakerSelect').value=s.speaker;
  }
  function renderLists(autoscroll=false) {
    const s=current();$('transcriptCount').textContent=s.segments.length;$('markerCount').textContent=s.markers.length;
    const list=$('transcriptList'),wasNearBottom=list.scrollTop+list.clientHeight>=list.scrollHeight-70;
    const sorted=[...s.segments].sort((a,b)=>a.start-b.start);
    const marked=new Set(s.markers.flatMap(m=>m.segmentIds||[]));
    list.innerHTML=sorted.length?sorted.map(line=>`<article class="transcript-row ${selected.has(line.id)?'selected':''} ${marked.has(line.id)?'marked':''}"><button class="transcript-main" data-segment="${esc(line.id)}" aria-pressed="${selected.has(line.id)}"><span class="line-meta"><strong>${esc(line.speaker||'Voce')}</strong><span>${esc(tcAt(line.start))}</span>${marked.has(line.id)?'<span>●</span>':''}</span><span class="line-text">${esc(line.text)}</span></button><button class="icon-button edit-line" data-edit-segment="${esc(line.id)}" aria-label="Modifica frase">${icon('note')}</button></article>`).join(''):`<div class="empty-state"><div class="empty-glyph">${icon('wave')}</div><h3>Le parole passano.<br>I momenti restano.</h3><p>${active?'Sto aspettando la prima frase. Puoi già segnare un momento o scrivere una nota.':'Avvia la sessione per trascrivere, oppure aggiungi una nota o un file SRT.'}</p><button class="text-button import-button">Importa una trascrizione ${icon('arrow')}</button></div>`;
    if(interimText){const row=document.createElement('div');row.className='transcript-row interim';const text=document.createElement('span');text.className='line-text';text.textContent=interimText;row.append(text);list.append(row);}
    if(autoscroll&&wasNearBottom)list.scrollTop=list.scrollHeight;
    $('markerList').innerHTML=s.markers.length?[...s.markers].sort((a,b)=>a.start-b.start).map(m=>{const cat=catFor(m.category);return `<article class="marker-row"><span class="marker-dot" style="--dot:${cat.dot}"></span><div><strong>${esc(m.name)}</strong><p>${esc(m.note||'Momento segnato durante la ripresa.')}</p><span class="line-meta">${esc(tcAt(m.start))} → ${esc(tcAt(m.end))} · ${(m.end-m.start).toFixed(1)}s</span></div><button class="icon-button" data-edit-marker="${esc(m.id)}" aria-label="Modifica marker">${icon('note')}</button></article>`;}).join(''):`<div class="empty-state"><div class="empty-glyph">${icon('flag')}</div><h3>Il prossimo momento<br>potrebbe essere quello.</h3><p>Usa un pulsante colorato per segnare gli ultimi secondi, o seleziona le frasi che vuoi tenere.</p></div>`;
    $('selectionBar').hidden=!selected.size;$('selectionText').textContent=`${selected.size} ${selected.size===1?'frase selezionata':'frasi selezionate'}`;
    $('markScope').textContent=selected.size?'Frasi selezionate':'Segna gli ultimi';
    $$('.segmented button').forEach(b=>{b.classList.toggle('active',Number(b.dataset.lookback)===s.lookback);b.disabled=!!selected.size;});
    $('transcriptList').hidden=activeTab!=='transcript';$('markerList').hidden=activeTab!=='markers';
    $('transcriptTab').classList.toggle('active',activeTab==='transcript');$('markersTab').classList.toggle('active',activeTab==='markers');
    $('transcriptTab').setAttribute('aria-selected',String(activeTab==='transcript'));$('markersTab').setAttribute('aria-selected',String(activeTab==='markers'));
  }
  function render() {
    const s=current();$('sessionTitle').textContent=s.title;$('sessionDate').textContent=isoDay(s.createdAt).toUpperCase();
    $('sessionSubtitle').textContent=s.isDemo?'Una sessione di esempio, tutta da esplorare.':active?'La sessione è in corso. Non perdere il momento.':s.endedAt?`${durationText(s.duration)} di sessione · ${s.markers.length} momenti segnati`:'Cattura le parole. Segna ciò che conta.';
    $('demoBanner').hidden=!s.isDemo;$('recoveryBanner').hidden=!recovery;
    const rate=C.rateInfo(s.fps);$('fpsBadge').textContent=String(rate.rate.toFixed(3)).replace(/\.0+$/,'').replace(/0+$/,'').replace(/\.$/,'');
    // Integer rates must retain their trailing zero (30/50/60).
    if(Number.isInteger(rate.rate))$('fpsBadge').textContent=String(rate.rate);
    $('tcMode').textContent=rate.drop?'DF':'NDF';
    $('clockStatus').classList.toggle('live',active);$('clockStatus').innerHTML='<span></span>'+(active?'IN CORSO':s.isDemo?'DEMO':s.endedAt?'CONCLUSA':preSync?'SYNC OTTICO':'PRONTO');
    document.querySelector('.transport').classList.toggle('live',active);
    $('startButton').hidden=active||!!s.endedAt||s.isDemo||recovery;$('stopButton').hidden=!active;
    $('newAfterEnd').hidden=!s.endedAt&&!s.isDemo;$('speechMode').disabled=active||pendingFlush||recovery;
    $('startButton').disabled=pendingFlush;$('newAfterEnd').disabled=pendingFlush;
    $('speechMode').value=store.prefs.mode;
    $('transportTitle').textContent=pendingFlush?'Completo l’ultima trascrizione…':active?'Sessione in corso · tieni aperta l’app':s.isDemo?'Demo: nessun microfono attivo.':s.endedAt?'Sessione salvata. Pronta per il montaggio.':recovery?'Sessione da recuperare.':'Pronto quando lo sei tu.';
    $('transportHint').textContent=s.endedAt?'Esporta i marker e una copia di sicurezza.':'Il timecode parte con la sessione.';
    $('transcriptFootnote').textContent=store.prefs.mode==='native'?'Tempi delle frasi stimati · correggibili dopo la ripresa.':'Seleziona le frasi per creare un marker preciso al passaggio.';
    if($('syncSummary'))$('syncSummary').textContent=s.sync?`Sync ottico · ${new Date(s.sync.at).toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit'})}`:preSync?'Timecode letto dalla camera':useWallClock?'Ora del telefono all’avvio':'Riferimento impostato a mano';
    renderSessions();renderSpeakers();renderLists();displayTC();
  }
  function setSpeech(state,message,retry=false) {
    speechState=state;$('speechStatus').textContent=message;$('speechBar').classList.toggle('listening',state==='listening'||state==='processing');$('speechBar').classList.toggle('problem',state==='error'||state==='suspended');$('speechRetry').hidden=!retry;
    if(!['loading'].includes(state))$('modelProgress').hidden=true;
  }
  function addSegment(session,data) {
    if(!data.text?.trim())return;
    const start=Math.max(0,Number(data.start)||0),end=Math.max(start+1/C.rateInfo(session.fps).rate,Number(data.end)||start+.1);
    session.segments.push({id:uid(),start,end,text:data.text.trim(),speaker:data.speaker||session.speaker});
    session.markers.filter(m=>m.autoNote).forEach(m=>{const lines=session.segments.filter(l=>l.end>m.start&&l.start<m.end).sort((a,b)=>a.start-b.start);m.segmentIds=lines.map(l=>l.id);m.note=lines.map(l=>l.text).join(' ');});
    if(!session.startedAt)session.duration=Math.max(session.duration,end);
    persist();if(session.id===store.activeId)renderLists(true);
  }
  function startNative(session) {
    if(!active)return;
    const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!Speech){setSpeech('error','Riconoscimento vocale non disponibile qui. Prova Safari, Whisper locale o le note.',false);return;}
    nativeAllowed=true;speechSuspended=false;clearTimeout(restartTimer);
    const run=++nativeRun,recognition=new Speech();native=recognition;
    recognition.lang=session.language;recognition.continuous=true;recognition.interimResults=true;recognition.maxAlternatives=1;
    let utteranceStart=null,utteranceSpeaker=session.speaker,lastFinal=elapsed(),finalized=new Set(),fatal=false;
    recognition.onstart=()=>{if(run!==nativeRun)return;setSpeech('listening','In ascolto · riconoscimento del browser');};
    recognition.onspeechstart=()=>{utteranceStart=elapsed();utteranceSpeaker=session.speaker;};
    recognition.onresult=event=>{
      if(run!==nativeRun || session.id!==store.activeId)return;
      let interim='';
      for(let i=event.resultIndex;i<event.results.length;i++){
        const result=event.results[i],text=result[0]?.transcript?.trim();if(!text)continue;
        const end=elapsed(),estimated=Math.max(lastFinal,end-Math.max(.7,text.split(/\s+/).length/2.5));
        if(result.isFinal && !finalized.has(i)){
          finalized.add(i);const start=Math.min(end,Math.max(0,utteranceStart??estimated));
          addSegment(session,{start,end:Math.max(end,start+.04),text,speaker:utteranceSpeaker});lastFinal=end;utteranceStart=null;utteranceSpeaker=session.speaker;
        }else if(!result.isFinal){if(utteranceStart===null){utteranceStart=estimated;utteranceSpeaker=session.speaker;}interim+=text+' ';}
      }
      interimText=interim.trim();renderLists(true);
    };
    recognition.onerror=event=>{
      if(run!==nativeRun)return;const kind=event.error;
      if(kind==='aborted'&&!nativeAllowed)return;
      if(kind==='no-speech')return;
      fatal=true;nativeAllowed=false;
      const msgs={'not-allowed':'Microfono o riconoscimento non autorizzato. Controlla i permessi di Safari.','service-not-allowed':'Il servizio vocale non è disponibile qui. Prova direttamente in Safari.','audio-capture':'Microfono non disponibile. Chiudi le altre app che lo usano.','network':'Connessione al servizio vocale interrotta. Note e marker restano attivi.','language-not-supported':'Lingua non supportata dal servizio vocale di questo browser.'};
      setSpeech('error',msgs[kind]||'Ascolto interrotto dal browser. Puoi riattivarlo o scrivere note.',active);
    };
    recognition.onend=()=>{
      if(nativeStopResolve){nativeStopResolve();nativeStopResolve=null;}
      if(run!==nativeRun)return;native=null;interimText='';renderLists();
      if(!active||!nativeAllowed||speechSuspended||fatal)return;
      lastNativeEnd=lastNativeEnd.filter(t=>Date.now()-t<15000);lastNativeEnd.push(Date.now());
      if(lastNativeEnd.length>4){nativeAllowed=false;setSpeech('error','Il browser interrompe l’ascolto. Premi Riattiva oppure prova Safari o Whisper.',true);return;}
      setSpeech('processing','Ricollego l’ascolto…');restartTimer=setTimeout(()=>{if(active&&nativeAllowed)startNative(session);},550);
    };
    try{recognition.start();setSpeech('loading','Attendo il microfono…');}catch(e){nativeAllowed=false;setSpeech('error','Non riesco ad avviare l’ascolto. Riprova in Safari.',true);}
  }
  async function startLocal(session) {
    if(!window.RamblaLocalASR){setSpeech('error','Modulo locale non disponibile.',false);return;}
    const token=++localGeneration,sessionId=session.id;let localProblem='';
    setSpeech('loading','Preparo l’ascolto locale…');
    if(local){const previous=local;local=null;await previous.destroy();}
    if(token!==localGeneration||!active||speechSuspended||current()?.id!==sessionId)return;
    local=new window.RamblaLocalASR({
      onStatus:info=>{
        if(current()?.id!==sessionId||token!==localGeneration)return;
        if(info.state==='stopped'&&active&&!pendingFlush){setSpeech('error',localProblem||'Ascolto locale fermo. Premi Riattiva per riprendere.',true);return;}
        if(info.state==='loading'){$('modelProgress').hidden=false;const p=$('modelProgress').querySelector('progress');if(Number.isFinite(info.progress))p.value=info.progress;else p.removeAttribute('value');$('modelProgress').querySelector('span').textContent=info.message;}
        setSpeech(info.state,info.message,info.state==='error'&&active);
        if(info.state==='loading')$('modelProgress').hidden=false;
      },
      onSegment:segment=>{const found=store.sessions.find(s=>s.id===sessionId);const voice=[...speakerHistory].reverse().find(event=>event.start<=segment.start)?.speaker;if(found)addSegment(found,{...segment,speaker:voice||found.speaker});},
      onError:error=>{if(error.name==='AbortError')return;if(current()?.id===sessionId&&token===localGeneration){localProblem=error.message||'Il riconoscimento locale si è interrotto.';setSpeech('error',localProblem,active);}}
    });
    const engine=local;
    try{await engine.start({language:session.language.split('-')[0],getElapsed:elapsed});if(token!==localGeneration||!active||speechSuspended){await engine.stop({flush:true});}}
    catch(e){if(e.name!=='AbortError'&&token===localGeneration&&active)setSpeech('error',e.message||'Whisper non è disponibile su questo dispositivo.',true);}
  }
  async function startSpeech() {
    const s=current();if(store.prefs.mode==='native')startNative(s);
    else if(store.prefs.mode==='local')await startLocal(s);
    else setSpeech('idle','Solo marker · nessun microfono attivo');
  }
  async function requestWake() {
    if(!active||document.visibilityState!=='visible')return;
    try{if(navigator.wakeLock&&!wake){wake=await navigator.wakeLock.request('screen');wake.addEventListener('release',()=>{wake=null;});}}catch(e){ /* UI already instructs to keep screen awake. */ }
  }
  function clockTC(d,fps) {const rate=C.rateInfo(fps);let f=Math.min(rate.nominal-1,Math.floor(d.getMilliseconds()/1000*rate.nominal));if(rate.drop&&d.getMinutes()%10!==0&&d.getSeconds()===0)f=Math.max(f,rate.nominal===60?4:2);return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}${rate.drop?';':':'}${String(f).padStart(2,'0')}`;}
  function startSession(resume=false) {
    if(active||pendingFlush)return;
    const s=current();if(s.isDemo||s.endedAt)return;
    if(!resume){
      if(preSync)s.startTC=C.formatTC(preSync.frames+C.secondsToFrames((liveClock()-preSync.capturedAt)/1000,s.fps),s.fps);
      if(useWallClock)s.startTC=clockTC(new Date(),s.fps);
      s.startedAt=Date.now();s.duration=0;clockBase=0;
    }else clockBase=Math.max(s.duration,(Date.now()-s.startedAt)/1000);
    clockPerf=liveClock();active=true;recovery=false;preSync=null;selected.clear();lastNativeEnd=[];speechSuspended=false;
    speakerHistory=[{start:0,speaker:s.speaker}];
    $('visibilityBanner').hidden=true;persist();render();requestWake();startSpeech();
  }
  async function endSession() {
    if(!active)return;
    const s=current();s.duration=elapsed();s.endedAt=Math.max(s.startedAt||0,Date.now());active=false;nativeAllowed=false;pendingFlush=true;localGeneration++;
    clearTimeout(restartTimer);persist();render();
    if(wake){try{await wake.release();}catch{}wake=null;}
    if(native){await new Promise(resolve=>{const timer=setTimeout(()=>{nativeStopResolve=null;resolve();},2500);nativeStopResolve=()=>{clearTimeout(timer);resolve();};try{native.stop();}catch{clearTimeout(timer);nativeStopResolve=null;resolve();}});}
    if(local){try{await local.stop({flush:true});}catch(e){notify('Chiusura trascrizione: '+e.message);}}
    pendingFlush=false;interimText='';setSpeech('idle','Sessione conclusa · trascrizione modificabile');persist();render();notify('Sessione salvata. Esporta anche il backup JSON.');
  }
  function selectSession(id) {
    if(active||pendingFlush){notify('Termina prima la sessione in corso.');return;}
    const s=store.sessions.find(s=>s.id===id);if(!s)return;
    store.activeId=id;selected.clear();interimText='';preSync=null;useWallClock=false;activeTab='transcript';recovery=!!(s.startedAt&&!s.endedAt&&!s.isDemo);setSpeech('idle','Microfono spento');persist();render();$('sessionsDialog').close();
  }
  function newSession() {
    if(active||pendingFlush){notify('Termina prima la sessione in corso.');return;}
    const s=makeSession();store.sessions.push(s);store.activeId=s.id;selected.clear();preSync=null;useWallClock=false;recovery=false;activeTab='transcript';interimText='';persist();render();$('sessionsDialog').close();openSettings(true);
  }
  function mark(categoryId) {
    const s=current(),cat=catFor(categoryId);let start,end,note,ids=[];
    const lines=s.segments.filter(line=>selected.has(line.id)).sort((a,b)=>a.start-b.start);
    if(lines.length){start=Math.min(...lines.map(l=>l.start));end=Math.max(...lines.map(l=>l.end));note=lines.map(l=>l.text).join(' ');ids=lines.map(l=>l.id);}
    else{
      if(!active){notify(s.endedAt||s.isDemo?'Seleziona una frase o aggiungi una nota con i suoi tempi.':'Avvia la sessione per segnare gli ultimi secondi.');return;}
      end=elapsed();start=Math.max(0,end-s.lookback);end=Math.max(end,start+1/C.rateInfo(s.fps).rate);
      const matching=s.segments.filter(l=>l.end>start&&l.start<end);note=matching.map(l=>l.text).join(' ');ids=matching.map(l=>l.id);
    }
    const marker={id:uid(),start,end,name:cat.name,note,color:cat.color,category:cat.id,segmentIds:ids,autoNote:!lines.length};s.markers.push(marker);selected.clear();persist();renderLists();renderSessions();
    if(navigator.vibrate)navigator.vibrate(20);notify(`${cat.name} · ${tcAt(start)} · ${(end-start).toFixed(1)}s`,()=>{s.markers=s.markers.filter(m=>m.id!==marker.id);persist();render();});
  }
  function openSettings(isNew=false) {
    newSettings=isNew;const s=current(),locked=active||recovery||s.isDemo;
    $('settingsTitle').value=s.title;$('settingsFps').value=s.fps;$('settingsLanguage').value=s.language;$('settingsTC').value=s.startTC;$('settingsSpeakers').value=s.speakers.join(', ');
    $('settingsFps').disabled=locked;$('settingsTC').disabled=locked;$('useClock').disabled=locked;$('settingsLanguage').disabled=active;$('clockLocked').hidden=!locked;$('deleteSession').hidden=active||pendingFlush||isNew;
    showError('settingsError','');$('settingsDialog').showModal();
  }
  function saveSettings(event) {
    event.preventDefault();const s=current();
    try{
      const title=$('settingsTitle').value.trim();if(!title)throw Error('Dai un nome alla sessione.');
      if(!active&&!recovery&&!s.isDemo){const fps=$('settingsFps').value;const tc=C.formatTC(C.parseTC($('settingsTC').value,fps),fps);if(s.fps!==fps||s.startTC!==tc){preSync=null;delete s.sync;}s.fps=fps;s.startTC=tc;}
      const speakers=[...new Set($('settingsSpeakers').value.split(',').map(x=>x.trim()).filter(Boolean))].slice(0,12);if(!speakers.length)throw Error('Inserisci almeno il nome di una voce.');
      s.title=title;s.language=$('settingsLanguage').value;s.speakers=speakers;if(!speakers.includes(s.speaker))s.speaker=speakers[0];
      persist();render();$('settingsDialog').close();if(newSettings)notify('Sessione pronta. Puoi sincronizzare il timecode dalla camera.');
    }catch(e){showError('settingsError',e.message);}
  }
  function openNote(type=null,id=null) {
    const s=current();noteEdit=type&&id?{type,id}:null;
    const item=type==='segment'?s.segments.find(l=>l.id===id):type==='marker'?s.markers.find(m=>m.id===id):null;
    const chosen=s.segments.filter(l=>selected.has(l.id));
    const end=chosen.length?Math.max(...chosen.map(l=>l.end)):elapsed();
    const start=chosen.length?Math.min(...chosen.map(l=>l.start)):Math.max(0,end-s.lookback);
    $('noteHeading').textContent=type==='segment'?'Correggi la frase.':type==='marker'?'Modifica il marker.':'Aggiungi una nota.';
    $('noteText').value=item?(item.text??item.note??''):chosen.map(l=>l.text).join(' ');
    const formStart=item?.start??start;
    $('noteStart').value=formStart.toFixed(3);$('noteEnd').value=Math.max(item?.end??end,formStart+1/C.rateInfo(s.fps).rate).toFixed(3);
    $('noteCategory').value=catFor(item?.category).id;$('noteCategory').disabled=type==='segment';
    $('noteSpeaker').innerHTML=s.speakers.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');$('noteSpeaker').value=item?.speaker||s.speaker;
    $('noteTranscriptLabel').hidden=!!type;$('noteTranscript').checked=true;$('deleteNote').hidden=!type;
    showError('noteError','');$('noteDialog').showModal();
  }
  function saveNote(event) {
    event.preventDefault();const s=current();
    try{
      const text=$('noteText').value.trim(),start=Number($('noteStart').value),end=Number($('noteEnd').value);if(!text)throw Error('Scrivi il testo della nota.');
      if(!Number.isFinite(start)||!Number.isFinite(end)||start<0||end<=start)throw Error('Usa un inizio positivo o zero e una fine successiva.');
      if(end>86400)throw Error('La durata massima gestita è 24 ore.');
      const cat=catFor($('noteCategory').value),speaker=$('noteSpeaker').value;
      if(noteEdit?.type==='segment'){
        const line=s.segments.find(l=>l.id===noteEdit.id);Object.assign(line,{start,end,text,speaker});
      }else if(noteEdit?.type==='marker'){
        const m=s.markers.find(m=>m.id===noteEdit.id);Object.assign(m,{start,end,note:text,name:cat.name,category:cat.id,color:cat.color,autoNote:false});
      }else{
        const ids=[];if($('noteTranscript').checked){const seg={id:uid(),start,end,text,speaker};s.segments.push(seg);ids.push(seg.id);}
        s.markers.push({id:uid(),start,end,name:cat.name,note:text,color:cat.color,category:cat.id,segmentIds:ids});
      }
      if(!active)s.duration=Math.max(s.duration,end);selected.clear();persist();render();$('noteDialog').close();notify('Nota salvata.');
    }catch(e){showError('noteError',e.message);}
  }
  function deleteNote() {
    const s=current(),kind=noteEdit?.type;if(!kind)return;
    const key=kind==='segment'?'segments':'markers',item=s[key].find(x=>x.id===noteEdit.id),oldMarkers=JSON.parse(JSON.stringify(s.markers));
    s[key]=s[key].filter(x=>x.id!==noteEdit.id);if(kind==='segment')s.markers.forEach(m=>m.segmentIds=m.segmentIds.filter(id=>id!==item.id));
    selected.delete(item.id);persist();render();$('noteDialog').close();notify(kind==='segment'?'Frase eliminata.':'Marker eliminato.',()=>{s[key].push(item);if(kind==='segment')s.markers=oldMarkers;persist();render();});
  }
  function openExport() {
    if(pendingFlush){notify('Attendi l’ultima trascrizione: poi potrai esportare la sessione completa.');return;}
    const s=current();if(active)s.duration=elapsed();
    $('exportSummary').textContent=`${s.title} · ${s.markers.length} marker · ${s.segments.length} ${s.segments.length===1?'frase':'frasi'} · ${C.rateInfo(s.fps).label}${active?' · copia parziale della sessione in corso':''}`;
    $('exportTC').value=s.startTC;$('exportOffset').value='0';
    const duplicates=s.markers.length-new Set(s.markers.map(m=>C.secondsToFrames(m.start,s.fps))).size;
    $('exportWarning').hidden=!duplicates;$('exportWarning').textContent=duplicates?'Ci sono marker sullo stesso fotogramma. Il file li conserva, ma Resolve potrebbe tenerne uno solo per posizione. Puoi spostarli prima di esportare.':'';
    $('exportDialog').showModal();
  }
  async function saveFile(name,text,type) {
    const file=new File([text],name,{type});
    if(navigator.canShare?.({files:[file]})&&navigator.share){
      try{await navigator.share({files:[file],title:name});return;}catch(e){if(e.name==='AbortError')return;}
    }
    const url=URL.createObjectURL(file),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);notify('File preparato: '+name);
  }
  function exportKind(kind) {
    if(pendingFlush){notify('L’ultima trascrizione è ancora in elaborazione. Attendi prima di esportare.');return;}
    const s=current();if(active)s.duration=elapsed();
    try{
      let body,mime,name=fileSlug(s.title);
      if(kind==='edl'){if(!s.markers.length)throw Error('Aggiungi almeno un marker prima di esportare.');body=C.makeEDL(s,{timelineTC:$('exportTC').value,offsetSeconds:Number($('exportOffset').value)});mime='text/plain;charset=utf-8';name+='-marker.edl';}
      else if(kind==='srt'){if(!s.segments.length)throw Error('Non ci sono ancora frasi da esportare.');body=C.makeSRT(s);mime='application/x-subrip';name+='.srt';}
      else if(kind==='csv'){body=C.makeCSV(s);mime='text/csv;charset=utf-8';name+='-log.csv';}
      else if(kind==='txt'){body=C.makeTXT(s);mime='text/plain;charset=utf-8';name+='-log.txt';}
      else{body=JSON.stringify({app:'RAMBLA Log',version:1,exportedAt:new Date().toISOString(),sessions:[s]},null,2);mime='application/json';name+='-backup.json';}
      saveFile(name,body,mime);
    }catch(e){$('exportWarning').hidden=false;$('exportWarning').textContent=e.message;}
  }
  function importClick() {
    if(active||pendingFlush){notify('Termina prima la sessione per importare nuovi dati.');return;}
    $('importFile').value='';$('importFile').click();
  }
  async function importFile(file) {
    if(!file)return;if(file.size>20*1024*1024){notify('Il file è troppo grande. Usa un backup o SRT inferiore a 20 MB.');return;}
    try{
      const raw=await file.text();let sessions;
      if(file.name.toLowerCase().endsWith('.srt')){
        const segments=C.parseSRT(raw);if(!segments.length)throw Error('Non ho trovato sottotitoli validi nel file.');
        const s=makeSession(file.name.replace(/\.srt$/i,''));s.segments=segments.map(l=>({...l,id:uid(),speaker:l.speaker||s.speaker}));s.duration=Math.max(...segments.map(l=>l.end));s.startedAt=Date.now()-s.duration*1000;s.endedAt=Date.now();sessions=[s];
      }else{
        const parsed=JSON.parse(raw);const rawSessions=Array.isArray(parsed.sessions)?parsed.sessions:parsed.fps?[parsed]:null;
        if(!rawSessions?.length||rawSessions.length>300)throw Error('Il file non contiene sessioni RAMBLA Log valide (massimo 300).');
        sessions=rawSessions.map(s=>C.validateSession(s));
        // Imports are copies; avoid changing existing sessions with identical IDs.
        sessions=sessions.map(s=>({...s,id:uid(),isDemo:false}));
      }
      store.sessions.push(...sessions);selectSession(sessions[0].id);persist();notify(`${sessions.length} ${sessions.length===1?'sessione importata':'sessioni importate'}.`);
    }catch(e){notify('Importazione non riuscita: '+e.message);}
  }
  function loadDemo() {
    if(active||pendingFlush){notify('Termina prima la sessione in corso.');return;}
    let s=store.sessions.find(x=>x.isDemo);
    if(!s){s=makeSession('Intervista · La prima volta');s.isDemo=true;s.duration=53;s.startedAt=Date.now()-53000;s.endedAt=Date.now();s.speakers=['Giulia','Intervistatore'];s.speaker='Giulia';
      s.segments=[{id:uid(),start:3,end:8,text:'Ti ricordi il momento in cui hai capito che volevi partire?',speaker:'Intervistatore'},{id:uid(),start:10,end:19,text:'Sì. Ero seduta alla fermata dell’autobus e ho pensato: conosco questa strada a memoria.',speaker:'Giulia'},{id:uid(),start:21,end:30,text:'Non volevo andare lontano. Volevo solo ricominciare a guardare le cose per la prima volta.',speaker:'Giulia'},{id:uid(),start:34,end:42,text:'Poi sono partita con uno zaino enorme. Dentro, ovviamente, tutto quello che non mi serviva.',speaker:'Giulia'},{id:uid(),start:44,end:52,text:'La parte più bella? Le persone incontrate. Il viaggio alla fine era tutto lì.',speaker:'Giulia'}];
      s.markers=[{id:uid(),start:21,end:30,name:'Highlight',note:s.segments[2].text,color:'Yellow',category:'highlight',segmentIds:[s.segments[2].id]},{id:uid(),start:34,end:42,name:'Divertente',note:s.segments[3].text,color:'Purple',category:'funny',segmentIds:[s.segments[3].id]},{id:uid(),start:44,end:52,name:'Emozione',note:s.segments[4].text,color:'Pink',category:'emotion',segmentIds:[s.segments[4].id]}];store.sessions.push(s);}
    selectSession(s.id);notify('Demo caricata: contenuti di esempio, nessun microfono attivo.');
  }
  function deleteSession() {
    if(active||pendingFlush)return;const s=current();if(!confirm(`Eliminare «${s.title}» da questo dispositivo? Puoi prima esportare un backup.`))return;
    store.sessions=store.sessions.filter(x=>x.id!==s.id);if(!store.sessions.length)store.sessions.push(makeSession());store.activeId=store.sessions.at(-1).id;recovery=false;selected.clear();preSync=null;useWallClock=false;persist();render();$('settingsDialog').close();notify('Sessione eliminata.',()=>{store.sessions.push(s);selectSession(s.id);});
  }
  async function openScanner() {
    if(pendingFlush){notify('Attendi la fine della trascrizione.');return;}
    if(!window.RamblaTimecodeCamera){notify('Lettore timecode non ancora disponibile.');return;}
    const s=current();if(s.isDemo){notify('Crea una sessione reale per sincronizzare la camera.');return;}
    if(s.endedAt){notify('Per leggere il TC corrente crea una nuova sessione. Correggi il riferimento di questa sessione dalle impostazioni.');return;}
    latestReading=null;$('scanReading').textContent='--:--:--:--';$('scanStatus').textContent='Inquadra solo il timecode della camera nel riquadro.';$('scanApply').disabled=true;
    $('scanFps').textContent=C.rateInfo(s.fps).label;$('scanDialog').showModal();
    const token=++scanGeneration;let applying=false;
    scanner=new window.RamblaTimecodeCamera({video:$('scanVideo'),canvas:$('scanCanvas'),
      onStatus:info=>{if(token!==scanGeneration)return;$('scanStatus').textContent=info.message;if(['searching','error','stopped'].includes(info.state)){latestReading=null;$('scanApply').disabled=true;}},
      onReading:reading=>{
        if(token!==scanGeneration)return;latestReading=reading;latestReadingReceivedAt=liveClock();$('scanReading').textContent=reading.timecode||reading.text;
        $('scanApply').disabled=!reading.stable;
        $('scanLock').textContent=reading.stable?'LETTURE COERENTI':'VERIFICO L’AVANZAMENTO';
        if(reading.stable&&$('scanAuto').checked&&!applying){applying=true;applyScan();}
      },
      onError:error=>{if(token!==scanGeneration)return;$('scanStatus').textContent=error.message||'La fotocamera non è disponibile. Controlla i permessi di Safari.';}
    });
    try{await scanner.start({fps:s.fps,roi:scanROI()});}catch(e){if(token===scanGeneration)$('scanStatus').textContent=e.message;}
  }
  function scanROI() {const width=Number($('scanWidth').value)/100,height=Number($('scanHeight').value)/100,y=Number($('scanY').value)/100;return {x:(1-width)/2,y:Math.min(1-height,Math.max(0,y-height/2)),width,height};}
  function updateROI() {const r=scanROI();latestReading=null;$('scanApply').disabled=true;$('scanLock').textContent='VERIFICO L’AVANZAMENTO';$('scanReticle').style.cssText=`left:${r.x*100}%;top:${r.y*100}%;width:${r.width*100}%;height:${r.height*100}%`;scanner?.setROI(r);}
  function applyScan() {
    if(!latestReading?.stable)return;
    if(liveClock()-latestReadingReceivedAt>5000){latestReading=null;$('scanApply').disabled=true;$('scanStatus').textContent='Lettura troppo vecchia: attendo nuovi valori coerenti.';return;}
    const s=current(),reading=latestReading,now=liveClock();
    const nowFrames=reading.frames+C.secondsToFrames((now-reading.capturedAt)/1000,s.fps);
    if(active||s.startedAt){s.startTC=C.formatTC(nowFrames-C.secondsToFrames(elapsed(),s.fps),s.fps);preSync=null;}
    else{preSync={frames:reading.frames,capturedAt:reading.capturedAt};s.startTC=C.formatTC(nowFrames,s.fps);}
    useWallClock=false;s.sync={method:'camera',timecode:C.formatTC(nowFrames,s.fps),at:new Date().toISOString(),readings:3,confidence:reading.confidence};
    persist();render();$('scanDialog').close();notify(`Allineato alla camera: ${C.formatTC(nowFrames,s.fps)}. Il clock prosegue sul telefono.`);
  }
  async function closeScanner() {scanGeneration++;const old=scanner;scanner=null;latestReading=null;try{await old?.stop();}catch{} }
  function bind() {
    $('markerPads').innerHTML=CATEGORIES.map((c,i)=>`<button class="marker-pad" data-category="${c.id}" style="--pad-bg:${c.bg};--pad-border:${c.border};--pad-ink:${c.ink}">${icon(c.icon)}<span>${c.name}</span><span class="shortcut">${i+1}</span></button>`).join('');
    $('settingsFps').innerHTML=C.rates.map(r=>`<option value="${esc(r.id)}">${esc(r.label)}</option>`).join('');
    $('noteCategory').innerHTML=CATEGORIES.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
    document.addEventListener('click',event=>{
      const b=event.target.closest('button');if(!b)return;
      if(b.dataset.session)selectSession(b.dataset.session);
      else if(b.dataset.category)mark(b.dataset.category);
      else if(b.dataset.lookback){current().lookback=Number(b.dataset.lookback);persist();renderLists();}
      else if(b.dataset.segment){const id=b.dataset.segment;if(selected.has(id))selected.delete(id);else selected.add(id);renderLists();}
      else if(b.dataset.editSegment)openNote('segment',b.dataset.editSegment);
      else if(b.dataset.editMarker)openNote('marker',b.dataset.editMarker);
      else if(b.dataset.export)exportKind(b.dataset.export);
      else if(b.classList.contains('new-session'))newSession();
      else if(b.classList.contains('settings-button'))openSettings();
      else if(b.classList.contains('help-button'))$('helpDialog').showModal();
      else if(b.classList.contains('export-button'))openExport();
      else if(b.classList.contains('import-button'))importClick();
      else if(b.classList.contains('demo-button'))loadDemo();
      else if(b.classList.contains('close-dialog'))b.closest('dialog').close();
    });
    $('startButton').onclick=()=>startSession();$('stopButton').onclick=endSession;
    $('speakerSelect').onchange=()=>{current().speaker=$('speakerSelect').value;if(active)speakerHistory.push({start:elapsed(),speaker:current().speaker});persist();};
    $('speechMode').onchange=()=>{store.prefs.mode=$('speechMode').value;persist();render();};
    $('speechRetry').onclick=()=>{if(!active)return;speechSuspended=false;lastNativeEnd=[];setSpeech('loading','Riattivo l’ascolto…');$('visibilityBanner').hidden=true;startSpeech();requestWake();};
    $('transcriptTab').onclick=()=>{activeTab='transcript';renderLists();};$('markersTab').onclick=()=>{activeTab='markers';renderLists();};
    $('clearSelection').onclick=()=>{selected.clear();renderLists();};
    $('manualNoteButton').onclick=()=>openNote();$('manualNoteButton2').onclick=()=>openNote();
    $('settingsForm').onsubmit=saveSettings;$('noteForm').onsubmit=saveNote;$('deleteNote').onclick=deleteNote;$('deleteSession').onclick=deleteSession;
    $('useClock').onclick=()=>{useWallClock=true;preSync=null;$('settingsTC').value=clockTC(new Date(),$('settingsFps').value);notify('Il timecode userà l’ora del telefono al momento di Inizia.');};
    $('settingsTC').oninput=()=>{useWallClock=false;};
    $('sessionsButton').onclick=()=>{$('sessionsDialog').showModal();};
    $('importFile').onchange=e=>importFile(e.target.files[0]);
    $('backupAll').onclick=()=>{if(active)current().duration=elapsed();saveFile('RAMBLA-Log-tutte-le-sessioni.json',JSON.stringify({app:'RAMBLA Log',version:1,exportedAt:new Date().toISOString(),sessions:store.sessions},null,2),'application/json');};
    $('recoverContinue').onclick=()=>startSession(true);$('recoverClose').onclick=()=>{const s=current();s.endedAt=s.startedAt+s.duration*1000;recovery=false;persist();render();};
    if($('syncCameraButton'))$('syncCameraButton').onclick=openScanner;
    if($('scanDialog')){
      $('scanVideo').addEventListener('loadedmetadata',()=>{const v=$('scanVideo');if(v.videoWidth&&v.videoHeight)v.style.aspectRatio=v.videoWidth+'/'+v.videoHeight;});
      $('scanDialog').addEventListener('close',closeScanner);$('scanApply').onclick=applyScan;
      ['scanWidth','scanHeight','scanY'].forEach(id=>$(id).oninput=updateROI);updateROI();
    }
    document.addEventListener('keydown',e=>{if(e.repeat||e.ctrlKey||e.metaKey||e.altKey||/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)||document.querySelector('dialog[open]'))return;const n=Number(e.key);if(n>=1&&n<=6){e.preventDefault();mark(CATEGORIES[n-1].id);}});
    document.addEventListener('visibilitychange',async()=>{
      if(document.hidden){
        persist();if(scanner){$('scanDialog').close();}
        if(active&&store.prefs.mode!=='manual'){
          speechSuspended=true;nativeAllowed=false;localGeneration++;clearTimeout(restartTimer);if(native){try{native.abort();}catch{}}
          if(local){try{await local.stop({flush:true});}catch{}}
          $('visibilityBanner').hidden=false;setSpeech('suspended','Ascolto sospeso. Il timecode continua; premi Riattiva per riprendere.',true);
        }
      }else if(active)requestWake();
    });
    window.addEventListener('pagehide',persist);
    window.addEventListener('online',()=>$('offlineBanner').hidden=true);window.addEventListener('offline',()=>$('offlineBanner').hidden=false);
  }
  function initPWA() {
    if('serviceWorker' in navigator&&location.protocol==='https:'&&!window.RAMBLA_PORTABLE){
      navigator.serviceWorker.register('./sw.js').then(()=>navigator.serviceWorker.ready).then(()=>{$('offlineReady').textContent='App disponibile offline · dati su questo dispositivo';}).catch(()=>{$('offlineReady').textContent='Salvataggio locale · cache offline non disponibile';});
    }
    if(window.RAMBLA_PORTABLE){$('offlineReady').textContent='Copia HTML · per il microfono apri da HTTPS';}
    $('offlineBanner').hidden=navigator.onLine;
  }
  loadStore();bind();render();initPWA();
  setInterval(()=>{displayTC();if(active&&Date.now()-lastSave>4000)persist();},80);
})();
