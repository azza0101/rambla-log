(function () {
  'use strict';
  const C = window.RamblaCore;
  const $ = id => document.getElementById(id);
  const $$ = selector => Array.from(document.querySelectorAll(selector));
  const esc = text => String(text ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icon = name => `<svg class="icon" aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const uid = () => window.crypto?.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2);
  const KEY = 'rambla-log-v1';
  let storageKey=KEY;
  const CATEGORIES = [
    {id:'keep',name:'Da tenere',color:'Green',icon:'check',bg:'#35dec0',border:'#35dec0',ink:'#06281f',dot:'#35dec0'},
    {id:'highlight',name:'Highlight',color:'Yellow',icon:'star',bg:'#f8cf4b',border:'#f8cf4b',ink:'#302404',dot:'#f8cf4b'},
    {id:'funny',name:'Divertente',color:'Purple',icon:'smile',bg:'#ad87ff',border:'#ad87ff',ink:'#24123e',dot:'#ad87ff'},
    {id:'emotion',name:'Emozione',color:'Pink',icon:'heart',bg:'#ff7fab',border:'#ff7fab',ink:'#3c1124',dot:'#ff7fab'},
    {id:'turn',name:'SCARTA',color:'Red',icon:'trash',bg:'#ff6f62',border:'#ff6f62',ink:'#3a100c',dot:'#ff6f62'},
    {id:'check',name:'Da rivedere',color:'Blue',icon:'flag',bg:'#63bbff',border:'#63bbff',ink:'#092638',dot:'#63bbff'}
  ];
  const catFor = id => CATEGORIES.find(c => c.id === id || c.name === id) || CATEGORIES[0];
  let store = {version:1,sessions:[],activeId:null,prefs:{mode:'native'}};
  let active = false, pendingFlush = false, recovery = false, activeTab = 'markers';
  let selected = new Set(), native = null, local = null, wake = null, restartTimer = null;
  let clockPerf = 0, clockBase = 0, preSync = null, captureRangeStart = 0;
  let lastNativeEnd = [], nativeAllowed = false, speechSuspended = false, nativeRun = 0;
  let interimText = '', toastTimer, noteEdit = null, speechState = 'idle', newSettings = false;
  let scanner = null, scanGeneration = 0, latestReading = null, localGeneration=0, latestReadingReceivedAt=0;
  let nativeCapture=null, localCapture=null, flushPromise=null, speechStartTask=null, retryTask=null, speechGeneration=0;
  let wakeRequest=null,wakeGeneration=0;
  let speakerHistory=[];
  let voiceNote=null, voiceGeneration=0, voiceClosing=null;
  const liveClock = () => performance.now();
  const current = () => store.sessions.find(s => s.id === store.activeId);
  const unfinished = s => s && s.startedAt !== null && s.startedAt !== undefined && s.endedAt == null && !s.isDemo;
  const elapsed = () => {
    const s=current();if(!s)return 0;
    if(!unfinished(s))return Math.max(0,s.duration||0);
    // Epoch time survives Safari timer suspension and a complete page reload.
    // The monotonic clock also prevents a backwards device-clock adjustment
    // from moving a live capture backwards within this page.
    // duration can include manually edited transcript ranges. It must never
    // move this clock; only the persisted epoch and capture clock may do that.
    return Math.max(0,(Date.now()-s.startedAt)/1000,s.pausedAt==null?0:(s.pausedAt-s.startedAt)/1000,active?clockBase+(liveClock()-clockPerf)/1000:0);
  };
  const durationText = seconds => { const n = Math.floor(Math.max(0,seconds));return `${Math.floor(n/3600) ? String(Math.floor(n/3600)).padStart(2,'0')+':' : ''}${String(Math.floor(n/60)%60).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`; };
  const isoDay = date => new Date(date).toLocaleDateString('it-IT',{day:'2-digit',month:'short',year:'numeric'});
  const fileSlug = title => String(title).normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,70) || 'rambla-log';
  function makeSession(title) {
    return {id:uid(),title:title || `Riprese · ${new Date().toLocaleDateString('it-IT',{day:'2-digit',month:'short'})}`,createdAt:new Date().toISOString(),startedAt:null,endedAt:null,duration:0,fps:'25',startTC:'01:00:00:00',clockSource:'phone',phoneAnchorMs:null,captureState:'draft',pauseReason:null,pausedAt:null,language:'it-IT',lookback:10,speaker:'Speaker A',speakers:['Speaker A','Speaker B'],segments:[],markers:[],isDemo:false};
  }
  function notify(message,undo) {
    clearTimeout(toastTimer);$('toast').querySelector('span').textContent=message;
    const btn=$('toast').querySelector('button');btn.hidden=!undo;btn.onclick=undo?()=>{undo();$('toast').hidden=true;}:null;
    $('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,undo?8000:5500);
  }
  function showError(id,message) {$(id).hidden=!message;$(id).textContent=message || '';}
  function persist() {
    if(active && current()) current().duration=elapsed();
    try {localStorage.setItem(storageKey,JSON.stringify(store));$('saveState').classList.remove('error');$('saveState').innerHTML='<span></span>Salvato qui';if(!window.ramblaRecoveryData)$('storageWarning').hidden=true;return true;}
    catch(e) {$('saveState').classList.add('error');$('saveState').innerHTML='<span></span>Non salvato';$('storageWarning').hidden=false;$('storageWarning').textContent='Il browser non riesce a salvare questa sessione. I dati sono ancora aperti qui: esporta subito il backup JSON e libera spazio.';return false;}
  }
  function loadStore() {
    let raw;
    try {const fresh=localStorage.getItem(KEY+'-fresh');storageKey=fresh?KEY+'-fresh':KEY;raw=fresh||localStorage.getItem(KEY);}catch(e) {showError('storageWarning','Salvataggio locale non disponibile. Esporta un backup prima di chiudere.');}
    if(raw) {
      try {
        const parsed=JSON.parse(raw);if(parsed.version!==1 || !Array.isArray(parsed.sessions))throw Error('Formato archivio non riconosciuto');
        const sessions=parsed.sessions.map(s=>C.validateSession(s));
        store={version:1,sessions,activeId:parsed.activeId,prefs:{mode:['native','local','manual'].includes(parsed.prefs?.mode)?parsed.prefs.mode:'native'}};
      } catch(e) {
        // Never overwrite a damaged archive without giving the user a recovery copy.
        window.ramblaRecoveryData=raw;
        storageKey=KEY+'-fresh';
        showError('storageWarning','L’archivio locale non è leggibile. Ne conservo una copia recuperabile dal pulsante «Recupera archivio». Le nuove sessioni usano un archivio separato fino al download.');
        const b=document.createElement('button');b.className='button button-small';b.textContent='Recupera archivio';b.onclick=()=>saveFile('RAMBLA-archivio-da-recuperare.json',raw,'application/json');$('storageWarning').append(b);
        // The original remains under KEY; new sessions write to a separate key.
      }
    }
    if(!store.sessions.length){const s=makeSession();store.sessions.push(s);store.activeId=s.id;}
    if(!current())store.activeId=store.sessions[0].id;
    recovery=!!unfinished(current());
    // Recover a recent optical anchor before a session starts. A stale draft
    // must be scanned again, instead of silently treating an old TC as live.
    const s=current();
    if(recovery){
      if(s.captureState!=='paused'){s.captureState='paused';s.pauseReason='recovery';s.pausedAt=Math.max(s.startedAt,Math.min(Date.now(),Math.round(s.startedAt+s.duration*1000)));}
      active=false;speechSuspended=true;
    }
    if(!s.startedAt&&s.sync){const age=(Date.now()-Date.parse(s.sync.at))/1000;if(age>=0&&age<300)preSync={frames:C.parseTC(s.sync.timecode,s.fps)+C.secondsToFrames(age,s.fps),capturedAt:liveClock()};else{delete s.sync;notify('Rileggi il timecode della camera prima di iniziare: il precedente sync è scaduto.');}}
  }
  function phoneTime(epoch) {const d=new Date(epoch);return [d.getHours(),d.getMinutes(),d.getSeconds()].map(value=>String(value).padStart(2,'0')).join(':');}
  function tcAt(seconds,referenceAt=seconds) {
    const s=current();
    if(s.clockSource==='phone')return phoneTime((s.phoneAnchorMs??s.startedAt??Date.now())+seconds*1000);
    return C.formatTC(C.framesAt(s,seconds,{referenceAt}),s.fps);
  }
  function displayTC() {
    const s=current();if(!s)return;
    let tc=tcAt(elapsed());
    if(!s.startedAt&&preSync)tc=C.formatTC(preSync.frames+C.secondsToFrames((liveClock()-preSync.capturedAt)/1000,s.fps),s.fps);
    const markup=s.clockSource==='phone'?esc(!s.startedAt?phoneTime(Date.now()):tc):esc(tc.slice(0,8))+`<span>${tc[8]||':'}${esc(tc.slice(9))}</span>`;
    if($('timecode').innerHTML!==markup)$('timecode').innerHTML=markup;
    const duration=durationText(elapsed())+' trascorsi';if($('duration').textContent!==duration)$('duration').textContent=duration;
  }
  function renderSessions() {
    const sorted=[...store.sessions].reverse();$('sessionCount').textContent=String(sorted.length);
    const markup=sorted.map(s=>`<button class="session-item ${s.id===store.activeId?'active':''}" data-session="${esc(s.id)}">${icon(s.isDemo?'play':'folder')}<div><strong>${esc(s.title)}</strong><small>${s.isDemo?'DEMO · ':''}${esc(isoDay(s.createdAt))} · ${s.markers.length} marker</small></div></button>`).join('');
    $('sessionList').innerHTML=markup;$('mobileSessionList').innerHTML=markup;
  }
  function renderSpeakers() {
    const s=current(),options=s.speakers.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');
    $('speakerSelect').innerHTML=options;$('speakerSelect').value=s.speaker;
  }
  function renderLists(autoscroll=false) {
    const s=current();$('transcriptCount').textContent=s.segments.length;$('markerCount').textContent=s.markers.length;
    if($('logMarkerCount'))$('logMarkerCount').textContent=s.markers.length;
    if($('logNoteCount'))$('logNoteCount').textContent=s.segments.length+s.markers.filter(m=>m.note?.trim()&&!m.segmentIds?.length).length;
    const list=$('transcriptList'),wasNearBottom=list.scrollTop+list.clientHeight>=list.scrollHeight-70;
    const sorted=[...s.segments].sort((a,b)=>a.start-b.start);
    const marked=new Set(s.markers.flatMap(m=>m.segmentIds||[]));
    list.innerHTML=sorted.length?sorted.map(line=>`<article class="transcript-row ${selected.has(line.id)?'selected':''} ${marked.has(line.id)?'marked':''}"><button class="transcript-main" data-segment="${esc(line.id)}" aria-pressed="${selected.has(line.id)}"><span class="line-meta"><strong>${esc(line.speaker||'Voce')}</strong><span>${esc(tcAt(line.start))}</span>${marked.has(line.id)?'<span>●</span>':''}</span><span class="line-text">${esc(line.text)}</span></button><button class="icon-button edit-line" data-edit-segment="${esc(line.id)}" aria-label="Modifica frase">${icon('note')}</button></article>`).join(''):`<div class="empty-state"><div class="empty-glyph">${icon('wave')}</div><h3>Nessuna trascrizione</h3><p>${active?'La trascrizione apparirà qui. Marker e note vocali sono nel registro dei marker.':'Avvia la sessione per trascrivere, oppure aggiungi una nota o un file SRT.'}</p><button class="text-button import-button">Importa una trascrizione ${icon('arrow')}</button></div>`;
    if(interimText){const row=document.createElement('div');row.className='transcript-row interim';const text=document.createElement('span');text.className='line-text';text.textContent=interimText;row.append(text);list.append(row);}
    if(autoscroll&&wasNearBottom)list.scrollTop=list.scrollHeight;
    $('markerList').innerHTML=s.markers.length?[...s.markers].sort((a,b)=>a.start-b.start).map(m=>{const cat=catFor(m.category);return `<article class="marker-row"><span class="marker-dot" style="--dot:${cat.dot}"></span><div><strong>${esc(m.name)}</strong><p>${esc(m.note||'Momento segnato durante la ripresa.')}</p><span class="line-meta">${esc(tcAt(m.start))} → ${esc(tcAt(m.end,m.start))} · ${(m.end-m.start).toFixed(1)}s</span></div><button class="icon-button" data-edit-marker="${esc(m.id)}" aria-label="Modifica marker">${icon('note')}</button></article>`;}).join(''):`<div class="empty-state"><div class="empty-glyph">${icon('flag')}</div><h3>Nessun marker</h3><p>Usa un pulsante colorato per segnare gli ultimi secondi, o seleziona le frasi che vuoi tenere.</p></div>`;
    $('selectionBar').hidden=!selected.size;$('selectionText').textContent=`${selected.size} ${selected.size===1?'frase selezionata':'frasi selezionate'}`;
    $('markScope').textContent=selected.size?'Frasi selezionate':'Segna gli ultimi';
    $$('.segmented button').forEach(b=>{b.classList.toggle('active',Number(b.dataset.lookback)===s.lookback);b.disabled=!!selected.size;});
    $$('.marker-pad').forEach(b=>{b.disabled=pendingFlush||(!active&&unfinished(s)&&!selected.size);});
    $('transcriptList').hidden=activeTab!=='transcript';$('markerList').hidden=activeTab!=='markers';
    $('transcriptTab').classList.toggle('active',activeTab==='transcript');$('markersTab').classList.toggle('active',activeTab==='markers');
    $('transcriptTab').setAttribute('aria-selected',String(activeTab==='transcript'));$('markersTab').setAttribute('aria-selected',String(activeTab==='markers'));
  }
  function render() {
    const s=current(),paused=!active&&unfinished(s),phone=s.clockSource==='phone',locked=active||paused||pendingFlush||s.isDemo||!!s.tcAnchors?.length;
    document.body.dataset.clockSource=phone?'phone':'timecode';
    $('sessionTitle').textContent=s.title;$('sessionDate').textContent=isoDay(s.createdAt).toUpperCase();
    $('sessionSubtitle').textContent=s.isDemo?'Una sessione di esempio, tutta da esplorare.':active?'Sessione in corso.':paused?'Sessione in pausa · riprendi quando sei pronto.':s.endedAt?`${durationText(s.duration)} di sessione · ${s.markers.length} momenti segnati`:'Sessione pronta.';
    $('demoBanner').hidden=!s.isDemo;$('recoveryBanner').hidden=!recovery;
    const rate=C.rateInfo(s.fps);$('fpsBadge').textContent=String(rate.rate.toFixed(3)).replace(/\.0+$/,'').replace(/0+$/,'').replace(/\.$/,'');
    // Integer rates must retain their trailing zero (30/50/60).
    if(Number.isInteger(rate.rate))$('fpsBadge').textContent=String(rate.rate);
    $('tcMode').textContent=rate.drop?'DF':'NDF';
    $('clockStatus').classList.toggle('live',active);$('clockStatus').classList.toggle('paused',paused);$('clockStatus').innerHTML='<span></span>'+(active?'IN CORSO':paused?'IN PAUSA':s.isDemo?'DEMO':s.endedAt?'CONCLUSA':preSync?'SYNC OTTICO':'PRONTO');
    if($('clockCaption'))$('clockCaption').textContent=phone?'ORA IPHONE':'TIMECODE';
    if(document.querySelector('.clock-fps'))document.querySelector('.clock-fps').hidden=phone;
    for(const [id,source] of [['clockPhoneButton','phone'],['clockTimecodeButton','timecode']]){
      const button=$(id);if(!button)continue;const chosen=(s.clockSource||'timecode')===source;
      button.classList.toggle('active',chosen);button.setAttribute('aria-pressed',String(chosen));button.disabled=locked;
    }
    if($('clockSourceHint'))$('clockSourceHint').textContent=phone?'Ore, minuti e secondi del telefono. Il riferimento si fissa quando inizi.':s.sync?'Riferimento letto dalla camera. Gli export usano il frame rate scelto.':'Imposta il TC iniziale o leggilo dalla camera prima di iniziare.';
    document.querySelector('.transport').classList.toggle('live',active);document.querySelector('.transport').classList.toggle('paused',paused);
    $('startButton').hidden=active||paused||!!s.endedAt||s.isDemo||recovery;$('stopButton').hidden=!active&&!paused;
    if($('pauseButton')){$('pauseButton').hidden=!active;$('pauseButton').disabled=false;}
    if($('resumeButton')){$('resumeButton').hidden=!paused;$('resumeButton').disabled=pendingFlush||!!voiceClosing;}
    $('stopButton').disabled=pendingFlush;
    $('newAfterEnd').hidden=!s.endedAt&&!s.isDemo;$('speechMode').disabled=active||pendingFlush;
    $('startButton').disabled=pendingFlush;$('newAfterEnd').disabled=pendingFlush;
    $('speechMode').value=store.prefs.mode;
    $('transportTitle').textContent=pendingFlush?'Completo l’ultima trascrizione…':active?'Sessione in corso · tieni aperta l’app':paused?s.pauseReason==='background'?'In pausa · sei uscito dall’app':recovery?'Sessione recuperata · pronta a riprendere':'Sessione in pausa':s.isDemo?'Demo: nessun microfono attivo.':s.endedAt?'Sessione salvata. Pronta per il montaggio.':'Pronto quando lo sei tu.';
    $('transportHint').textContent=s.endedAt?'Esporta i marker e una copia di sicurezza.':paused?'Il riferimento orario continua. Microfono e marker rapidi ripartono con Riprendi.':phone?'Segni i momenti con l’ora del telefono.':'Il timecode parte con la sessione.';
    $('transcriptFootnote').textContent=store.prefs.mode==='native'?'Tempi delle frasi stimati · correggibili dopo la ripresa.':'Seleziona le frasi per creare un marker preciso al passaggio.';
    if($('syncSummary'))$('syncSummary').textContent=phone?'Ora del telefono · HH:MM:SS':s.sync?`${s.tcAnchors?.length?'Ultimo allineamento':'Sync ottico'} · ${new Date(s.sync.at).toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}`:preSync?'Timecode letto dalla camera':'Riferimento impostato a mano';
    if($('syncCameraButton')){$('syncCameraButton').hidden=phone;$('syncCameraButton').disabled=pendingFlush||(phone&&unfinished(s));$('syncCameraButton').innerHTML=icon('camera')+(s.startedAt&&!s.endedAt?'Aggiorna timecode':'Leggi timecode');}
    $('recoverContinue').disabled=pendingFlush;$('recoverClose').disabled=pendingFlush;
    $('visibilityBanner').hidden=!(paused&&s.pauseReason==='background');
    renderSessions();renderSpeakers();renderLists();displayTC();
  }
  function setSpeech(state,message,retry=false) {
    speechState=state;$('speechStatus').textContent=message;$('speechBar').classList.toggle('listening',state==='listening'||state==='processing');$('speechBar').classList.toggle('problem',state==='error'||state==='suspended');$('speechRetry').hidden=!retry;
    if(!['loading'].includes(state))$('modelProgress').hidden=true;
  }
  function addSegment(session,data) {
    if(!data.text?.trim())return;
    const start=Math.max(0,Number(data.start)||0),end=Math.max(start+1/C.rateInfo(session.fps).rate,Number(data.end)||start+.1);
    session.segments.push({id:uid(),start,end,text:data.text.trim(),speaker:data.speaker||session.speaker});
    session.markers.filter(m=>m.autoNote).forEach(m=>{const lines=session.segments.filter(l=>l.end>m.start&&l.start<m.end).sort((a,b)=>a.start-b.start);m.segmentIds=lines.map(l=>l.id);m.note=lines.map(l=>l.text).join(' ');});
    if(!session.startedAt)session.duration=Math.max(session.duration,end);
    persist();if(session.id===store.activeId)renderLists(true);
  }
  function captureSegment(capture,data) {
    if(!capture?.acceptResults)return;
    const session=store.sessions.find(s=>s.id===capture.sessionId);if(!session)return;
    const limit=capture.end??elapsed(),frame=1/C.rateInfo(session.fps).rate;
    const start=Math.max(capture.start,Math.min(Number(data.start)||0,Math.max(capture.start,limit-frame)));
    const end=Math.min(limit,Math.max(start+frame,Number(data.end)||start+frame));
    if(end<=start)return;
    addSegment(session,{...data,start,end});
  }
  function startNative(session) {
    if(!active||pendingFlush||speechSuspended||document.hidden)return;
    const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!Speech){setSpeech('error','Riconoscimento vocale non disponibile qui. Prova Safari, Whisper locale o le note.',false);return;}
    nativeAllowed=true;speechSuspended=false;clearTimeout(restartTimer);
    const run=++nativeRun,recognition=new Speech();native=recognition;
    const capture={engine:recognition,sessionId:session.id,start:elapsed(),end:null,acceptResults:true,finish:null};nativeCapture=capture;
    recognition.lang=session.language;recognition.continuous=true;recognition.interimResults=true;recognition.maxAlternatives=1;
    let utteranceStart=null,utteranceSpeaker=session.speaker,lastFinal=capture.start,finalized=new Set(),fatal=false;
    recognition.onstart=()=>{if(run!==nativeRun||!active||!capture.acceptResults||capture.end!==null||speechSuspended||document.hidden){try{recognition.abort();}catch{}return;}setSpeech('listening','In ascolto · riconoscimento del browser');};
    recognition.onspeechstart=()=>{if(!capture.acceptResults||capture.end!==null)return;utteranceStart=elapsed();utteranceSpeaker=session.speaker;};
    recognition.onresult=event=>{
      if(run!==nativeRun||!capture.acceptResults||session.id!==store.activeId)return;
      let interim='';
      for(let i=event.resultIndex;i<event.results.length;i++){
        const result=event.results[i],text=result[0]?.transcript?.trim();if(!text)continue;
        const end=capture.end??elapsed(),estimated=Math.max(lastFinal,end-Math.max(.7,text.split(/\s+/).length/2.5));
        if(result.isFinal && !finalized.has(i)){
          finalized.add(i);const start=Math.min(end,Math.max(0,utteranceStart??estimated));
          captureSegment(capture,{start,end,text,speaker:utteranceSpeaker});lastFinal=end;utteranceStart=null;utteranceSpeaker=session.speaker;
        }else if(!result.isFinal&&capture.end===null){if(utteranceStart===null){utteranceStart=estimated;utteranceSpeaker=session.speaker;}interim+=text+' ';}
      }
      interimText=interim.trim();renderLists(true);
    };
    recognition.onerror=event=>{
      if(run!==nativeRun||!capture.acceptResults||capture.end!==null||!active)return;const kind=event.error;
      if(kind==='aborted'&&!nativeAllowed)return;
      if(kind==='no-speech')return;
      fatal=true;nativeAllowed=false;
      const msgs={'not-allowed':'Microfono o riconoscimento non autorizzato. Controlla i permessi di Safari.','service-not-allowed':'Il servizio vocale non è disponibile qui. Prova direttamente in Safari.','audio-capture':'Microfono non disponibile. Chiudi le altre app che lo usano.','network':'Connessione al servizio vocale interrotta. Note e marker restano attivi.','language-not-supported':'Lingua non supportata dal servizio vocale di questo browser.'};
      setSpeech('error',msgs[kind]||'Ascolto interrotto dal browser. Puoi riattivarlo o scrivere note.',active);
    };
    recognition.onend=()=>{
      if(capture.finish){capture.finish();return;}
      capture.acceptResults=false;
      if(run!==nativeRun)return;native=null;nativeCapture=null;interimText='';renderLists();
      if(!active||!nativeAllowed||speechSuspended||fatal)return;
      lastNativeEnd=lastNativeEnd.filter(t=>Date.now()-t<15000);lastNativeEnd.push(Date.now());
      if(lastNativeEnd.length>4){nativeAllowed=false;setSpeech('error','Il browser interrompe l’ascolto. Premi Riattiva oppure prova Safari o Whisper.',true);return;}
      setSpeech('processing','Ricollego l’ascolto…');restartTimer=setTimeout(()=>{if(active&&nativeAllowed)startNative(session);},550);
    };
    try{setSpeech('loading','Attendo il microfono…');recognition.start();}catch(e){capture.acceptResults=false;native=null;nativeCapture=null;nativeAllowed=false;setSpeech('error','Non riesco ad avviare l’ascolto. Riprova in Safari.',true);}
  }
  async function startLocal(session) {
    if(!window.RamblaLocalASR){setSpeech('error','Modulo locale non disponibile.',false);return;}
    const token=++localGeneration,sessionId=session.id;let localProblem='';
    setSpeech('loading','Preparo l’ascolto locale…');
    if(local){const previous=local;await previous.destroy();if(local===previous)local=null;}
    if(token!==localGeneration||!active||speechSuspended||current()?.id!==sessionId)return;
    const capture={sessionId,start:elapsed(),end:null,acceptResults:true};localCapture=capture;
    local=new window.RamblaLocalASR({
      onStatus:info=>{
        if(current()?.id!==sessionId||token!==localGeneration||!active||speechSuspended)return;
        if(info.state==='stopped'&&active&&!pendingFlush){setSpeech('error',localProblem||'Ascolto locale fermo. Premi Riattiva per riprendere.',true);return;}
        if(info.state==='loading'){$('modelProgress').hidden=false;const p=$('modelProgress').querySelector('progress');if(Number.isFinite(info.progress))p.value=info.progress;else p.removeAttribute('value');$('modelProgress').querySelector('span').textContent=info.message;}
        setSpeech(info.state,info.message,info.state==='error'&&active);
        if(info.state==='loading')$('modelProgress').hidden=false;
      },
      onSegment:segment=>{const voice=[...speakerHistory].reverse().find(event=>event.start<=segment.start)?.speaker;captureSegment(capture,{...segment,speaker:voice||session.speaker});},
      onError:error=>{if(error.name==='AbortError')return;if(current()?.id===sessionId&&token===localGeneration&&active){localProblem=error.message||'Il riconoscimento locale si è interrotto.';setSpeech('error',localProblem,true);}}
    });
    const engine=local;capture.engine=engine;
    try{await engine.start({language:session.language.split('-')[0],getElapsed:()=>capture.end??elapsed()});if(token!==localGeneration||!active||speechSuspended){await engine.stop({flush:true});}}
    catch(e){if(e.name!=='AbortError'&&token===localGeneration&&active)setSpeech('error',e.message||'Whisper non è disponibile su questo dispositivo.',true);}
  }
  function startSpeech() {
    if(!active||pendingFlush||speechSuspended||document.hidden)return Promise.resolve();
    if(speechStartTask)return speechStartTask;
    const s=current(),generation=speechGeneration;
    const task=(async()=>{
      if(store.prefs.mode==='native')startNative(s);
      else if(store.prefs.mode==='local')await startLocal(s);
      else setSpeech('idle','Solo marker · nessun microfono attivo');
    })().catch(error=>{if(generation===speechGeneration&&active)setSpeech('error',error.message||'Non riesco ad avviare il microfono.',true);}).finally(()=>{if(speechStartTask===task)speechStartTask=null;});
    speechStartTask=task;return task;
  }
  async function requestWake() {
    if(!active||document.visibilityState!=='visible'||!navigator.wakeLock||wake||wakeRequest)return;
    const generation=++wakeGeneration;
    let request;
    try{
      request=navigator.wakeLock.request('screen');wakeRequest=request;const lock=await request;
      if(generation!==wakeGeneration||!active||document.hidden){await lock.release();return;}
      wake=lock;lock.addEventListener('release',()=>{if(wake===lock)wake=null;});
    }catch(e){ /* UI already instructs to keep screen awake. */ }
    finally{if(wakeRequest===request)wakeRequest=null;}
  }
  function clockTC(d,fps) {const rate=C.rateInfo(fps);let f=Math.min(rate.nominal-1,Math.floor(d.getMilliseconds()/1000*rate.nominal));if(rate.drop&&d.getMinutes()%10!==0&&d.getSeconds()===0)f=Math.max(f,rate.nominal===60?4:2);return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}${rate.drop?';':':'}${String(f).padStart(2,'0')}`;}
  function startSession(resume=false) {
    if(active||pendingFlush||voiceClosing||document.hidden)return;
    const s=current();if(s.isDemo||s.endedAt)return;
    if(unfinished(s)!==resume)return;
    if(!resume){
      if(preSync)s.startTC=C.formatTC(preSync.frames+C.secondsToFrames((liveClock()-preSync.capturedAt)/1000,s.fps),s.fps);
      const now=Date.now();
      s.clockSource=s.clockSource||'timecode';
      if(s.clockSource==='phone'){s.phoneAnchorMs=now;s.startTC=clockTC(new Date(now),s.fps);delete s.sync;}
      s.startedAt=now;s.duration=0;clockBase=0;
    }else clockBase=elapsed();
    s.captureState='active';s.pauseReason=null;s.pausedAt=null;
    clockPerf=liveClock();active=true;recovery=false;preSync=null;selected.clear();lastNativeEnd=[];speechSuspended=false;
    captureRangeStart=clockBase;speakerHistory=[{start:captureRangeStart,speaker:s.speaker}];
    $('visibilityBanner').hidden=true;persist();render();requestWake();startSpeech();
  }
  function stopNative(capture) {
    if(!capture||!capture.acceptResults)return Promise.resolve();
    return new Promise(resolve=>{
      let timer,done=false;
      const finish=()=>{if(done)return;done=true;clearTimeout(timer);capture.acceptResults=false;capture.finish=null;if(nativeCapture===capture){nativeCapture=null;native=null;}resolve();};
      capture.finish=finish;
      timer=setTimeout(()=>{capture.acceptResults=false;try{capture.engine.abort();}catch{}finish();},2500);
      try{capture.engine.stop();}catch{finish();}
    });
  }
  function flushCapture(boundary) {
    // Set both boundaries before stop(): native results and local final chunks
    // can arrive synchronously or much later than the user's pause tap.
    for(const capture of [nativeCapture,localCapture])if(capture)capture.end=Math.min(capture.end??Infinity,boundary);
    speechGeneration++;localGeneration++;speechStartTask=null;nativeAllowed=false;clearTimeout(restartTimer);
    if(flushPromise)return flushPromise;
    pendingFlush=true;
    const tasks=[stopNative(nativeCapture)],capture=localCapture,engine=local;
    if(engine){
      try{tasks.push(Promise.resolve(engine.stop({flush:true})).catch(error=>notify('Chiusura trascrizione: '+error.message)).finally(()=>{if(capture)capture.acceptResults=false;}));}
      catch(error){if(capture)capture.acceptResults=false;notify('Chiusura trascrizione: '+error.message);}
    }
    wakeGeneration++;wakeRequest=null;const lock=wake;wake=null;if(lock)Promise.resolve(lock.release()).catch(()=>{});
    const task=Promise.all(tasks).finally(()=>{if(flushPromise===task){flushPromise=null;pendingFlush=false;interimText='';persist();render();}});
    flushPromise=task;return task;
  }
  function pauseSession(reason='manual') {
    if(!active)return flushPromise||Promise.resolve();
    const s=current(),boundary=elapsed();s.duration=boundary;s.captureState='paused';s.pauseReason=reason;s.pausedAt=Math.max(s.startedAt,Date.now());
    active=false;recovery=false;speechSuspended=true;
    // This synchronous checkpoint precedes every await on a lifecycle event.
    persist();const finished=flushCapture(boundary);render();
    setSpeech('suspended','Sessione in pausa · microfono spento',false);
    return finished.then(()=>{if(current()?.id===s.id&&!active&&!s.endedAt){setSpeech('suspended','Sessione in pausa · premi Riprendi per continuare',false);render();}});
  }
  function endSession() {
    if(pendingFlush)return flushPromise||Promise.resolve();
    const s=current();if(!unfinished(s))return Promise.resolve();
    const boundary=elapsed();s.duration=boundary;s.endedAt=Math.max(s.startedAt||0,Date.now());s.captureState='ended';s.pauseReason=null;s.pausedAt=null;
    active=false;recovery=false;speechSuspended=true;persist();
    const finished=flushCapture(boundary);render();
    return finished.then(()=>{setSpeech('idle','Sessione conclusa · trascrizione modificabile');persist();render();notify('Sessione salvata. Esporta anche il backup JSON.');});
  }
  function retrySpeech() {
    if(!active||pendingFlush||retryTask||voiceNote||voiceClosing)return;
    const sessionId=current().id;
    const task=(async()=>{
      await flushCapture(elapsed());
      if(!active||document.hidden||current()?.id!==sessionId)return;
      speechSuspended=false;lastNativeEnd=[];setSpeech('loading','Riattivo l’ascolto…');await startSpeech();requestWake();
    })().finally(()=>{if(retryTask===task)retryTask=null;});
    retryTask=task;render();return task;
  }
  function selectSession(id) {
    if(active||pendingFlush){notify('Termina prima la sessione in corso.');return;}
    const s=store.sessions.find(s=>s.id===id);if(!s)return;
    store.activeId=id;selected.clear();interimText='';preSync=null;activeTab='markers';recovery=!!unfinished(s);
    if(recovery&&s.captureState!=='paused'){s.captureState='paused';s.pauseReason='recovery';s.pausedAt=Math.max(s.startedAt,Math.min(Date.now(),Math.round(s.startedAt+s.duration*1000)));}
    setSpeech(recovery?'suspended':'idle',recovery?'Sessione in pausa · premi Riprendi per continuare':'Microfono spento');persist();render();$('sessionsDialog').close();
  }
  function newSession() {
    if(active||pendingFlush){notify('Termina prima la sessione in corso.');return;}
    const s=makeSession();store.sessions.push(s);store.activeId=s.id;selected.clear();preSync=null;recovery=false;activeTab='markers';interimText='';persist();render();$('sessionsDialog').close();openSettings(true);
  }
  function mark(categoryId) {
    if(pendingFlush){notify('Attendi la fine della trascrizione prima di aggiungere un marker.');return;}
    const s=current(),cat=catFor(categoryId);let start,end,note,ids=[];
    const lines=s.segments.filter(line=>selected.has(line.id)).sort((a,b)=>a.start-b.start);
    if(lines.length){start=Math.min(...lines.map(l=>l.start));end=Math.max(...lines.map(l=>l.end));note=lines.map(l=>l.text).join(' ');ids=lines.map(l=>l.id);}
    else{
      if(!active){notify(unfinished(s)?'La sessione è in pausa. Premi Riprendi per segnare nuovi momenti.':s.endedAt||s.isDemo?'Seleziona una frase o aggiungi una nota con i suoi tempi.':'Avvia la sessione per segnare gli ultimi secondi.');return;}
      end=elapsed();start=Math.max(0,captureRangeStart,end-s.lookback);end=Math.max(end,start+1/C.rateInfo(s.fps).rate);
      const matching=s.segments.filter(l=>l.end>start&&l.start<end);note=matching.map(l=>l.text).join(' ');ids=matching.map(l=>l.id);
    }
    const marker={id:uid(),start,end,name:cat.name,note,color:cat.color,category:cat.id,segmentIds:ids,autoNote:!lines.length};s.markers.push(marker);selected.clear();persist();renderLists();renderSessions();
    if(navigator.vibrate)navigator.vibrate(20);notify(`${cat.name} · ${tcAt(start)} · ${(end-start).toFixed(1)}s`,()=>{s.markers=s.markers.filter(m=>m.id!==marker.id);persist();render();});
  }
  function openSettings(isNew=false) {
    newSettings=isNew;const s=current(),locked=active||unfinished(s)||pendingFlush||s.isDemo||!!s.tcAnchors?.length;
    $('settingsTitle').value=s.title;$('settingsFps').value=s.fps;$('settingsLanguage').value=s.language;$('settingsTC').value=s.startTC;$('settingsSpeakers').value=s.speakers.join(', ');
    $('settingsFps').disabled=locked;$('settingsTC').disabled=locked||s.clockSource==='phone';$('useClock').disabled=locked;$('settingsLanguage').disabled=active||pendingFlush;$('clockLocked').hidden=!locked;$('deleteSession').hidden=active||pendingFlush||isNew;
    $('clockLocked').textContent=s.tcAnchors?.length?'FPS e riferimento iniziale restano fissi per conservare gli allineamenti. Puoi correggere il posizionamento nell’esportazione EDL.':'FPS e riferimento iniziale sono fissi durante la sessione. Puoi aggiornare il timecode dalla camera.';
    if($('settingsTCField'))$('settingsTCField').hidden=s.clockSource==='phone';
    showError('settingsError','');$('settingsDialog').showModal();
  }
  function saveSettings(event) {
    event.preventDefault();const s=current();
    try{
      const title=$('settingsTitle').value.trim();if(!title)throw Error('Dai un nome alla sessione.');
      if(!active&&!unfinished(s)&&!pendingFlush&&!s.isDemo&&!s.tcAnchors?.length){const fps=$('settingsFps').value;const tc=s.clockSource==='phone'?clockTC(new Date(s.phoneAnchorMs??Date.now()),fps):C.formatTC(C.parseTC($('settingsTC').value,fps),fps);if(s.fps!==fps||s.startTC!==tc){preSync=null;delete s.sync;}s.fps=fps;s.startTC=tc;}
      const speakers=[...new Set($('settingsSpeakers').value.split(',').map(x=>x.trim()).filter(Boolean))].slice(0,12);if(!speakers.length)throw Error('Inserisci almeno il nome di una voce.');
      s.title=title;s.language=$('settingsLanguage').value;s.speakers=speakers;if(!speakers.includes(s.speaker))s.speaker=speakers[0];
      persist();render();$('settingsDialog').close();if(newSettings)notify(s.clockSource==='phone'?'Sessione pronta con l’ora del telefono.': 'Sessione pronta. Puoi sincronizzare il timecode dalla camera.');
    }catch(e){showError('settingsError',e.message);}
  }
  function selectClockSource(source) {
    const s=current();if(!['phone','timecode'].includes(source)||active||unfinished(s)||pendingFlush||s.isDemo||s.tcAnchors?.length)return false;
    s.clockSource=source;preSync=null;delete s.sync;
    s.phoneAnchorMs=source==='phone'?(s.startedAt??null):null;
    if(source==='phone'&&s.phoneAnchorMs!==null)s.startTC=clockTC(new Date(s.phoneAnchorMs),s.fps);
    persist();render();return true;
  }
  function openNote(type=null,id=null) {
    const s=current();noteEdit=type&&id?{type,id}:null;
    const item=type==='segment'?s.segments.find(l=>l.id===id):type==='marker'?s.markers.find(m=>m.id===id):null;
    const chosen=s.segments.filter(l=>selected.has(l.id));
    const end=chosen.length?Math.max(...chosen.map(l=>l.end)):elapsed();
    const start=chosen.length?Math.min(...chosen.map(l=>l.start)):Math.max(0,end-s.lookback);
    $('noteHeading').textContent=type==='segment'?'Correggi la frase.':type==='marker'?'Modifica il marker.':'Aggiungi una nota.';
    $('noteText').value=item?(item.text??item.note??''):chosen.map(l=>l.text).join(' ');
    const formStart=item?.start??start;
    $('noteStart').value=formStart.toFixed(3);$('noteEnd').value=Math.max(item?.end??end,formStart+1/C.rateInfo(s.fps).rate).toFixed(3);
    $('noteCategory').value=catFor(item?.category).id;$('noteCategory').disabled=type==='segment';
    $('noteSpeaker').innerHTML=s.speakers.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');$('noteSpeaker').value=item?.speaker||s.speaker;
    $('noteTranscriptLabel').hidden=!!type;$('noteTranscript').checked=true;$('deleteNote').hidden=!type;
    showError('noteError','');$('noteDialog').showModal();
  }
  function saveNote(event) {
    event.preventDefault();const s=current();
    try{
      const text=$('noteText').value.trim(),start=Number($('noteStart').value),end=Number($('noteEnd').value);if(!text)throw Error('Scrivi il testo della nota.');
      if(!Number.isFinite(start)||!Number.isFinite(end)||start<0||end<=start)throw Error('Usa un inizio positivo o zero e una fine successiva.');
      if(end>86400)throw Error('La durata massima gestita è 24 ore.');
      const cat=catFor($('noteCategory').value),speaker=$('noteSpeaker').value;
      if(noteEdit?.type==='segment'){
        const line=s.segments.find(l=>l.id===noteEdit.id);Object.assign(line,{start,end,text,speaker});
      }else if(noteEdit?.type==='marker'){
        const m=s.markers.find(m=>m.id===noteEdit.id);Object.assign(m,{start,end,note:text,name:cat.name,category:cat.id,color:cat.color,autoNote:false});
      }else{
        const ids=[];if($('noteTranscript').checked){const seg={id:uid(),start,end,text,speaker};s.segments.push(seg);ids.push(seg.id);}
        s.markers.push({id:uid(),start,end,name:cat.name,note:text,color:cat.color,category:cat.id,segmentIds:ids});
      }
      if(!active)s.duration=Math.max(s.duration,end);selected.clear();persist();render();$('noteDialog').close();notify('Nota salvata.');
    }catch(e){showError('noteError',e.message);}
  }
  function deleteNote() {
    const s=current(),kind=noteEdit?.type;if(!kind)return;
    const key=kind==='segment'?'segments':'markers',item=s[key].find(x=>x.id===noteEdit.id),oldMarkers=JSON.parse(JSON.stringify(s.markers));
    s[key]=s[key].filter(x=>x.id!==noteEdit.id);if(kind==='segment')s.markers.forEach(m=>m.segmentIds=m.segmentIds.filter(id=>id!==item.id));
    selected.delete(item.id);persist();render();$('noteDialog').close();notify(kind==='segment'?'Frase eliminata.':'Marker eliminato.',()=>{s[key].push(item);if(kind==='segment')s.markers=oldMarkers;persist();render();});
  }
  function openExport() {
    if(pendingFlush){notify('Attendi l’ultima trascrizione: poi potrai esportare la sessione completa.');return;}
    const s=current();if(active)s.duration=elapsed();
    $('exportSummary').textContent=`${s.title} · ${s.markers.length} marker · ${s.segments.length} ${s.segments.length===1?'frase':'frasi'} · ${C.rateInfo(s.fps).label}${active?' · copia parziale della sessione in corso':''}`;
    $('exportTC').value=s.startTC;$('exportOffset').value='0';
    const duplicates=s.markers.length-new Set(s.markers.map(m=>C.secondsToFrames(m.start,s.fps))).size;
    $('exportWarning').hidden=!duplicates;$('exportWarning').textContent=duplicates?'Ci sono marker sullo stesso fotogramma. Il file li conserva, ma Resolve potrebbe tenerne uno solo per posizione. Puoi spostarli prima di esportare.':'';
    $('exportDialog').showModal();
  }
  async function saveFile(name,text,type) {
    const file=new File([text],name,{type});
    if(navigator.canShare?.({files:[file]})&&navigator.share){
      try{await navigator.share({files:[file],title:name});return;}catch(e){if(e.name==='AbortError')return;}
    }
    const url=URL.createObjectURL(file),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);notify('File preparato: '+name);
  }
  function exportKind(kind) {
    if(pendingFlush){notify('L’ultima trascrizione è ancora in elaborazione. Attendi prima di esportare.');return;}
    const s=current();if(active)s.duration=elapsed();
    try{
      let body,mime,name=fileSlug(s.title);
      if(kind==='edl'){if(!s.markers.length)throw Error('Aggiungi almeno un marker prima di esportare.');body=C.makeEDL(s,{timelineTC:$('exportTC').value,offsetSeconds:Number($('exportOffset').value)});mime='text/plain;charset=utf-8';name+='-marker.edl';}
      else if(kind==='srt'){if(!s.segments.length)throw Error('Non ci sono ancora frasi da esportare.');body=C.makeSRT(s);mime='application/x-subrip';name+='.srt';}
      else if(kind==='csv'){body=C.makeCSV(s);mime='text/csv;charset=utf-8';name+='-log.csv';}
      else if(kind==='txt'){body=C.makeTXT(s);mime='text/plain;charset=utf-8';name+='-log.txt';}
      else{body=JSON.stringify({app:'RAMBLA Log',version:1,exportedAt:new Date().toISOString(),sessions:[s]},null,2);mime='application/json';name+='-backup.json';}
      saveFile(name,body,mime);
    }catch(e){$('exportWarning').hidden=false;$('exportWarning').textContent=e.message;}
  }
  function importClick() {
    if(active||pendingFlush){notify('Termina prima la sessione per importare nuovi dati.');return;}
    $('importFile').value='';$('importFile').click();
  }
  async function importFile(file) {
    if(!file)return;if(file.size>20*1024*1024){notify('Il file è troppo grande. Usa un backup o SRT inferiore a 20 MB.');return;}
    try{
      const raw=await file.text();let sessions;
      if(file.name.toLowerCase().endsWith('.srt')){
        const segments=C.parseSRT(raw);if(!segments.length)throw Error('Non ho trovato sottotitoli validi nel file.');
        const s=makeSession(file.name.replace(/\.srt$/i,''));s.clockSource='timecode';s.segments=segments.map(l=>({...l,id:uid(),speaker:l.speaker||s.speaker}));s.duration=Math.max(...segments.map(l=>l.end));s.startedAt=Math.round(Date.now()-s.duration*1000);s.endedAt=Date.now();s.captureState='ended';sessions=[s];
      }else{
        const parsed=JSON.parse(raw);const rawSessions=Array.isArray(parsed.sessions)?parsed.sessions:parsed.fps?[parsed]:null;
        if(!rawSessions?.length||rawSessions.length>300)throw Error('Il file non contiene sessioni RAMBLA Log valide (massimo 300).');
        sessions=rawSessions.map(s=>C.validateSession(s));
        // Imports are copies; avoid changing existing sessions with identical IDs.
        sessions=sessions.map(s=>({...s,id:uid(),isDemo:false}));
      }
      store.sessions.push(...sessions);selectSession(sessions[0].id);persist();notify(`${sessions.length} ${sessions.length===1?'sessione importata':'sessioni importate'}.`);
    }catch(e){notify('Importazione non riuscita: '+e.message);}
  }
  function loadDemo() {
    if(active||pendingFlush){notify('Termina prima la sessione in corso.');return;}
    let s=store.sessions.find(x=>x.isDemo);
    if(!s){s=makeSession('Intervista · La prima volta');s.clockSource='timecode';s.captureState='ended';s.isDemo=true;s.duration=53;s.startedAt=Date.now()-53000;s.endedAt=Date.now();s.speakers=['Giulia','Intervistatore'];s.speaker='Giulia';
      s.segments=[{id:uid(),start:3,end:8,text:'Ti ricordi il momento in cui hai capito che volevi partire?',speaker:'Intervistatore'},{id:uid(),start:10,end:19,text:'Sì. Ero seduta alla fermata dell’autobus e ho pensato: conosco questa strada a memoria.',speaker:'Giulia'},{id:uid(),start:21,end:30,text:'Non volevo andare lontano. Volevo solo ricominciare a guardare le cose per la prima volta.',speaker:'Giulia'},{id:uid(),start:34,end:42,text:'Poi sono partita con uno zaino enorme. Dentro, ovviamente, tutto quello che non mi serviva.',speaker:'Giulia'},{id:uid(),start:44,end:52,text:'La parte più bella? Le persone incontrate. Il viaggio alla fine era tutto lì.',speaker:'Giulia'}];
      s.markers=[{id:uid(),start:21,end:30,name:'Highlight',note:s.segments[2].text,color:'Yellow',category:'highlight',segmentIds:[s.segments[2].id]},{id:uid(),start:34,end:42,name:'Divertente',note:s.segments[3].text,color:'Purple',category:'funny',segmentIds:[s.segments[3].id]},{id:uid(),start:44,end:52,name:'Emozione',note:s.segments[4].text,color:'Pink',category:'emotion',segmentIds:[s.segments[4].id]}];store.sessions.push(s);}
    selectSession(s.id);notify('Demo caricata: contenuti di esempio, nessun microfono attivo.');
  }
  function deleteSession() {
    if(active||pendingFlush)return;const s=current();if(!confirm(`Eliminare «${s.title}» da questo dispositivo? Puoi prima esportare un backup.`))return;
    store.sessions=store.sessions.filter(x=>x.id!==s.id);if(!store.sessions.length)store.sessions.push(makeSession());store.activeId=store.sessions.at(-1).id;recovery=!!unfinished(current());selected.clear();preSync=null;persist();render();$('settingsDialog').close();notify('Sessione eliminata.',()=>{store.sessions.push(s);selectSession(s.id);});
  }
  function persistVoiceText(context,text) {
    if(voiceNote!==context)return;
    const s=store.sessions.find(item=>item.id===context.sessionId),m=s?.markers.find(item=>item.id===context.markerId);
    if(!m)return;
    const cat=catFor($('voiceCategory').value);
    const note=String(text??'').trim().slice(0,12000);
    if(m.note===note&&m.category===cat.id)return;
    Object.assign(m,{note,name:cat.name+' · nota vocale',category:cat.id,color:cat.color,autoNote:false});
    persist();renderLists();
  }
  async function openVoiceNote() {
    if(voiceNote||voiceClosing||pendingFlush)return;
    const s=current();
    if(s.isDemo||!s.startedAt){notify('Avvia una sessione per fissare il momento della nota vocale.');return;}
    const lines=s.segments.filter(item=>selected.has(item.id)),captureBoundary=elapsed();
    const end=lines.length?Math.max(...lines.map(item=>item.end)):captureBoundary;
    const start=lines.length?Math.min(...lines.map(item=>item.start)):Math.max(0,active?captureRangeStart:0,end-s.lookback);
    const marker={id:uid(),start,end:Math.max(end,start+1/C.rateInfo(s.fps).rate),name:'Nota vocale',note:'',category:'check',color:'Blue',autoNote:false,segmentIds:[]};
    s.markers.push(marker);selected.clear();
    const context={sessionId:s.id,markerId:marker.id,token:++voiceGeneration,resumeSpeech:active&&store.prefs.mode!=='manual',engine:null,recording:false,loading:false,stopping:false,saving:false,run:0};
    voiceNote=context;speechSuspended=true;
    $('voiceText').value='';$('voiceText').readOnly=true;$('voiceCategory').value='check';
    $('voiceMoment').textContent=`Momento fissato: ${tcAt(start)} → ${tcAt(marker.end,start)}. La durata della dettatura non sposta il marker.`;
    $('voiceStatus').textContent='Preparo la dettatura…';$('voiceSave').disabled=true;$('voiceStop').hidden=true;$('voiceStart').disabled=true;
    persist();renderLists();$('voiceNoteDialog').showModal();
    context.captureDrain=flushCapture(captureBoundary);
    await context.captureDrain;
    if(voiceNote!==context||document.hidden)return;
    requestWake();
    await startVoiceCapture();
  }
  async function startVoiceCapture() {
    const context=voiceNote;
    if(!context||context.loading||context.recording||context.stopping||document.hidden)return;
    if(!window.RamblaVoiceNote){$('voiceStatus').textContent='Dettatura non disponibile. Puoi scrivere la nota.';$('voiceText').readOnly=false;return;}
    const run=++context.run;context.loading=true;
    $('voiceStart').disabled=true;$('voiceSave').disabled=true;$('voiceText').readOnly=true;
    const base=$('voiceText').value.trim();
    if(context.engine)await context.engine.destroy();
    if(voiceNote!==context||document.hidden)return;
    const alive=()=>voiceNote===context&&context.run===run;
    const engine=new window.RamblaVoiceNote({
      onText:data=>{
        if(!alive())return;
        const confirmed=[base,data.text].filter(Boolean).join(' ').trim();
        $('voiceText').value=[confirmed,data.interim].filter(Boolean).join(' ').trim();
        $('voiceSave').disabled=!$('voiceText').value.trim()||context.stopping;
        persistVoiceText(context,confirmed);
      },
      onStatus:info=>{
        if(!alive())return;
        context.recording=['listening','processing'].includes(info.state)&&!context.stopping;context.loading=info.state==='loading';
        $('voiceStatus').textContent=info.message;
        $('voiceStop').hidden=!context.recording&&!context.stopping;$('voiceStop').disabled=context.stopping;
        $('voiceStart').hidden=context.recording||context.stopping;$('voiceStart').disabled=context.loading||context.stopping;
        $('voiceText').readOnly=context.recording||context.loading||context.stopping;
        $('voiceSave').disabled=context.loading||context.stopping||!$('voiceText').value.trim();
      },
      onError:error=>{if(alive()){$('voiceStatus').textContent=error.message||'Dettatura interrotta. Puoi correggere o scrivere la nota.';$('voiceText').readOnly=false;}}
    });
    context.engine=engine;
    try{await engine.start({mode:store.prefs.mode==='local'?'local':'native',language:current().language});}
    catch(error){if(alive()&&error.name!=='AbortError'){$('voiceStatus').textContent=error.message||'Premi Detta per autorizzare il microfono, oppure scrivi la nota.';$('voiceText').readOnly=false;$('voiceStart').hidden=false;$('voiceStart').disabled=false;}}
    finally{if(alive())context.loading=false;}
  }
  async function stopVoiceCapture() {
    const context=voiceNote;if(!context||context.stopping)return context?.stopTask;
    context.stopping=true;$('voiceStop').disabled=true;$('voiceSave').disabled=true;$('voiceStart').disabled=true;
    const task=(async()=>{
      try{await context.engine?.stop({flush:true});}
      catch(error){if(voiceNote===context&&error.name!=='AbortError')$('voiceStatus').textContent=error.message;}
      finally{if(voiceNote===context){context.stopping=false;context.recording=false;context.loading=false;$('voiceStop').hidden=true;$('voiceStart').hidden=false;$('voiceStart').disabled=false;$('voiceText').readOnly=false;$('voiceSave').disabled=!$('voiceText').value.trim();persistVoiceText(context,$('voiceText').value);}}
    })();context.stopTask=task;return task;
  }
  function closeVoiceNote({discard=false,resume=true}={}) {
    const context=voiceNote;if(!context)return voiceClosing||Promise.resolve();
    persistVoiceText(context,$('voiceText').value);
    const s=store.sessions.find(item=>item.id===context.sessionId),m=s?.markers.find(item=>item.id===context.markerId);
    if(s&&(discard||!m?.note.trim()))s.markers=s.markers.filter(item=>item.id!==context.markerId);
    voiceNote=null;voiceGeneration++;context.run++;
    $('voiceNoteDialog').close();persist();renderLists();
    const task=(async()=>{
      try{await context.engine?.destroy();}catch{}
      // Cancel may arrive before the previous scene microphone has drained.
      // Wait for ownership to be released before restoring that transcription.
      if(resume&&context.resumeSpeech)await context.captureDrain;
      if(resume&&context.resumeSpeech&&active&&!document.hidden&&current()?.id===context.sessionId&&!pendingFlush){speechSuspended=false;startSpeech();requestWake();}
      else if(active&&!document.hidden){speechSuspended=false;requestWake();}
    })().finally(()=>{if(voiceClosing===task){voiceClosing=null;render();}});
    voiceClosing=task;return task;
  }
  async function saveVoiceNote() {
    const context=voiceNote;if(!context||context.saving)return;
    context.saving=true;await stopVoiceCapture();
    if(voiceNote!==context)return;
    if(!$('voiceText').value.trim()){context.saving=false;$('voiceStatus').textContent='Detta o scrivi una nota prima di salvare.';return;}
    persistVoiceText(context,$('voiceText').value);await closeVoiceNote();notify('Nota vocale salvata nel marker.');
  }
  async function openScanner() {
    if(pendingFlush||voiceNote||voiceClosing){notify('Completa la nota o la trascrizione prima di leggere il timecode.');return;}
    if(!window.RamblaTimecodeCamera){notify('Lettore timecode non ancora disponibile.');return;}
    const s=current();if(s.isDemo){notify('Crea una sessione reale per sincronizzare la camera.');return;}
    if(s.clockSource==='phone'&&unfinished(s)){notify('Questa sessione usa l’ora del telefono. Scegli Timecode in una nuova sessione per sincronizzare la camera.');return;}
    if(s.endedAt){notify('Per leggere il TC corrente crea una nuova sessione. Puoi correggere il posizionamento di questa sessione nell’esportazione EDL.');return;}
    latestReading=null;$('scanReading').textContent='--:--:--:--';$('scanStatus').textContent='Inquadra solo il timecode della camera nel riquadro.';$('scanApply').disabled=true;$('scanLock').textContent='CERCO IL TIMECODE';
    $('scanExposure').value='0';$('scanExposureValue').textContent='0';$('scanPreviewToggle').open=false;
    $('scanApply').innerHTML=(s.startedAt?'Aggiorna e chiudi':'Allinea e chiudi')+icon('check');
    $('scanFps').textContent=C.rateInfo(s.fps).label;$('scanDialog').showModal();
    const token=++scanGeneration;let applying=false;
    scanner=new window.RamblaTimecodeCamera({video:$('scanVideo'),canvas:$('scanCanvas'),
      onStatus:info=>{if(token!==scanGeneration)return;$('scanStatus').textContent=info.message;if(info.roi)updateScanReticle();if(['searching','error','stopped'].includes(info.state)){latestReading=null;$('scanApply').disabled=true;}},
      onReading:reading=>{
        if(token!==scanGeneration)return;latestReading=reading;latestReadingReceivedAt=liveClock();$('scanReading').textContent=reading.timecode||reading.text;
        $('scanApply').disabled=!reading.stable;
        $('scanLock').textContent=reading.stable?'LETTURE COERENTI':`VERIFICO · ${reading.readings||1}/${reading.requiredReadings||3}`;
        if(reading.stable&&$('scanAuto').checked&&!applying){applying=true;applyScan();}
      },
      onCameraControls:info=>{
        if(token!==scanGeneration)return;
        const input=$('scanExposure');input.min=String(info.min);input.max=String(info.max);input.step=String(info.step);input.value=String(info.value);
        $('scanExposureValue').textContent=(info.value>0?'+':'')+Number(info.value).toFixed(1);
        $('scanExposureHint').textContent=info.message;
      },
      onError:error=>{if(token!==scanGeneration)return;$('scanStatus').textContent=error.message||'La fotocamera non è disponibile. Controlla i permessi di Safari.';}
    });
    updateScanReticle();
    try{await scanner.start({fps:s.fps});if(token===scanGeneration)updateScanReticle();}catch(e){if(token===scanGeneration)$('scanStatus').textContent=e.message;}
  }
  function updateScanReticle() {
    if(!scanner)return;
    const video=$('scanVideo'),viewport=video.parentElement||document.querySelector('.scan-viewport');
    const box=viewport.getBoundingClientRect();if(!box.width||!box.height)return;
    scanner.setViewport(box.width,box.height);
    if(!video.videoWidth||!video.videoHeight)return;
    const r=scanner.getROI(),scale=Math.max(box.width/video.videoWidth,box.height/video.videoHeight);
    const width=video.videoWidth*scale,height=video.videoHeight*scale;
    $('scanReticle').style.cssText=`left:${(box.width-width)/2+r.x*width}px;top:${(box.height-height)/2+r.y*height}px;width:${r.width*width}px;height:${r.height*height}px`;
  }
  function applyScan() {
    if(!latestReading?.stable)return;
    if(liveClock()-latestReadingReceivedAt>5000){latestReading=null;$('scanApply').disabled=true;$('scanStatus').textContent='Lettura troppo vecchia: attendo nuovi valori coerenti.';return;}
    const s=current(),reading=latestReading,now=liveClock();
    const nowFrames=reading.frames+C.secondsToFrames((now-reading.capturedAt)/1000,s.fps);
    const syncedAt=new Date().toISOString();
    if(s.startedAt){
      const at=elapsed();let anchor;
      try{anchor=C.makeTimecodeAnchor(s,{at,timecode:C.formatTC(nowFrames,s.fps),syncedAt});}
      catch(error){$('scanStatus').textContent=error.message;return;}
      s.tcAnchors=[...(s.tcAnchors||[]),anchor];captureRangeStart=Math.max(captureRangeStart,at);preSync=null;
    }else{preSync={frames:reading.frames,capturedAt:reading.capturedAt};s.startTC=C.formatTC(nowFrames,s.fps);}
    s.clockSource='timecode';s.phoneAnchorMs=null;s.sync={method:'camera',timecode:C.formatTC(nowFrames,s.fps),at:syncedAt,readings:reading.readings||3,confidence:reading.confidence};
    persist();render();$('scanDialog').close();notify(s.startedAt?'Timecode aggiornato da questo momento. I marker precedenti restano invariati.':`Allineato alla camera: ${C.formatTC(nowFrames,s.fps)}. Il clock prosegue sul telefono.`);
  }
  async function closeScanner() {scanGeneration++;const old=scanner;scanner=null;latestReading=null;try{await old?.stop();}catch{} }
  function bind() {
    $('markerPads').innerHTML=CATEGORIES.map((c,i)=>`<button class="marker-pad" data-category="${c.id}" style="--pad-bg:${c.bg};--pad-border:${c.border};--pad-ink:${c.ink}">${icon(c.icon)}<span>${c.name}</span><span class="shortcut">${i+1}</span></button>`).join('');
    $('settingsFps').innerHTML=C.rates.map(r=>`<option value="${esc(r.id)}">${esc(r.label)}</option>`).join('');
    $('noteCategory').innerHTML=CATEGORIES.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
    $('voiceCategory').innerHTML=$('noteCategory').innerHTML;
    document.addEventListener('click',event=>{
      const b=event.target.closest('button');if(!b)return;
      if(b.dataset.session)selectSession(b.dataset.session);
      else if(b.dataset.category)mark(b.dataset.category);
      else if(b.dataset.lookback){current().lookback=Number(b.dataset.lookback);persist();renderLists();}
      else if(b.dataset.segment){const id=b.dataset.segment;if(selected.has(id))selected.delete(id);else selected.add(id);renderLists();}
      else if(b.dataset.editSegment)openNote('segment',b.dataset.editSegment);
      else if(b.dataset.editMarker)openNote('marker',b.dataset.editMarker);
      else if(b.dataset.export)exportKind(b.dataset.export);
      else if(b.classList.contains('new-session'))newSession();
      else if(b.classList.contains('settings-button'))openSettings();
      else if(b.classList.contains('help-button'))$('helpDialog').showModal();
      else if(b.classList.contains('export-button'))openExport();
      else if(b.classList.contains('import-button'))importClick();
      else if(b.classList.contains('demo-button'))loadDemo();
      else if(b.classList.contains('close-dialog'))b.closest('dialog').close();
    });
    $('startButton').onclick=()=>startSession();$('stopButton').onclick=endSession;
    if($('pauseButton'))$('pauseButton').onclick=()=>pauseSession('manual');
    if($('resumeButton'))$('resumeButton').onclick=()=>startSession(true);
    if($('clockPhoneButton'))$('clockPhoneButton').onclick=()=>selectClockSource('phone');
    if($('clockTimecodeButton'))$('clockTimecodeButton').onclick=()=>selectClockSource('timecode');
    $('speakerSelect').onchange=()=>{current().speaker=$('speakerSelect').value;if(active)speakerHistory.push({start:elapsed(),speaker:current().speaker});persist();};
    $('speechMode').onchange=()=>{if(active||pendingFlush)return;store.prefs.mode=$('speechMode').value;persist();render();};
    $('speechRetry').onclick=retrySpeech;
    $('transcriptTab').onclick=()=>{activeTab='transcript';renderLists();};$('markersTab').onclick=()=>{activeTab='markers';renderLists();};
    $('clearSelection').onclick=()=>{selected.clear();renderLists();};
    $('manualNoteButton').onclick=()=>openNote();$('manualNoteButton2').onclick=()=>openNote();
    $('voiceNoteButton').onclick=openVoiceNote;$('voiceStart').onclick=startVoiceCapture;$('voiceStop').onclick=stopVoiceCapture;
    $('voiceSave').onclick=saveVoiceNote;$('voiceCancel').onclick=()=>closeVoiceNote({discard:true});
    $('voiceText').oninput=()=>{if(!voiceNote)return;persistVoiceText(voiceNote,$('voiceText').value);$('voiceSave').disabled=!$('voiceText').value.trim()||voiceNote.loading||voiceNote.stopping;};
    $('voiceCategory').onchange=()=>{if(voiceNote)persistVoiceText(voiceNote,$('voiceText').value);};
    $('voiceNoteDialog').addEventListener('close',()=>closeVoiceNote());
    $('settingsForm').onsubmit=saveSettings;$('noteForm').onsubmit=saveNote;$('deleteNote').onclick=deleteNote;$('deleteSession').onclick=deleteSession;
    $('useClock').onclick=()=>{if(!selectClockSource('phone'))return;$('settingsTC').value=clockTC(new Date(),$('settingsFps').value);$('settingsTC').disabled=true;if($('settingsTCField'))$('settingsTCField').hidden=true;notify('La sessione userà l’ora del telefono dal momento di Inizia.');};
    $('sessionsButton').onclick=()=>{$('sessionsDialog').showModal();};
    $('importFile').onchange=e=>importFile(e.target.files[0]);
    $('backupAll').onclick=()=>{if(pendingFlush){notify('Attendi l’ultima trascrizione prima del backup completo.');return;}if(active)current().duration=elapsed();saveFile('RAMBLA-Log-tutte-le-sessioni.json',JSON.stringify({app:'RAMBLA Log',version:1,exportedAt:new Date().toISOString(),sessions:store.sessions},null,2),'application/json');};
    $('recoverContinue').onclick=()=>startSession(true);$('recoverClose').onclick=endSession;
    if($('syncCameraButton'))$('syncCameraButton').onclick=openScanner;
    if($('scanDialog')){
      $('scanVideo').addEventListener('loadedmetadata',updateScanReticle);window.addEventListener('resize',updateScanReticle);
      $('scanDialog').addEventListener('close',closeScanner);$('scanApply').onclick=applyScan;
      $('scanExposure').oninput=()=>{
        latestReading=null;$('scanApply').disabled=true;$('scanLock').textContent='VERIFICO L’AVANZAMENTO';
        const value=Number($('scanExposure').value),token=scanGeneration;
        $('scanExposureValue').textContent=(value>0?'+':'')+value.toFixed(1);
        scanner?.setExposure(value).catch(error=>{if(token===scanGeneration)$('scanStatus').textContent=error.message;});
      };
    }
    document.addEventListener('keydown',e=>{if(e.repeat||e.ctrlKey||e.metaKey||e.altKey||/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)||document.querySelector('dialog[open]'))return;const n=Number(e.key);if(n>=1&&n<=6){e.preventDefault();mark(CATEGORIES[n-1].id);}});
    const backgroundPause=()=>{
      const finished=active?pauseSession('background'):(persist(),Promise.resolve());
      const voiceFinished=voiceNote?closeVoiceNote({resume:false}):Promise.resolve();
      if(scanner)$('scanDialog').close();
      return Promise.all([finished,voiceFinished]);
    };
    document.addEventListener('visibilitychange',()=>{if(document.hidden)return backgroundPause();render();});
    window.addEventListener('pagehide',backgroundPause);
    window.addEventListener('online',()=>$('offlineBanner').hidden=true);window.addEventListener('offline',()=>$('offlineBanner').hidden=false);
    // On the shortest screens, keep every pad and both note actions visible.
    // The same capture controls remain available from the settings gear.
    if(window.matchMedia){
      const compact=window.matchMedia('(max-width: 620px) and (max-height: 580px)'),options=document.querySelector('.transport-options'),buttons=document.querySelector('.transport-buttons');
      const placeCaptureControls=()=>{if(compact.matches)$('settingsCaptureSlot').append(options);else buttons.parentElement.insertBefore(options,buttons);};
      placeCaptureControls();if(compact.addEventListener)compact.addEventListener('change',placeCaptureControls);else compact.addListener(placeCaptureControls);
    }
  }
  function initPWA() {
    if('serviceWorker' in navigator&&location.protocol==='https:'&&!window.RAMBLA_PORTABLE){
      navigator.serviceWorker.register('./sw.js').then(()=>navigator.serviceWorker.ready).then(()=>{$('offlineReady').textContent='App disponibile offline · dati su questo dispositivo';}).catch(()=>{$('offlineReady').textContent='Salvataggio locale · cache offline non disponibile';});
    }
    if(window.RAMBLA_PORTABLE){$('offlineReady').textContent='Copia HTML · per il microfono apri da HTTPS';}
    $('offlineBanner').hidden=navigator.onLine;
  }
  loadStore();bind();render();initPWA();
  // The clock is cheap UI work only. Data is saved on actual changes, pause,
  // visibilitychange and pagehide, never by repeatedly rewriting the archive.
  setInterval(displayTC,80);
})();
