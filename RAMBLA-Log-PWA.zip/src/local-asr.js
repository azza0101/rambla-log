/*
 * RAMBLA Log — optional, experimental local speech recognition.
 * Loading this file does not contact a server or request the microphone.
 * The first explicit load()/start() fetches the runtime and model. Audio is
 * processed by a dedicated browser worker; it is not sent to an ASR service.
 *
 * Pins and API references (checked 2026-10-26):
 * https://huggingface.co/docs/transformers.js/v3.8.1/en/installation
 * https://huggingface.co/docs/transformers.js/v3.8.1/en/api/pipelines
 * https://huggingface.co/Xenova/whisper-tiny/tree/886cdcc0ac3be42c545d24403ccb116ff9387d97/onnx
 * https://onnxruntime.ai/docs/tutorials/web/env-flags-and-session-options.html
 *
 * q8 weights are approximately 40.8 MB; runtime/tokenizer downloads and RAM
 * are additional. Cache retention and real-time speed on iPhone are NOT
 * guaranteed. Consecutive ~8-second windows avoid overlap duplicates, but
 * words at boundaries and model timestamps may be imprecise. Keep the page
 * foregrounded. Capture is stopped explicitly if inference cannot keep up.
 */
(function (global) {
  'use strict';

  const SAMPLE_RATE = 16000;
  const CHUNK_SAMPLES = 8 * SAMPLE_RATE;
  const MAX_QUEUED = 2;
  const LOAD_TIMEOUT_MS = 180000;
  const INFERENCE_TIMEOUT_MS = 180000;

  const WORKER_SOURCE = `
    let recognizer = null;
    let loading = null;
    async function load() {
      if (recognizer) return recognizer;
      if (!loading) loading = (async () => {
        const { pipeline, env } = await import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1');
        env.allowLocalModels = false;
        // CacheStorage is optional (for example on an HTTP QA preview).
        // Its absence must not prevent an otherwise supported inference.
        env.useBrowserCache = typeof self.caches !== 'undefined';
        env.backends.onnx.wasm.numThreads = 1;
        env.backends.onnx.wasm.proxy = false;
        env.backends.onnx.wasm.wasmPaths = 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/dist/';
        recognizer = await pipeline('automatic-speech-recognition', 'Xenova/whisper-tiny', {
          revision: '886cdcc0ac3be42c545d24403ccb116ff9387d97',
          device: 'wasm',
          dtype: 'q8',
          progress_callback: (progress) => self.postMessage({ type: 'progress', progress })
        });
        return recognizer;
      })().catch(error => { loading = null; throw error; });
      return loading;
    }
    self.onmessage = async ({ data }) => {
      try {
        if (data.type === 'load') {
          await load();
          self.postMessage({ type: 'ready' });
        } else if (data.type === 'transcribe') {
          const pipe = await load();
          const output = await pipe(data.audio, {
            language: data.language || 'it',
            task: 'transcribe',
            return_timestamps: true
          });
          self.postMessage({ type: 'result', id: data.id, output });
        }
      } catch (error) {
        self.postMessage({ type: 'error', id: data.id, message: String(error?.message || error) });
      }
    };
  `;

  // Batch 4096 frames before crossing the worklet boundary. The processor
  // outputs silence, so captured microphone audio is never played aloud.
  const CAPTURE_SOURCE = `
    class RamblaPCM extends AudioWorkletProcessor {
      constructor() {
        super();
        this.samples = new Float32Array(4096);
        this.length = 0;
        this.active = true;
        this.port.onmessage = ({ data }) => {
          if (data.type === 'stop') {
            this.active = false;
            this.flush();
            this.port.postMessage({ type: 'flushed' });
          }
        };
      }
      flush() {
        if (!this.length) return;
        const samples = this.samples.slice(0, this.length);
        this.port.postMessage({ type: 'pcm', samples }, [samples.buffer]);
        this.length = 0;
      }
      process(inputs) {
        const channels = inputs[0];
        if (!this.active || !channels?.length || !channels[0].length) return true;
        for (let i = 0; i < channels[0].length; i++) {
          let value = 0;
          for (let c = 0; c < channels.length; c++) value += channels[c][i];
          this.samples[this.length++] = value / channels.length;
          if (this.length === this.samples.length) this.flush();
        }
        return true;
      }
    }
    registerProcessor('rambla-pcm', RamblaPCM);
  `;

  function abortError() {
    const error = new Error('Avvio della trascrizione annullato.');
    error.name = 'AbortError';
    return error;
  }

  function asError(value, fallback) {
    // DOMException.message is read-only. Wrap it before adding a useful
    // explanation or an unprocessed-audio interval.
    if (value instanceof Error && Object.getOwnPropertyDescriptor(value, 'message')?.writable) return value;
    const error = new Error(value?.message || fallback || String(value));
    if (value?.name) error.name = value.name;
    return error;
  }

  class RamblaLocalASR {
    constructor({ onStatus, onSegment, onError } = {}) {
      this.onStatus = typeof onStatus === 'function' ? onStatus : function () {};
      this.onSegment = typeof onSegment === 'function' ? onSegment : function () {};
      this.onError = typeof onError === 'function' ? onError : function () {};
      this.state = 'stopped';
      this.language = 'it';
      this._worker = null;
      this._workerURL = null;
      this._ready = false;
      this._destroyed = false;
      this._loadTicket = null;
      this._loadPromise = null;
      this._startPromise = null;
      this._stopPromise = null;
      this._generation = 0;
      this._jobId = 0;
      this._queue = [];
      this._inFlight = null;
      this._drainWaiters = [];
      this._stream = null;
      this._context = null;
      this._processor = null;
      this._source = null;
      this._gain = null;
      this._active = false;
      this._acceptingAudio = false;
      this._lastError = null;
      this._parts = [];
      this._partLength = 0;
      this._elapsed = function () { return 0; };
    }

    get captureStream() { return this._stream; }
    get ready() { return this._ready; }

    _status(state, message, extra) {
      this.state = state;
      try { this.onStatus(Object.assign({ state, message }, extra || {})); }
      catch (error) { console.error('RAMBLA local ASR status callback', error); }
    }

    _report(error) {
      if (error._ramblaReported) return;
      error._ramblaReported = true;
      try { this.onError(error); }
      catch (callbackError) { console.error('RAMBLA local ASR error callback', callbackError); }
    }

    _ensureWorker() {
      if (this._worker) return;
      if (typeof global.Worker !== 'function' || typeof WebAssembly === 'undefined') {
        throw new Error('Questo browser non supporta il motore locale. Usa la trascrizione del browser o le note manuali.');
      }
      const url = URL.createObjectURL(new Blob([WORKER_SOURCE], { type: 'text/javascript' }));
      try {
        this._worker = new global.Worker(url, { type: 'module', name: 'rambla-local-asr' });
        this._workerURL = url;
      } catch (error) {
        URL.revokeObjectURL(url);
        throw new Error('Impossibile avviare il motore locale in questa pagina. Apri il sito direttamente in Safari. ' + (error.message || ''));
      }
      this._worker.onmessage = event => this._onWorkerMessage(event.data);
      this._worker.onerror = event => this._fatal(new Error('Motore locale interrotto: ' + (event.message || 'errore del worker.')));
      this._worker.onmessageerror = () => this._fatal(new Error('Il motore locale ha restituito dati non leggibili.'));
    }

    load({ language = this.language } = {}) {
      if (this._destroyed) return Promise.reject(new Error('Il motore locale è stato chiuso.'));
      this.language = String(language || 'it').toLowerCase().split('-')[0];
      if (this._ready) return Promise.resolve(this);
      if (this._loadPromise) return this._loadPromise;
      this._lastError = null;
      this._status('loading', 'Preparo Whisper locale. Al primo uso servono circa 41 MB di modello, più il runtime.');
      try { this._ensureWorker(); }
      catch (error) {
        this._status('error', error.message);
        this._report(error);
        return Promise.reject(error);
      }
      this._loadPromise = new Promise((resolve, reject) => {
        this._loadTicket = { resolve, reject };
      });
      this._loadTimer = setTimeout(() => this._fatal(new Error('Il download del modello sta impiegando troppo tempo. Controlla la connessione e riprova.')), LOAD_TIMEOUT_MS);
      this._worker.postMessage({ type: 'load' });
      return this._loadPromise;
    }

    _onWorkerMessage(message) {
      if (message.type === 'progress' && this._loadTicket) {
        const info = message.progress || {};
        const progress = Number(info.progress);
        const file = String(info.file || '').split('/').pop();
        if (info.status === 'progress' && Number.isFinite(progress)) {
          const percent = Math.max(0, Math.min(100, Math.round(progress)));
          this._status('loading', 'Download ' + (file || 'modello') + ': ' + percent + '%', { progress: percent });
        }
      } else if (message.type === 'ready') {
        clearTimeout(this._loadTimer);
        this._ready = true;
        const ticket = this._loadTicket;
        this._loadTicket = null;
        this._loadPromise = null;
        this._status('ready', 'Whisper locale pronto. I risultati arriveranno a blocchi; la velocità dipende dal dispositivo.', { progress: 100 });
        ticket?.resolve(this);
      } else if (message.type === 'result' && this._inFlight?.id === message.id) {
        clearTimeout(this._inferenceTimer);
        const clip = this._inFlight;
        this._inFlight = null;
        this._emitSegments(clip, message.output);
        this._pump();
      } else if (message.type === 'error') {
        if (message.id && this._inFlight?.id !== message.id) return;
        this._fatal(new Error('Whisper locale non ha completato l’elaborazione. ' + String(message.message || 'Controlla connessione e memoria disponibile.')));
      }
    }

    start({ language = this.language, getElapsed } = {}) {
      if (this._destroyed) return Promise.reject(new Error('Il motore locale è stato chiuso.'));
      if (this._startPromise) return this._startPromise;
      if (this._active) return Promise.resolve(this._stream);
      const generation = ++this._generation;
      this._startPromise = this._startCapture({ language, getElapsed, generation }).finally(() => { this._startPromise = null; });
      return this._startPromise;
    }

    async _startCapture({ language, getElapsed, generation }) {
      try {
        if (this._stopPromise) await this._stopPromise;
        if (generation !== this._generation || this._destroyed) throw abortError();
        if (global.isSecureContext === false || !global.navigator.mediaDevices?.getUserMedia) {
          throw new Error('Il microfono richiede una pagina HTTPS aperta direttamente in Safari. Puoi continuare con marker e note.');
        }
        const AudioContext = global.AudioContext || global.webkitAudioContext;
        if (!AudioContext) throw new Error('La cattura audio locale non è disponibile in questo browser.');
        this._lastError = null;
        this._stopReason = '';
        this._parts = [];
        this._partLength = 0;
        this._inputCount = 0;
        this._nextInputPosition = 0;
        this._lastInput = 0;
        this._outputCount = 0;
        this._captureBase = null;
        this._elapsed = typeof getElapsed === 'function' ? getElapsed : (() => (performance.now() - this._startedAt) / 1000);
        this._startedAt = performance.now();
        const context = new AudioContext({ latencyHint: 'interactive' });
        this._context = context;
        // Resume immediately while start() is still inside the user's gesture.
        // No microphone is opened during the possibly long model download.
        context.resume().catch(function () {});
        await this.load({ language });
        if (generation !== this._generation || this._destroyed) throw abortError();
        const stream = await global.navigator.mediaDevices.getUserMedia({
          audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true },
          video: false
        });
        if (generation !== this._generation || this._destroyed) {
          stream.getTracks().forEach(track => track.stop());
          throw abortError();
        }
        this._stream = stream;
        await this._makeCaptureNode(context);
        if (generation !== this._generation || this._destroyed) throw abortError();
        await context.resume();
        if (context.state !== 'running') throw new Error('Audio sospeso da iPhone. Mantieni questa pagina aperta e tocca Avvia di nuovo.');
        this._source = context.createMediaStreamSource(stream);
        this._gain = context.createGain();
        this._gain.gain.value = 0;
        this._active = true;
        this._acceptingAudio = true;
        this._source.connect(this._processor);
        this._processor.connect(this._gain);
        this._gain.connect(context.destination);
        this._trackInterrupt = () => this._interrupt('Il microfono è stato interrotto. Resta in questa pagina e riavvia la trascrizione.');
        stream.getAudioTracks().forEach(track => {
          track.addEventListener('ended', this._trackInterrupt);
          track.addEventListener('mute', this._trackInterrupt);
        });
        this._contextInterrupt = () => {
          if (this._active && context.state !== 'running') this._interrupt('La cattura audio è stata sospesa dal dispositivo. Riapri la pagina e riavvia.');
        };
        context.addEventListener('statechange', this._contextInterrupt);
        this._status('listening', 'Ascolto locale attivo. Trascrivo blocchi di circa 8 secondi; mantieni la pagina in primo piano.');
        return stream;
      } catch (cause) {
        const canceled = generation !== this._generation || this._destroyed || cause?.name === 'AbortError';
        const error = canceled ? abortError() : asError(cause);
        await this._releaseCapture();
        if (!canceled) {
          if (error.name === 'NotAllowedError') error.message = 'Accesso al microfono negato. Consenti il microfono nelle impostazioni del sito in Safari e riprova.';
          this._status('error', error.message);
          this._report(error);
        }
        throw error;
      }
    }

    async _makeCaptureNode(context) {
      if (context.audioWorklet && typeof global.AudioWorkletNode === 'function') {
        const url = URL.createObjectURL(new Blob([CAPTURE_SOURCE], { type: 'text/javascript' }));
        try {
          await context.audioWorklet.addModule(url);
          const processor = new global.AudioWorkletNode(context, 'rambla-pcm', { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [1] });
          processor.port.onmessage = ({ data }) => {
            if (data.type === 'pcm') this._appendPCM(data.samples, context.sampleRate);
            else if (data.type === 'flushed') this._flushResolve?.();
          };
          processor.onprocessorerror = () => this._interrupt('La cattura audio locale si è interrotta. Riavvia la trascrizione.');
          this._processor = processor;
          return;
        } catch (error) {
          // Older Safari/CSP configurations may lack AudioWorklet. The
          // deprecated ScriptProcessor fallback still captures real audio.
          if (context.state === 'closed') throw error;
        } finally { URL.revokeObjectURL(url); }
      }
      if (typeof context.createScriptProcessor !== 'function') throw new Error('Questo browser non permette la cattura PCM richiesta da Whisper locale.');
      const processor = context.createScriptProcessor(4096, 1, 1);
      processor.onaudioprocess = event => {
        const input = event.inputBuffer;
        const samples = input.getChannelData(0);
        if (input.numberOfChannels > 1) {
          const mono = new Float32Array(samples.length);
          for (let channel = 0; channel < input.numberOfChannels; channel++) {
            const values = input.getChannelData(channel);
            for (let i = 0; i < mono.length; i++) mono[i] += values[i] / input.numberOfChannels;
          }
          this._appendPCM(mono, context.sampleRate);
        } else this._appendPCM(samples, context.sampleRate);
        for (let channel = 0; channel < event.outputBuffer.numberOfChannels; channel++) event.outputBuffer.getChannelData(channel).fill(0);
      };
      this._processor = processor;
    }

    _appendPCM(input, sourceRate) {
      if (!this._acceptingAudio || !input?.length) return;
      if (this._captureBase === null) {
        const elapsed = Number(this._elapsed());
        this._captureBase = Math.max(0, (Number.isFinite(elapsed) ? elapsed : 0) - input.length / sourceRate);
      }
      // Continuous linear resampling, with the previous input sample retained
      // across callbacks. Rounding each block independently would drift.
      const step = sourceRate / SAMPLE_RATE;
      const blockStart = this._inputCount;
      const blockEnd = blockStart + input.length - 1;
      const output = new Float32Array(Math.max(0, Math.ceil((blockEnd - this._nextInputPosition) / step) + 1));
      let length = 0;
      while (this._nextInputPosition <= blockEnd + 1e-7) {
        const position = this._nextInputPosition - blockStart;
        const index = Math.floor(position);
        const fraction = position - index;
        if (index + 1 >= input.length && fraction > 1e-7) break;
        const left = index < 0 ? this._lastInput : input[index];
        const right = input[Math.min(input.length - 1, Math.max(0, index + 1))];
        output[length++] = left + (right - left) * fraction;
        this._nextInputPosition += step;
      }
      this._inputCount += input.length;
      this._lastInput = input[input.length - 1];
      if (!length) return;
      this._parts.push(length === output.length ? output : output.slice(0, length));
      this._partLength += length;
      if (this._active && this._partLength >= CHUNK_SAMPLES) this._flushAudio();
    }

    _flushAudio() {
      if (!this._partLength) return;
      const audio = new Float32Array(this._partLength);
      let offset = 0;
      for (const part of this._parts) { audio.set(part, offset); offset += part.length; }
      const start = (this._captureBase || 0) + this._outputCount / SAMPLE_RATE;
      const end = start + audio.length / SAMPLE_RATE;
      this._outputCount += audio.length;
      this._parts = [];
      this._partLength = 0;
      // Suppress only essentially digital silence; this is not a speech/VAD
      // classifier, and it cannot guarantee Whisper never hallucinates.
      let squareSum = 0;
      for (let i = 0; i < audio.length; i++) squareSum += audio[i] * audio[i];
      if (Math.sqrt(squareSum / audio.length) < 0.00001) return;
      if (this._queue.length >= MAX_QUEUED) {
        // A worklet may deliver its final sub-buffer while stop() flushes.
        // Append it to the last waiting window instead of losing that audio
        // or exceeding the queue bound.
        const last = this._queue[this._queue.length - 1];
        const joined = new Float32Array(last.audio.length + audio.length);
        joined.set(last.audio); joined.set(audio, last.audio.length);
        last.audio = joined;
        last.end = end;
      } else this._queue.push({ audio, start, end });
      this._pump();
      if (this._queue.length >= MAX_QUEUED && this._active) {
        const error = new Error('Whisper non tiene il ritmo su questo dispositivo: fermo il microfono ed elaboro tutta la coda. Riavvia per continuare o usa la trascrizione del browser.');
        error.code = 'backpressure';
        this._stopReason = 'Microfono fermato perché il modello era in ritardo. La coda acquisita è stata elaborata.';
        this._report(error);
        this.stop({ flush: true });
      }
    }

    _pump() {
      if (this._inFlight || !this._ready || !this._worker) return;
      const clip = this._queue.shift();
      if (!clip) {
        this._resolveDrain();
        if (this._active) this._status('listening', 'Ascolto locale attivo. In attesa del prossimo blocco audio.');
        return;
      }
      const id = ++this._jobId;
      this._inFlight = { id, start: clip.start, end: clip.end };
      this._status('processing', 'Trascrivo audio ' + clip.start.toFixed(1) + '–' + clip.end.toFixed(1) + ' s' + (this._active ? '. Il microfono resta attivo.' : '. Microfono fermo.'));
      this._inferenceTimer = setTimeout(() => this._fatal(new Error('L’elaborazione locale è troppo lenta o bloccata. Prova la trascrizione del browser.')), INFERENCE_TIMEOUT_MS);
      try { this._worker.postMessage({ type: 'transcribe', id, audio: clip.audio, language: this.language }, [clip.audio.buffer]); }
      catch (error) { this._fatal(asError(error)); }
    }

    _emitSegments(clip, output) {
      const duration = Math.max(0, clip.end - clip.start);
      const chunks = Array.isArray(output?.chunks) && output.chunks.some(chunk => String(chunk.text || '').trim())
        ? output.chunks : [{ text: output?.text || '', timestamp: [0, duration] }];
      const segments = [];
      let previousEnd = 0;
      for (const chunk of chunks) {
        const text = String(chunk.text || '').trim();
        if (!text) continue;
        const stamp = Array.isArray(chunk.timestamp) ? chunk.timestamp : [0, duration];
        const rawStart = stamp[0] === null ? previousEnd : Number(stamp[0]);
        const rawEnd = stamp[1] === null ? duration : Number(stamp[1]);
        let start = Math.max(previousEnd, Math.min(duration, Number.isFinite(rawStart) ? rawStart : previousEnd));
        let end = Math.max(start, Math.min(duration, Number.isFinite(rawEnd) ? rawEnd : duration));
        if (end <= start) {
          if (segments.length) { segments[segments.length - 1].text += ' ' + text; continue; }
          start = 0; end = duration;
        }
        previousEnd = end;
        segments.push({ start: clip.start + start, end: clip.start + end, text });
      }
      for (const segment of segments) {
        try { this.onSegment(segment); }
        catch (error) { console.error('RAMBLA local ASR segment callback', error); }
      }
    }

    _interrupt(message) {
      if (!this._active) return;
      const error = new Error(message);
      error.code = 'interrupted';
      this._stopReason = message;
      this._report(error);
      this.stop({ flush: true });
    }

    async _releaseCapture() {
      this._active = false;
      const context = this._context;
      const processor = this._processor;
      const stream = this._stream;
      if (context && this._contextInterrupt) context.removeEventListener('statechange', this._contextInterrupt);
      if (stream && this._trackInterrupt) stream.getAudioTracks().forEach(track => {
        track.removeEventListener('ended', this._trackInterrupt);
        track.removeEventListener('mute', this._trackInterrupt);
      });
      if (processor?.port && this._acceptingAudio) {
        await new Promise(resolve => {
          let timer;
          const finish = () => { clearTimeout(timer); this._flushResolve = null; resolve(); };
          this._flushResolve = finish;
          timer = setTimeout(finish, 300);
          try { processor.port.postMessage({ type: 'stop' }); } catch (_) { finish(); }
        });
      }
      this._acceptingAudio = false;
      if (processor) {
        processor.onaudioprocess = null;
        processor.onprocessorerror = null;
        if (processor.port) processor.port.onmessage = null;
      }
      for (const audioNode of [this._source, processor, this._gain]) {
        try { audioNode?.disconnect(); } catch (_) {}
      }
      if (stream) stream.getTracks().forEach(track => track.stop());
      this._stream = null;
      this._source = null;
      this._processor = null;
      this._gain = null;
      this._context = null;
      if (context && context.state !== 'closed') {
        try { await context.close(); } catch (_) {}
      }
    }

    _resolveDrain() {
      if (this._inFlight || this._queue.length) return;
      this._drainWaiters.splice(0).forEach(resolve => resolve());
    }

    _drain() {
      if (!this._inFlight && !this._queue.length) return Promise.resolve();
      return new Promise(resolve => this._drainWaiters.push(resolve));
    }

    _terminateWorker(reason) {
      clearTimeout(this._loadTimer);
      clearTimeout(this._inferenceTimer);
      this._worker?.terminate();
      this._worker = null;
      this._ready = false;
      if (this._workerURL) URL.revokeObjectURL(this._workerURL);
      this._workerURL = null;
      const ticket = this._loadTicket;
      this._loadTicket = null;
      this._loadPromise = null;
      ticket?.reject(reason || abortError());
    }

    _fatal(cause) {
      const error = asError(cause);
      const intervals = [this._inFlight, ...this._queue].filter(Boolean).map(clip => ({ start: clip.start, end: clip.end }));
      if (this._partLength) intervals.push({ start: (this._captureBase || 0) + this._outputCount / SAMPLE_RATE, end: (this._captureBase || 0) + (this._outputCount + this._partLength) / SAMPLE_RATE });
      if (intervals.length) {
        error.unprocessed = intervals;
        error.message += ' Audio non trascritto: ' + intervals[0].start.toFixed(1) + '–' + intervals[intervals.length - 1].end.toFixed(1) + ' s.';
      }
      this._lastError = error;
      this._terminateWorker(error);
      this._queue = [];
      this._inFlight = null;
      this._parts = [];
      this._partLength = 0;
      this._releaseCapture();
      this._resolveDrain();
      this._status('error', error.message);
      this._report(error);
    }

    stop({ flush = true } = {}) {
      if (this._stopPromise) return this._stopPromise;
      ++this._generation;
      this._active = false;
      if (this._loadTicket) this._terminateWorker(abortError());
      this._stopPromise = (async () => {
        await this._releaseCapture();
        if (flush && this._ready) {
          this._flushAudio();
          await this._drain();
        } else {
          if (this._inFlight) this._terminateWorker(abortError());
          this._queue = [];
          this._inFlight = null;
          this._parts = [];
          this._partLength = 0;
          this._resolveDrain();
        }
        if (this._lastError) this._status('error', this._lastError.message);
        else this._status('stopped', this._stopReason || 'Trascrizione locale fermata. Audio acquisito elaborato.');
      })().finally(() => { this._stopPromise = null; });
      return this._stopPromise;
    }

    async destroy() {
      this._destroyed = true;
      // destroy() is also the escape hatch for an inference already awaited
      // by stop({flush:true}); do not wait for that worker to finish.
      this._terminateWorker(abortError());
      this._queue = [];
      this._inFlight = null;
      this._parts = [];
      this._partLength = 0;
      this._resolveDrain();
      await this.stop({ flush: false });
    }
  }

  global.RamblaLocalASR = RamblaLocalASR;
})(window);
