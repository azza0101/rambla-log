'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const cameraPath = path.join(__dirname, '..', 'src', 'timecode-camera.js');

// Independent fixture: only the documented core boundary, no camera/filter logic.
const fixtureCore = {
  rateInfo(id) {
    if (!['25', '29.97', '29.97df'].includes(id)) throw Error('FPS non validi');
    return { id, nominal: id === '25' ? 25 : 30, rate: id === '25' ? 25 : 30000 / 1001, drop: id.endsWith('df') };
  },
  parseTC(tc, id) {
    const r = this.rateInfo(id), m = /^(\d{2}):(\d{2}):(\d{2})([:;])(\d{2})$/.exec(tc);
    if (!m) throw Error('Timecode non valido');
    const [h, min, sec, frame] = [m[1], m[2], m[3], m[5]].map(Number);
    if (h > 23 || min > 59 || sec > 59 || frame >= r.nominal || (!r.drop && m[4] === ';')) throw Error('Timecode non valido');
    if (r.drop && min % 10 && sec === 0 && frame < 2) throw Error('Drop-frame impossibile');
    return ((h * 3600 + min * 60 + sec) * r.nominal + frame) - (r.drop ? 2 * (h * 60 + min - Math.floor((h * 60 + min) / 10)) : 0);
  },
};
function moduleAPI() {
  assert.ok(fs.existsSync(cameraPath), 'The camera/timecode implementation has not been written yet');
  return require(cameraPath);
}
const reading = (frames, capturedAt, confidence = 90) => ({ frames, capturedAt, confidence });

test('OCR accepts explicit frame separators and validates through the core', () => {
  const { parseReading } = moduleAPI();
  assert.deepEqual(parseReading('TC 01 : 02 : 03 : 04\n', '25', fixtureCore), { timecode: '01:02:03:04', frames: 93079 });
  assert.deepEqual(parseReading('00:01:00;02', '29.97df', fixtureCore), { timecode: '00:01:00;02', frames: 1800 });
  for (const value of ['01020304', '1:02:03:04', '001:02:03:04', '01:02:03:045', '01:02:03:04:05', '00:00:00:25', '24:00:00:00', '00:60:00:00', '00:00:00;01', '01:02:03:04 02:03:04:05', 'O1:02:03:04']) {
    assert.equal(parseReading(value, '25', fixtureCore), null, value);
  }
  assert.equal(parseReading('00:01:00;00', '29.97df', fixtureCore), null);
});

test('stability requires three confident progressing readings matching elapsed capture time', () => {
  const { StabilityFilter } = moduleAPI(), f = new StabilityFilter('25', fixtureCore);
  assert.equal(f.push(reading(90000, 1000)).stable, false);
  assert.equal(f.push(reading(90010, 1400)).stable, false);
  assert.equal(f.push(reading(90020, 1800)).stable, true);
  assert.equal(f.push(reading(90020, 2200)).stable, false, 'a frozen display must lose the lock');
});

test('frozen or low-confidence OCR never creates a stable clock', () => {
  const { StabilityFilter } = moduleAPI(), f = new StabilityFilter('25', fixtureCore);
  for (const t of [0, 400, 800, 1200]) assert.equal(f.push(reading(1234, t)).stable, false);
  f.reset();
  f.push(reading(0, 0));
  f.push(reading(10, 400, 59));
  assert.equal(f.push(reading(20, 800)).stable, false);
  assert.equal(f.push(reading(30, 1200)).stable, false);
  assert.equal(f.push(reading(40, 1600)).stable, true);
});

test('inconsistent jumps, backward timestamps and cumulative drift restart validation', () => {
  const { StabilityFilter } = moduleAPI(), f = new StabilityFilter('25', fixtureCore);
  f.push(reading(0, 0));
  assert.equal(f.push(reading(20, 400)).reason, 'incoherent');
  assert.equal(f.push(reading(30, 400)).stable, false);
  f.reset();
  f.push(reading(0, 0));
  f.push(reading(13, 400));
  assert.equal(f.push(reading(26, 800)).stable, false, '3 frames per interval cannot accumulate unchecked');
});

test('variable OCR duration uses capture times and fractional fps rather than a fixed cadence', () => {
  const { StabilityFilter } = moduleAPI(), f = new StabilityFilter('29.97', fixtureCore);
  assert.equal(f.push(reading(0, 1000)).stable, false);
  assert.equal(f.push(reading(60, 3002)).stable, false);
  assert.equal(f.push(reading(150, 6005)).stable, true);
  assert.equal(f.push(reading(750, 26025)).stable, false, 'a long interruption requires a new lock');
});

test('timecode rollover at midnight retains a coherent advancing lock', () => {
  const { StabilityFilter } = moduleAPI();
  for (const [fps, a, b, c, dt] of [['25', 2159990, 0, 10, 400], ['29.97df', 2589398, 0, 10, 1001 / 3]]) {
    const f = new StabilityFilter(fps, fixtureCore);
    f.push(reading(a, 0));
    assert.equal(f.push(reading(b, dt)).stable, false, fps);
    assert.equal(f.push(reading(c, dt * 2)).stable, true, fps);
  }
});

test('ROI coordinates are finite and remain inside the source image', () => {
  const { normalizeROI } = moduleAPI();
  assert.deepEqual(normalizeROI({ x: .1, y: .4, width: .8, height: .2 }), { x: .1, y: .4, width: .8, height: .2 });
  const r = normalizeROI({ x: -.2, y: .9, width: 2, height: .5 });
  assert.equal(r.x, 0);
  assert.ok(r.x + r.width <= 1 && r.y + r.height <= 1);
  assert.throws(() => normalizeROI({ x: NaN, y: 0, width: 1, height: 1 }));
  assert.throws(() => normalizeROI({ x: 0, y: 0, width: 0, height: 1 }));
});

function deferred() { let resolve, reject; const promise = new Promise((a, b) => { resolve = a; reject = b; }); return { promise, resolve, reject }; }
async function flush() { for (let i = 0; i < 20; i++) await Promise.resolve(); }
function browser(options = {}) {
  moduleAPI();
  const state = { now: 1000, draws: [], workers: [], readings: [], statuses: [], errors: [], stopped: 0, revoked: 0, constraints: null };
  const trackEvents = new Map();
  const track = { stop() { state.stopped++; }, getCapabilities() { return {}; }, addEventListener(name, fn) { trackEvents.set(name, fn); }, removeEventListener(name) { trackEvents.delete(name); } };
  const stream = { getTracks: () => [track], getVideoTracks: () => [track] };
  const video = { videoWidth: 1920, videoHeight: 1080, readyState: 4, setAttribute() {}, play: () => Promise.resolve(), pause() {}, srcObject: null };
  const ctx = { drawImage(...args) { state.draws.push({ at: state.now, args }); }, clearRect() {} };
  const canvas = { width: 0, height: 0, getContext: () => ctx, toBlob: cb => cb(new Blob(['png'], { type: 'image/png' })) };
  class Worker {
    constructor() { this.jobs = []; this.terminated = false; state.workers.push(this); }
    postMessage(packet) {
      this.jobs.push(packet);
      if (options.holdLoad && packet.action === 'load') return;
      if (packet.action !== 'recognize') queueMicrotask(() => {
        if (!this.terminated) this.onmessage({ data: { ...packet, status: options.failLoad && packet.action === 'loadLanguage' ? 'reject' : 'resolve', data: options.failLoad ? 'Network failure' : {} } });
      });
    }
    answer(text, confidence = 95) {
      const packet = this.jobs.findLast(p => p.action === 'recognize');
      assert.ok(packet, 'an OCR job was submitted');
      this.onmessage({ data: { ...packet, status: 'resolve', data: { text, confidence } } });
    }
    terminate() { this.terminated = true; }
  }
  const window = { RamblaCore: fixtureCore, Worker, Blob, Uint8Array, AbortController, performance: { now: () => state.now }, URL: { createObjectURL: () => 'blob:ocr', revokeObjectURL() { state.revoked++; } }, setTimeout, clearTimeout, navigator: { mediaDevices: { getUserMedia(constraints) { state.constraints = constraints; return options.cameraPromise || Promise.resolve(stream); } } }, isSecureContext: true };
  vm.runInNewContext(fs.readFileSync(cameraPath, 'utf8'), { window, setTimeout, clearTimeout, Blob, Uint8Array, AbortController, console });
  const scanner = new window.RamblaTimecodeCamera({ video, canvas, onStatus: value => state.statuses.push(value), onReading: value => state.readings.push(value), onError: error => state.errors.push(error) });
  return { state, scanner, video, canvas, stream, endCamera() { if (trackEvents.has('ended')) trackEvents.get('ended')(); } };
}

test('camera capture is opt-in and crop timestamp precedes delayed OCR completion', async () => {
  const h = browser();
  assert.equal(h.state.constraints, null);
  await h.scanner.start({ fps: '25', roi: { x: .1, y: .4, width: .8, height: .2 } });
  await flush();
  assert.equal(h.state.constraints.audio, false);
  assert.equal(h.state.constraints.video.facingMode.ideal, 'environment');
  assert.equal(h.video.playsInline, true);
  assert.equal(h.video.muted, true);
  assert.deepEqual(h.state.draws[0].args.slice(1, 5), [192, 432, 1536, 216]);
  h.state.now = 6000;
  h.state.workers[0].answer('01:00:00:00');
  await flush();
  assert.equal(h.state.readings[0].capturedAt, 1000);
  assert.equal(h.state.readings[0].frames, 90000);
  await h.scanner.stop();
  assert.equal(h.state.stopped, 1);
  assert.equal(h.video.srcObject, null);
  assert.equal(h.state.workers[0].terminated, true);
  assert.equal(h.state.revoked, 1);
});

test('stopping while the OCR model loads terminates the native worker and camera immediately', async () => {
  const h = browser({ holdLoad: true });
  const starting = h.scanner.start({ fps: '25' });
  await flush();
  assert.equal(h.state.workers.length, 1);
  await h.scanner.stop();
  assert.equal(await starting, false);
  assert.equal(h.state.workers[0].terminated, true);
  assert.equal(h.state.stopped, 1);
  assert.equal(h.state.errors.length, 0);
});

test('a denied model download releases every resource and reports an error', async () => {
  const h = browser({ failLoad: true });
  await assert.rejects(h.scanner.start({ fps: '25' }), /Network failure/);
  assert.equal(h.state.workers[0].terminated, true);
  assert.equal(h.state.stopped, 1);
  assert.equal(h.video.srcObject, null);
  assert.equal(h.state.errors.length, 1);
});

test('a camera permission request resolved after cancellation is closed without starting OCR', async () => {
  const permission = deferred(), h = browser({ cameraPromise: permission.promise });
  const starting = h.scanner.start({ fps: '25' });
  await flush();
  await h.scanner.stop();
  assert.equal(await starting, false);
  permission.resolve(h.stream);
  await flush();
  assert.equal(h.state.stopped, 1);
  assert.equal(h.state.workers.length, 0);
  assert.equal(h.video.srcObject, null);
});

test('an OCR result from an earlier ROI is discarded after crop adjustment', async () => {
  const h = browser();
  await h.scanner.start({ fps: '25' });
  await flush();
  h.scanner.setROI({ x: .2, y: .2, width: .6, height: .3 });
  h.state.workers[0].answer('01:00:00:00');
  await flush();
  assert.equal(h.state.readings.length, 0);
  await h.scanner.stop();
});

test('stopping with an OCR job in progress emits no late reading or error', async () => {
  const h = browser();
  await h.scanner.start({ fps: '25' });
  await flush();
  await h.scanner.stop();
  h.state.workers[0].answer('01:00:00:00');
  await flush();
  assert.equal(h.state.readings.length, 0);
  assert.equal(h.state.errors.length, 0);
  assert.equal(h.state.workers[0].terminated, true);
});

test('an interrupted camera stops the OCR worker and reports the interruption', async () => {
  const h = browser();
  await h.scanner.start({ fps: '25' });
  await flush();
  h.endCamera();
  assert.equal(h.state.workers[0].terminated, true);
  assert.equal(h.video.srcObject, null);
  assert.equal(h.state.errors.length, 1);
  assert.match(h.state.errors[0].message, /fotocamera.*interrott/i);
});
