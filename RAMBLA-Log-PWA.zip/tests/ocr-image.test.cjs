'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { preprocessImage } = require('../src/timecode-camera.js');

function sample(width, height, pixel) {
  const data = new Uint8ClampedArray(width * height * 4);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const at = (y * width + x) * 4, v = pixel(x, y);
    data[at] = data[at + 1] = data[at + 2] = v; data[at + 3] = 255;
  }
  return { width, height, data };
}
const pixelAt = (result, x, y) => result.data[((y + result.padding) * result.width + x + result.padding) * 4];

test('bright digits on a dark display become black on white with a safe white border', () => {
  const raw = sample(100, 40, (x, y) => x >= 35 && x < 45 && y >= 8 && y < 32 ? 220 : 20);
  const original = raw.data.slice(), out = preprocessImage(raw);
  assert.ok(pixelAt(out, 40, 20) <= 10);
  assert.ok(pixelAt(out, 10, 20) >= 245);
  assert.ok(out.padding >= 8);
  assert.equal(out.data[0], 255);
  assert.deepEqual(raw.data, original, 'fallback must be able to reuse the original pixels');
  assert.equal(out.quality.polarity, 'light-on-dark');
});

test('low-contrast dark characters are stretched without turning the background dark', () => {
  const raw = sample(100, 40, (x, y) => x >= 35 && x < 45 && y >= 8 && y < 32 ? 180 : 204);
  const out = preprocessImage(raw);
  assert.ok(pixelAt(out, 40, 20) <= 10);
  assert.ok(pixelAt(out, 10, 20) >= 245);
  assert.equal(out.quality.polarity, 'dark-on-light');
});

test('small thin timecode strokes survive even when they occupy less than two percent of the crop', () => {
  for (const [background, foreground] of [[232, 38], [20, 232]]) {
    const raw = sample(528, 96, (x, y) => y >= 38 && y < 58 && x >= 190 && x < 286 && (x - 190) % 12 < 2 ? foreground : background);
    const out = preprocessImage(raw);
    assert.ok(pixelAt(out, 190, 45) <= 10);
    assert.ok(pixelAt(out, 100, 45) >= 245);
    assert.ok(out.quality.contrast > 100);
  }
});

test('software exposure changes anti-aliased stroke pixels rather than only a CSS preview', () => {
  const raw = sample(100, 40, (x, y) => y >= 8 && y < 32 && x >= 30 && x < 50 ? (x < 35 ? 150 : 240) : 20);
  const neutral = preprocessImage(raw), darker = preprocessImage(raw, { exposure: -1 });
  assert.ok(pixelAt(darker, 32, 20) > pixelAt(neutral, 32, 20) + 15, 'negative exposure suppresses the light halo around a bright digit');
  assert.ok(pixelAt(darker, 40, 20) <= 10, 'the bright digit core stays legible');
});

test('negative exposure preserves a faint difference instead of quantizing it into a blank image', () => {
  const raw = sample(100, 40, (x, y) => x >= 35 && x < 45 && y >= 8 && y < 32 ? 255 : 252);
  const out = preprocessImage(raw, { exposure: -2 });
  assert.ok(pixelAt(out, 40, 20) <= 10);
  assert.ok(pixelAt(out, 10, 20) >= 245);
});

test('adaptive threshold removes an uneven background while retaining dark strokes at both ends', () => {
  const raw = sample(180, 60, (x, y) => {
    const background = 110 + Math.round(x * .65);
    return y >= 15 && y < 45 && ((x >= 24 && x < 30) || (x >= 145 && x < 151)) ? background - 65 : background;
  });
  const out = preprocessImage(raw, { threshold: true });
  assert.equal(pixelAt(out, 26, 30), 0);
  assert.equal(pixelAt(out, 147, 30), 0);
  assert.equal(pixelAt(out, 8, 30), 255);
  assert.equal(pixelAt(out, 165, 30), 255);
});

test('blank clipped frames remain white and report the missing contrast', () => {
  const out = preprocessImage(sample(80, 30, () => 255));
  assert.equal(out.quality.contrast, 0);
  assert.equal(out.quality.clippedFraction, 1);
  assert.ok(out.data.every(v => v === 255));
});
