const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

// Browser audio and the model runtime are external boundaries. The actual
// capture, queue, resampling, timing, cancellation and cleanup code runs below.
function harness({ autoLoad = true, autoResult = true, denied = false, worklet = false } = {}) {
  const statuses = [], segments = [], errors = [], workers = [], contexts = [];
  const blobs = new Map();
  let WorkletImplementation, currentWorklet;
  let elapsed = 5, microphoneRequests = 0;
  const listeners = new Map();
  const track = {
    readyState: 'live', muted: false, stopped: 0,
    stop() { this.stopped++; this.readyState = 'ended'; },
    addEventListener(type, fn) { listeners.set(type, fn); },
    removeEventListener(type) { listeners.delete(type); },
    interrupt() { this.readyState = 'ended'; listeners.get('ended')?.(); }
  };
  const stream = { getTracks: () => [track], getAudioTracks: () => [track] };
  const node = () => ({ connect() {}, disconnect() {}, gain: { value: 1 } });
  class AudioContext {
    constructor() {
      this.sampleRate = 48000; this.state = 'suspended'; this.destination = node(); contexts.push(this);
      if (worklet) this.audioWorklet = { async addModule(url) {
        const source = await blobs.get(url).text();
        class AudioWorkletProcessor {
          constructor() { this.port = { postMessage(data) { currentWorklet.port.onmessage?.({ data }); } }; }
        }
        vm.runInNewContext(source, { AudioWorkletProcessor, Float32Array, registerProcessor(name, implementation) { WorkletImplementation = implementation; } });
      } };
    }
    async resume() { this.state = 'running'; }
    async close() { this.state = 'closed'; }
    createGain() { return node(); }
    createMediaStreamSource() { return node(); }
    createScriptProcessor() { this.processor = node(); return this.processor; }
    addEventListener(type, fn) { this['on' + type] = fn; }
    removeEventListener(type) { this['on' + type] = null; }
  }
  class AudioWorkletNode {
    constructor(context) {
      currentWorklet = this;
      this.implementation = new WorkletImplementation();
      this.port = { postMessage: data => this.implementation.port.onmessage({ data }) };
      context.processor = this;
    }
    connect() {}
    disconnect() {}
  }
  class Worker {
    constructor(url) { this.source = blobs.get(url); this.messages = []; this.terminated = false; workers.push(this); }
    postMessage(message) {
      this.messages.push(message);
      if (message.type === 'load' && autoLoad) queueMicrotask(() => this.emit({ type: 'ready' }));
      if (message.type === 'transcribe' && autoResult) queueMicrotask(() => this.reply(message));
    }
    emit(data) { if (!this.terminated) this.onmessage?.({ data }); }
    reply(message, output = { text: 'Parole reali dal modello', chunks: [{ text: 'Parole reali dal modello', timestamp: [-2, 90] }] }) {
      message.replied = true;
      this.emit({ type: 'result', id: message.id, output });
    }
    replyNext() { const m = this.messages.find(x => x.type === 'transcribe' && !x.replied); if (m) this.reply(m); }
    terminate() { this.terminated = true; }
  }
  const context = {
    console, setTimeout, clearTimeout, queueMicrotask, Float32Array, Float64Array,
    ArrayBuffer, Uint8Array, Math, Number, Error, DOMException, Blob,
    URL: { createObjectURL: blob => { const url = 'blob:test-' + blobs.size; blobs.set(url, blob); return url; }, revokeObjectURL() {} },
    Worker, AudioContext, isSecureContext: true,
    performance: { now: () => elapsed * 1000 },
    navigator: { mediaDevices: { async getUserMedia() {
      microphoneRequests++;
      if (denied) throw new DOMException('Permission denied', 'NotAllowedError');
      return stream;
    } } }
  };
  if (worklet) context.AudioWorkletNode = AudioWorkletNode;
  context.window = context;
  vm.createContext(context);
  const file = path.join(__dirname, '../src/local-asr.js');
  vm.runInContext(fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '', context, { filename: file });
  assert.equal(typeof context.RamblaLocalASR, 'function', 'The local engine must expose its public class');
  const asr = new context.RamblaLocalASR({
    onStatus: s => statuses.push(s), onSegment: s => segments.push(s), onError: e => errors.push(e)
  });
  return {
    asr, statuses, segments, errors, workers, contexts, track,
    getElapsed: () => elapsed,
    requests: () => microphoneRequests,
    feed(seconds) {
      const ctx = contexts.at(-1);
      let frames = Math.round(seconds * ctx.sampleRate);
      while (frames > 0 && (ctx.processor?.onaudioprocess || ctx.processor?.implementation?.active)) {
        const count = Math.min(worklet ? 128 : 4096, frames);
        elapsed += count / ctx.sampleRate;
        const samples = new Float32Array(count).fill(0.2);
        if (worklet) ctx.processor.implementation.process([[samples]]);
        else ctx.processor.onaudioprocess({
          inputBuffer: { numberOfChannels: 1, sampleRate: ctx.sampleRate, length: count, getChannelData: () => samples },
          outputBuffer: { numberOfChannels: 1, getChannelData: () => new Float32Array(count) }
        });
        frames -= count;
      }
    }
  };
}

const tick = () => new Promise(resolve => setImmediate(resolve));

test('constructing the engine never downloads a model or asks for the microphone', async () => {
  const h = harness();
  assert.equal(h.requests(), 0);
  assert.equal(h.workers.length, 0);
  await h.asr.destroy();
});

test('stop flushes real captured PCM at 16 kHz and bounds model timestamps to the captured interval', async () => {
  const h = harness();
  await h.asr.start({ language: 'it', getElapsed: h.getElapsed });
  h.feed(2);
  await h.asr.stop({ flush: true });
  const job = h.workers[0].messages.find(x => x.type === 'transcribe');
  assert.ok(job.audio instanceof Float32Array);
  assert.ok(Math.abs(job.audio.length - 32000) <= 1, 'Two seconds at 48 kHz must become two seconds at 16 kHz');
  assert.ok(Math.abs(job.audio[100] - 0.2) < 0.00001, 'The model receives the captured waveform');
  assert.equal(h.segments.length, 1);
  assert.ok(h.segments[0].start >= 4.99 && h.segments[0].start <= 5.01);
  assert.ok(h.segments[0].end <= 7.01 && h.segments[0].end >= 6.99);
  assert.equal(h.track.stopped, 1);
  assert.equal(h.contexts[0].state, 'closed');
  assert.equal(h.statuses.at(-1).state, 'stopped');
  await h.asr.destroy();
});

test('stopping waits for the final pending model result before reporting stopped', async () => {
  const h = harness({ autoResult: false });
  await h.asr.start({ getElapsed: h.getElapsed });
  h.feed(1);
  let finished = false;
  const stopping = h.asr.stop({ flush: true }).then(() => { finished = true; });
  await tick();
  assert.equal(finished, false);
  h.workers[0].replyNext();
  await stopping;
  assert.equal(h.segments.length, 1);
  assert.equal(finished, true);
  await h.asr.destroy();
});

test('a slow model stops capture with an explicit warning while retaining the bounded queue', async () => {
  const h = harness({ autoResult: false });
  await h.asr.start({ getElapsed: h.getElapsed });
  h.feed(40);
  await tick();
  assert.equal(h.track.stopped, 1, 'Capture must stop instead of collecting unbounded audio');
  assert.ok(h.errors.some(e => e.code === 'backpressure'), 'The user must hear why capture stopped');
  for (let i = 0; i < 5; i++) { h.workers[0].replyNext(); await tick(); }
  await h.asr.stop({ flush: true });
  const jobs = h.workers[0].messages.filter(x => x.type === 'transcribe');
  assert.ok(jobs.length <= 3, 'At most one active inference and two queued chunks');
  assert.equal(h.segments.length, jobs.length, 'Every accepted audio chunk must produce its result');
  assert.ok(h.segments.every((s, i, all) => i === 0 || s.start >= all[i - 1].end - 0.0001));
  await h.asr.destroy();
});

test('microphone denial is reported and releases the audio context', async () => {
  const h = harness({ denied: true });
  await assert.rejects(h.asr.start({ getElapsed: h.getElapsed }), /microfono|permission/i);
  assert.ok(h.errors.length > 0);
  assert.ok(h.contexts.every(c => c.state === 'closed'));
  await h.asr.destroy();
});

test('stop can cancel a model download without ever opening the microphone', async () => {
  const h = harness({ autoLoad: false });
  const starting = h.asr.start({ getElapsed: h.getElapsed });
  const rejected = assert.rejects(starting, { name: 'AbortError' });
  await tick();
  await h.asr.stop({ flush: true });
  await rejected;
  assert.equal(h.requests(), 0);
  assert.equal(h.workers[0].terminated, true);
  assert.ok(h.contexts.every(c => c.state === 'closed'));
  await h.asr.destroy();
});

test('a device interruption preserves captured audio and reports the interruption', async () => {
  const h = harness();
  await h.asr.start({ getElapsed: h.getElapsed });
  h.feed(1);
  h.track.interrupt();
  await tick();
  await h.asr.stop({ flush: true });
  assert.equal(h.segments.length, 1);
  assert.ok(h.errors.some(e => e.code === 'interrupted'));
  assert.equal(h.asr.captureStream, null);
  await h.asr.destroy();
});

test('the actual AudioWorklet flushes its final partial buffer before microphone cleanup', async () => {
  const h = harness({ worklet: true });
  await h.asr.start({ getElapsed: h.getElapsed });
  h.feed(1.07);
  await h.asr.stop({ flush: true });
  const job = h.workers[0].messages.find(x => x.type === 'transcribe');
  assert.ok(Math.abs(job.audio.length - 17120) <= 1, 'The sub-4096-frame tail must reach inference');
  assert.equal(h.segments.length, 1);
  assert.equal(h.track.stopped, 1);
  await h.asr.destroy();
});

test('destroy cancels an inference even when a previous flush is still waiting', async () => {
  const h = harness({ autoResult: false });
  await h.asr.start({ getElapsed: h.getElapsed });
  h.feed(1);
  const stopping = h.asr.stop({ flush: true });
  await tick();
  const destroying = h.asr.destroy();
  const finished = await Promise.race([destroying.then(() => true), new Promise(resolve => setTimeout(() => resolve(false), 100))]);
  if (!finished) h.workers[0].replyNext();
  await Promise.all([stopping, destroying]);
  assert.equal(finished, true, 'Releasing the model must not wait for a potentially stuck inference');
  assert.equal(h.workers[0].terminated, true);
});

test('the worker can load and transcribe when CacheStorage is unavailable', async () => {
  const h = harness();
  await h.asr.load();
  const source = await h.workers[0].source.text();
  const messages = [];
  const self = { postMessage: message => messages.push(message) };
  const env = { backends: { onnx: { wasm: {} } } };
  // The real runtime raised this exact error in the HTTP preview. Stub only
  // the remote dependency, then execute the actual worker message handlers.
  async function pipeline() {
    if (env.useBrowserCache && typeof self.caches === 'undefined') {
      throw new Error('Browser cache is not available in this environment.');
    }
    return async audio => ({ text: audio.length ? 'Fixture speech' : '', chunks: [] });
  }
  vm.runInNewContext(source.replace('await import(', 'await testImport('), {
    self, testImport: async () => ({ env, pipeline }), Float32Array
  });
  await self.onmessage({ data: { type: 'load' } });
  assert.equal(messages.at(-1).type, 'ready', 'An optional cache must not prevent model loading');
  await self.onmessage({ data: { type: 'transcribe', id: 12, audio: new Float32Array([0.1, 0.2]), language: 'en' } });
  assert.equal(messages.at(-1).type, 'result');
  assert.equal(messages.at(-1).id, 12);
  assert.equal(messages.at(-1).output.text, 'Fixture speech');
  await h.asr.destroy();
});
