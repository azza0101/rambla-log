'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const Core = require('../src/core.js');

// Execute production functions unchanged. Replace only the startup call with
// test access to its closure: the app owns all calculations and state changes.
// This seam deliberately fails if the application's startup shape changes.
const appSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'app.js'), 'utf8');
const startup = '  loadStore();bind();render();initPWA();';
const seam = `  globalThis.reviewApp = {
  bind, render, openNote, openSettings, saveSettings, importFile,
  startSession, startSpeech, endSession, openExport, exportKind, mark, addSegment,
  get current(){ return current(); }, get local(){ return local; },
  get active(){ return active; }, get pendingFlush(){ return pendingFlush; },
  setStore(value){ store=value; active=false; pendingFlush=false; selected=new Set();
    preSync=null; useWallClock=false; local=null; recovery=false; }
};`;

class Element {
  constructor() {
    this.value = ''; this.hidden = false; this.disabled = false;
    this.textContent = ''; this.innerHTML = ''; this.dataset = {}; this.style = {};
    this.listeners = new Map(); this.children = new Map();
    this.classList = { add() {}, remove() {}, toggle() {} };
    this.scrollTop = 0; this.clientHeight = 200; this.scrollHeight = 200;
  }
  querySelector(selector) {
    if (!this.children.has(selector)) this.children.set(selector, new Element());
    return this.children.get(selector);
  }
  setAttribute() {} removeAttribute() {} append() {} remove() {} click() {}
  showModal() { this.open = true; }
  close() { this.open = false; }
  addEventListener(name, fn) { this.listeners.set(name, fn); }
}

function session(patch = {}) {
  return {
    id: 'review-session', title: 'Review', createdAt: '2026-10-26T10:00:00.000Z',
    startedAt: null, endedAt: null, duration: 0, fps: '25', startTC: '01:00:00:00',
    language: 'it-IT', lookback: 10, speaker: 'A', speakers: ['A', 'B'],
    segments: [], markers: [], isDemo: false, ...patch,
  };
}

function harness(s = session(), mode = 'manual') {
  assert.ok(appSource.includes(startup), 'Update the VM startup seam: app boot code changed.');
  const elements = new Map(), storage = new Map(), downloads = [];
  let serial = 0, clock = 0;
  const el = id => {
    if (!elements.has(id)) elements.set(id, new Element());
    return elements.get(id);
  };
  const doc = {
    getElementById: el, querySelector: selector => el(selector), querySelectorAll: () => [],
    createElement: () => new Element(), body: new Element(), hidden: false,
    visibilityState: 'visible', addEventListener() {},
  };
  const appWindow = { RamblaCore: Core, crypto: { randomUUID: () => `review-${++serial}` }, addEventListener() {} };
  const context = {
    window: appWindow, document: doc, navigator: { onLine: true }, performance: { now: () => clock },
    Date, console, Map, Set, Math, Number, String, Array, JSON, Error, Promise, Blob,
    File: class { constructor(parts, name, options) { this.parts = parts; this.name = name; this.type = options.type; } },
    URL: { createObjectURL(file) { downloads.push(file); return 'blob:review'; }, revokeObjectURL() {} },
    localStorage: { setItem: (key, value) => storage.set(key, value), getItem: key => storage.get(key) || null },
    location: { protocol: 'https:' }, setTimeout: () => 1, clearTimeout() {}, setInterval() {}, confirm: () => true,
  };
  vm.runInNewContext(appSource.replace(startup, seam), context, { filename: 'app.js' });
  const app = context.reviewApp;
  app.setStore({ version: 1, sessions: [s], activeId: s.id, prefs: { mode } });
  app.bind(); app.render();
  return { app, el, appWindow, storage, downloads, advance(seconds) { clock += seconds * 1000; },
    click(id) { const button = el(id); if (!button.hidden && !button.disabled) return button.onclick?.({ target: button }); } };
}

function deferred() {
  let resolve;
  const promise = new Promise(done => { resolve = done; });
  return { promise, resolve };
}
const settle = () => new Promise(resolve => setImmediate(resolve));

function fakeLocal(h, destruction) {
  const instances = [];
  h.appWindow.RamblaLocalASR = class {
    constructor(options) { this.options = options; this.running = false; instances.push(this); }
    start() { this.running = true; this.options.onStatus({ state: 'listening', message: 'Ascolto' }); return Promise.resolve(); }
    stop() { this.running = false; return Promise.resolve(); }
    async destroy() { if (destruction) await destruction.promise; this.running = false; }
  };
  return instances;
}

test('editing a past phrase preserves its existing end even when the playhead is much later', () => {
  const s = session({ duration: 53, startedAt: Date.now() - 53000, endedAt: Date.now(),
    segments: [{ id: 'phrase', start: 3, end: 8, text: 'Testo', speaker: 'A' }] });
  const h = harness(s);
  h.app.openNote('segment', 'phrase');
  assert.equal(Number(h.el('noteStart').value), 3);
  assert.equal(Number(h.el('noteEnd').value), 8, 'Opening the editor must not extend a 3–8 second phrase to the current lookback window.');
});

test('an imported SRT can be assigned the destination frame rate and timecode', async () => {
  const h = harness();
  await h.app.importFile({ name: 'camera-29.97.srt', size: 80,
    text: async () => '1\n00:00:01,000 --> 00:00:03,000\nTesto\n' });
  h.app.openSettings();
  assert.equal(h.el('settingsFps').disabled, false, 'SRT does not carry a frame rate; the default must remain changeable.');
  assert.equal(h.el('settingsTC').disabled, false);
  h.el('settingsFps').value = '29.97df';
  h.el('settingsTC').value = '00:00:00;00';
  h.app.saveSettings({ preventDefault() {} });
  assert.equal(h.app.current.fps, '29.97df');
  assert.equal(h.app.current.startTC, '00:00:00;00');
});

test('a local microphone stopped by backpressure remains restartable while the session is active', async () => {
  const h = harness(session(), 'local');
  const instances = fakeLocal(h);
  h.app.startSession(); await settle();
  const events = instances[0].options;
  events.onError({ message: 'Microfono fermato: coda piena', code: 'backpressure' });
  events.onStatus({ state: 'processing', message: 'Elaboro la coda' });
  events.onStatus({ state: 'stopped', message: 'Microfono fermo. Coda elaborata.' });
  assert.equal(h.app.active, true);
  assert.equal(h.el('speechRetry').hidden, false, 'The final stopped status must not remove the only restart action.');
  assert.equal(h.el('speechRetry').disabled, false);
});

test('two rapid retry clicks never create an orphaned local microphone engine', async () => {
  const h = harness(session(), 'local');
  const destruction = deferred();
  const instances = fakeLocal(h, destruction);
  h.app.startSession(); await settle();
  instances[0].options.onError({ message: 'Riavvia', code: 'interrupted' });
  h.click('speechRetry'); h.click('speechRetry');
  destruction.resolve(); await settle();
  const running = instances.filter(instance => instance.running);
  assert.equal(running.length, 1, 'A retry must be single-flight even while the previous engine is being destroyed.');
  assert.equal(running[0], h.app.local, 'Every running microphone must remain owned by the app so Termina can stop it.');
});

test('a live marker receives matching transcription that arrives after the marker tap', () => {
  const s = session();
  const h = harness(s);
  h.app.startSession(); h.advance(10); h.app.mark('highlight');
  h.app.addSegment(s, { start: 2, end: 5, text: 'Momento importante', speaker: 'A' });
  assert.equal(s.markers.length, 1);
  assert.equal(s.markers[0].note, 'Momento importante');
  assert.deepEqual(Array.from(s.markers[0].segmentIds), [s.segments[0].id]);
});

test('a complete SRT cannot be downloaded before the final local transcription flush finishes', async () => {
  const s = session({ segments: [{ id: 'first', start: 1, end: 2, text: 'Prima frase', speaker: 'A' }] });
  const h = harness(s, 'local');
  fakeLocal(h);
  h.app.startSession(); await settle(); h.advance(5);
  const stop = deferred();
  h.app.local.stop = () => stop.promise;
  const ending = h.app.endSession();
  try {
    assert.equal(h.app.pendingFlush, true);
    h.app.openExport();
    if (h.el('exportDialog').open) h.app.exportKind('srt');
    assert.equal(h.downloads.length, 0, 'An export labeled complete must wait for pending final segments.');
  } finally {
    stop.resolve(); await ending;
  }
});
