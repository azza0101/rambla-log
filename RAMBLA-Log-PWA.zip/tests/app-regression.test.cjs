'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const Core = require('../src/core.js');

// Execute production functions unchanged. Replace only the startup call with
// test access to its closure: the app owns all calculations and state changes.
// This seam deliberately fails if the application's startup shape changes.
const appSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'app.js'), 'utf8');
const startup = '  loadStore();bind();render();initPWA();';
const seam = `  globalThis.reviewApp = {
  bind, render, openNote, saveNote, openSettings, saveSettings, importFile,
  startSession, startSpeech, endSession, openExport, exportKind, mark, addSegment,
  loadStore, newSession, selectSession, displayTC, elapsed,
  get current(){ return current(); }, get local(){ return local; },
  get active(){ return active; }, get pendingFlush(){ return pendingFlush; }, get recovery(){return recovery;},
  setStore(value){ store=value; active=false; pendingFlush=false; selected=new Set();
    preSync=null; local=null; recovery=false; }
};`;

class Element {
  constructor() {
    this.value = ''; this.hidden = false; this.disabled = false;
    this.textContent = ''; this.innerHTML = ''; this.dataset = {}; this.style = {};
    this.listeners = new Map(); this.children = new Map();
    this.attributes = new Map();
    this.classList = { add() {}, remove() {}, toggle() {} };
    this.scrollTop = 0; this.clientHeight = 200; this.scrollHeight = 200;
  }
  querySelector(selector) {
    if (!this.children.has(selector)) this.children.set(selector, new Element());
    return this.children.get(selector);
  }
  setAttribute(name,value) { this.attributes.set(name, value); } removeAttribute(name) {this.attributes.delete(name);} append() {} remove() {} click() {}
  showModal() { this.open = true; }
  close() { this.open = false; }
  addEventListener(name, fn) { this.listeners.set(name, fn); }
}

function session(patch = {}) {
  return {
    id: 'review-session', title: 'Review', createdAt: '2026-10-26T10:00:00.000Z',
    startedAt: null, endedAt: null, duration: 0, fps: '25', startTC: '01:00:00:00',
    language: 'it-IT', lookback: 10, speaker: 'A', speakers: ['A', 'B'],
    segments: [], markers: [], isDemo: false, ...patch,
  };
}

function harness(s = session(), mode = 'manual') {
  assert.ok(appSource.includes(startup), 'Update the VM startup seam: app boot code changed.');
  const elements = new Map(), storage = new Map(), downloads = [], writes = [], intervals = [];
  const docEvents = new Map(), windowEvents = new Map();
  let serial = 0, clock = 0, epoch = Date.parse('2026-10-26T10:00:00.875Z');
  class TestDate extends Date {
    constructor(...args) { super(...(args.length ? args : [epoch])); }
    static now() { return epoch; }
  }
  const el = id => {
    if (!elements.has(id)) elements.set(id, new Element());
    return elements.get(id);
  };
  const doc = {
    getElementById: el, querySelector: selector => el(selector), querySelectorAll: () => [],
    createElement: () => new Element(), body: new Element(), hidden: false,
    visibilityState: 'visible', addEventListener(name, fn) { docEvents.set(name, fn); },
  };
  const appWindow = { RamblaCore: Core, crypto: { randomUUID: () => `review-${++serial}` }, addEventListener(name, fn) {windowEvents.set(name, fn);} };
  const nav={onLine:true};
  const context = {
    window: appWindow, document: doc, navigator: nav, performance: { now: () => clock },
    Date: TestDate, console, Map, Set, Math, Number, String, Array, JSON, Error, Promise, Blob,
    File: class { constructor(parts, name, options) { this.parts = parts; this.name = name; this.type = options.type; } },
    URL: { createObjectURL(file) { downloads.push(file); return 'blob:review'; }, revokeObjectURL() {} },
    localStorage: { setItem: (key, value) => {storage.set(key, value);writes.push({key,value});}, getItem: key => storage.get(key) || null },
    location: { protocol: 'https:' }, setTimeout: () => 1, clearTimeout() {}, setInterval(fn) {intervals.push(fn);}, confirm: () => true,
  };
  vm.runInNewContext(appSource.replace(startup, seam), context, { filename: 'app.js' });
  const app = context.reviewApp;
  app.setStore({ version: 1, sessions: [s], activeId: s.id, prefs: { mode } });
  app.bind(); app.render();
  return { app, el, appWindow, navigator:nav, storage, downloads, writes,
    advance(seconds, { suspendPerformance = false } = {}) { if(!suspendPerformance)clock += seconds * 1000;epoch+=seconds*1000; },
    tick() {intervals.forEach(fn=>fn());},
    hide() {doc.hidden=true;doc.visibilityState='hidden';return docEvents.get('visibilitychange')?.();},
    show() {doc.hidden=false;doc.visibilityState='visible';return docEvents.get('visibilitychange')?.();},
    pagehide() {return windowEvents.get('pagehide')?.();},
    click(id) { const button = el(id); if (!button.hidden && !button.disabled) return button.onclick?.({ target: button }); } };
}

function deferred() {
  let resolve;
  const promise = new Promise(done => { resolve = done; });
  return { promise, resolve };
}
const settle = () => new Promise(resolve => setImmediate(resolve));

function fakeLocal(h, destruction) {
  const instances = [];
  h.appWindow.RamblaLocalASR = class {
    constructor(options) { this.options = options; this.running = false; instances.push(this); }
    start() { this.running = true; this.options.onStatus({ state: 'listening', message: 'Ascolto' }); return Promise.resolve(); }
    stop() { this.running = false; return Promise.resolve(); }
    async destroy() { if (destruction) await destruction.promise; this.running = false; }
  };
  return instances;
}

test('editing a past phrase preserves its existing end even when the playhead is much later', () => {
  const s = session({ duration: 53, startedAt: Date.now() - 53000, endedAt: Date.now(),
    segments: [{ id: 'phrase', start: 3, end: 8, text: 'Testo', speaker: 'A' }] });
  const h = harness(s);
  h.app.openNote('segment', 'phrase');
  assert.equal(Number(h.el('noteStart').value), 3);
  assert.equal(Number(h.el('noteEnd').value), 8, 'Opening the editor must not extend a 3–8 second phrase to the current lookback window.');
});

test('new sessions select and persist the phone clock while legacy drafts retain timecode', () => {
  const h = harness();
  h.app.newSession();
  assert.equal(h.app.current.clockSource, 'phone');
  h.click('clockTimecodeButton');
  assert.equal(h.app.current.clockSource, 'timecode');
  h.click('clockPhoneButton');
  const saved = JSON.parse(h.storage.get('rambla-log-v1'));
  assert.equal(saved.sessions.find(s=>s.id===h.app.current.id).clockSource, 'phone');
  assert.equal(h.el('clockPhoneButton').attributes.get('aria-pressed'), 'true');
  h.app.startSession();
  h.click('clockTimecodeButton');
  assert.equal(h.app.current.clockSource, 'phone', 'The reference is locked once capture starts.');
});

test('phone display honors subsecond start and has no fractional-rate NDF drift', () => {
  const h = harness(session({clockSource:'phone',fps:'29.97'}));
  h.app.startSession();
  assert.equal(h.app.current.phoneAnchorMs, Date.parse('2026-10-26T10:00:00.875Z'));
  h.advance(.2);h.app.displayTC();
  assert.equal(h.el('timecode').innerHTML, '10:00:01');
  h.advance(3599.8);h.app.displayTC();
  assert.equal(h.el('timecode').innerHTML, '11:00:00');
  h.app.mark('keep');
  assert.match(h.el('markerList').innerHTML,/10:59:50 → 11:00:00/);
  assert.match(Core.makeEDL(h.app.current),/FCM: NON-DROP FRAME/);
});

test('pausing blocks quick markers and resuming preserves the session, transcript and timeline gap', async () => {
  const h=harness(session({clockSource:'phone'}));
  h.app.startSession();h.advance(10);h.app.mark('keep');
  const id=h.app.current.id;
  await h.click('pauseButton');
  assert.equal(h.app.active,false);
  assert.equal(h.app.current.captureState,'paused');
  assert.equal(h.app.current.pauseReason,'manual');
  assert.equal(h.app.current.endedAt,null);
  h.app.mark('turn');
  assert.equal(h.app.current.markers.length,1);
  h.advance(100,{suspendPerformance:true});
  h.click('resumeButton');h.advance(2);h.app.mark('turn');
  assert.equal(h.app.current.id,id);
  assert.equal(h.app.current.captureState,'active');
  assert.equal(h.app.current.markers.length,2);
  assert.equal(h.app.current.markers[1].start,110,'Quick lookback starts at resume, not inside the pause.');
  assert.equal(h.app.current.markers[1].end,112);
  assert.equal(h.app.current.markers[1].name,'SCARTA');
});

test('hide checkpoints the paused state synchronously before local final transcription drains', async () => {
  const h=harness(session({clockSource:'phone'}),'local');
  fakeLocal(h);h.app.startSession();await settle();h.advance(7);
  const final=deferred();h.app.local.stop=()=>final.promise;
  const pausing=h.hide();
  const saved=JSON.parse(h.storage.get('rambla-log-v1')).sessions[0];
  assert.equal(saved.captureState,'paused');
  assert.equal(saved.pauseReason,'background');
  assert.equal(saved.duration,7);
  assert.equal(h.app.active,false);
  assert.equal(h.app.pendingFlush,true);
  h.show();h.click('resumeButton');
  assert.equal(h.app.active,false,'No microphone may restart while its final queue is pending.');
  final.resolve();await pausing;await settle();
  assert.equal(h.app.pendingFlush,false);
  assert.equal(h.el('resumeButton').hidden,false);
});

test('manual mode also pauses on pagehide and restores the same epoch-anchored session', async () => {
  const h=harness(session({clockSource:'phone'}));
  h.app.startSession();h.advance(8);await h.pagehide();
  const saved=h.storage.get('rambla-log-v1');
  assert.equal(JSON.parse(saved).sessions[0].pauseReason,'background');
  h.advance(300,{suspendPerformance:true});
  h.app.loadStore();h.app.render();
  assert.equal(h.app.current.id,'review-session');
  assert.equal(h.app.recovery,true);
  assert.equal(h.app.current.clockSource,'phone');
  h.click('resumeButton');h.advance(1);h.app.mark('keep');
  assert.equal(h.app.current.markers[0].start,308);
  assert.equal(h.app.current.markers[0].end,309);
});

test('the display timer does not rewrite the whole archive while no data changes', () => {
  const h=harness();h.app.startSession();
  const before=h.writes.length;
  for(let i=0;i<10;i++){h.advance(5);h.tick();}
  assert.equal(h.writes.length,before);
  h.app.mark('keep');
  assert.ok(h.writes.length>before,'Finalized log data is still persisted immediately.');
});

test('a delayed native final is bounded by pause time and ignored after its drained run', async () => {
  const h=harness(session(),'native');
  const runs=[];
  h.appWindow.SpeechRecognition=class {
    constructor(){runs.push(this);}
    start(){} stop(){} abort(){}
  };
  h.app.startSession();h.advance(3);runs[0].onspeechstart();h.advance(2);
  const pausing=h.click('pauseButton');
  h.advance(30,{suspendPerformance:true});
  const event=text=>({resultIndex:0,results:[Object.assign([{transcript:text}],{isFinal:true})]});
  runs[0].onresult(event('Ultime parole'));
  assert.equal(h.app.current.segments[0].start,3);
  assert.equal(h.app.current.segments[0].end,5,'Final arrival time must never extend captured speech into the pause.');
  runs[0].onend();await pausing;
  h.click('resumeButton');
  runs[0].onresult({...event('Risultato scaduto'),resultIndex:1,results:[[],Object.assign([{transcript:'Risultato scaduto'}],{isFinal:true})]});
  assert.equal(h.app.current.segments.length,1);
});

test('local finals retain the pre-pause capture range while stale callbacks cannot enter the resumed run', async () => {
  const h=harness(session(),'local');
  const engines=fakeLocal(h);h.app.startSession();await settle();h.advance(6);
  const final=deferred();engines[0].stop=()=>final.promise;
  const pausing=h.click('pauseButton');h.advance(90,{suspendPerformance:true});
  engines[0].options.onSegment({start:2,end:20,text:'Finale acquisito'});
  assert.equal(h.app.current.segments[0].end,6);
  final.resolve();await pausing;
  h.click('resumeButton');await settle();
  engines[0].options.onSegment({start:95,end:96,text:'Callback scaduto'});
  assert.equal(h.app.current.segments.length,1);
  h.advance(1);
  engines[1].options.onSegment({start:96,end:97,text:'Dopo la pausa'});
  assert.equal(h.app.current.segments[1].start,96);
});

test('editing a manual note in a paused session cannot move the live phone reference', async () => {
  const h=harness(session({clockSource:'phone'}));
  h.app.startSession();h.advance(10);await h.click('pauseButton');
  h.app.openNote();h.el('noteText').value='Nota con intervallo modificato';
  h.el('noteStart').value='200';h.el('noteEnd').value='201';
  h.app.saveNote({preventDefault(){}});
  h.advance(5);h.click('resumeButton');h.advance(1);h.app.displayTC();h.app.mark('keep');
  assert.equal(h.el('timecode').innerHTML,'10:00:16');
  assert.equal(h.app.current.markers.at(-1).start,15);
  assert.equal(h.app.current.markers.at(-1).end,16);
  await h.click('pauseButton');h.advance(30);h.app.loadStore();h.app.render();
  h.click('resumeButton');h.advance(1);h.app.displayTC();
  assert.equal(h.el('timecode').innerHTML,'10:00:47','Restoring manually edited ranges must preserve the epoch clock too.');
});

test('a local start canceled during model loading cannot restart capture after pause', async () => {
  const h=harness(session(),'local'),loading=deferred(),engines=[];
  h.appWindow.RamblaLocalASR=class {
    constructor(options){this.options=options;this.running=false;engines.push(this);}
    async start(){await loading.promise;this.running=true;this.options.onStatus({state:'listening',message:'Ascolto'});}
    stop(){this.running=false;return Promise.resolve();}
    destroy(){this.running=false;return Promise.resolve();}
  };
  h.app.startSession();h.advance(4);await h.click('pauseButton');
  loading.resolve();await settle();
  assert.equal(h.app.active,false);
  assert.equal(h.el('speechRetry').hidden,true);
  assert.equal(engines.filter(e=>e.running).length,0,'The app stops even a delayed external start that resolves after cancellation.');
  h.click('resumeButton');await settle();
  assert.equal(engines.filter(e=>e.running).length,1);
  assert.equal(h.app.current.captureState,'active');
});

test('pausing during a pending local retry prevents the canceled retry from owning a new microphone', async () => {
  const h=harness(session(),'local'),destruction=deferred();
  const engines=fakeLocal(h,destruction);h.app.startSession();await settle();
  engines[0].options.onError({message:'Riattiva'});
  h.click('speechRetry');await settle();
  h.advance(4);await h.click('pauseButton');
  h.advance(30);h.click('resumeButton');destruction.resolve();await settle();
  assert.equal(engines.filter(e=>e.running).length,1);
  assert.equal(engines.filter(e=>e.running)[0],h.app.local);
  assert.equal(h.app.current.captureState,'active');
});

test('late wake-lock permission from a paused run cannot orphan the resumed session lock', async () => {
  const h=harness(),first=deferred(),second=deferred(),released=[];
  const requests=[first,second];
  h.navigator.wakeLock={request:()=>requests.shift().promise};
  const lock=name=>({release(){released.push(name);return Promise.resolve();},addEventListener(){}});
  h.app.startSession();await h.click('pauseButton');h.click('resumeButton');
  second.resolve(lock('current'));await settle();
  first.resolve(lock('stale'));await settle();
  await h.click('pauseButton');
  assert.deepEqual(released.sort(),['current','stale'],'Both native screen locks are released even when the old permission arrives last.');
});

test('an imported SRT can be assigned the destination frame rate and timecode', async () => {
  const h = harness();
  await h.app.importFile({ name: 'camera-29.97.srt', size: 80,
    text: async () => '1\n00:00:01,000 --> 00:00:03,000\nTesto\n' });
  h.app.openSettings();
  assert.equal(h.el('settingsFps').disabled, false, 'SRT does not carry a frame rate; the default must remain changeable.');
  assert.equal(h.el('settingsTC').disabled, false);
  h.el('settingsFps').value = '29.97df';
  h.el('settingsTC').value = '00:00:00;00';
  h.app.saveSettings({ preventDefault() {} });
  assert.equal(h.app.current.fps, '29.97df');
  assert.equal(h.app.current.startTC, '00:00:00;00');
});

test('a local microphone stopped by backpressure remains restartable while the session is active', async () => {
  const h = harness(session(), 'local');
  const instances = fakeLocal(h);
  h.app.startSession(); await settle();
  const events = instances[0].options;
  events.onError({ message: 'Microfono fermato: coda piena', code: 'backpressure' });
  events.onStatus({ state: 'processing', message: 'Elaboro la coda' });
  events.onStatus({ state: 'stopped', message: 'Microfono fermo. Coda elaborata.' });
  assert.equal(h.app.active, true);
  assert.equal(h.el('speechRetry').hidden, false, 'The final stopped status must not remove the only restart action.');
  assert.equal(h.el('speechRetry').disabled, false);
});

test('two rapid retry clicks never create an orphaned local microphone engine', async () => {
  const h = harness(session(), 'local');
  const destruction = deferred();
  const instances = fakeLocal(h, destruction);
  h.app.startSession(); await settle();
  instances[0].options.onError({ message: 'Riavvia', code: 'interrupted' });
  h.click('speechRetry'); h.click('speechRetry');
  destruction.resolve(); await settle();
  const running = instances.filter(instance => instance.running);
  assert.equal(running.length, 1, 'A retry must be single-flight even while the previous engine is being destroyed.');
  assert.equal(running[0], h.app.local, 'Every running microphone must remain owned by the app so Termina can stop it.');
});

test('a live marker receives matching transcription that arrives after the marker tap', () => {
  const s = session();
  const h = harness(s);
  h.app.startSession(); h.advance(10); h.app.mark('highlight');
  h.app.addSegment(s, { start: 2, end: 5, text: 'Momento importante', speaker: 'A' });
  assert.equal(s.markers.length, 1);
  assert.equal(s.markers[0].note, 'Momento importante');
  assert.deepEqual(Array.from(s.markers[0].segmentIds), [s.segments[0].id]);
});

test('a complete SRT cannot be downloaded before the final local transcription flush finishes', async () => {
  const s = session({ segments: [{ id: 'first', start: 1, end: 2, text: 'Prima frase', speaker: 'A' }] });
  const h = harness(s, 'local');
  fakeLocal(h);
  h.app.startSession(); await settle(); h.advance(5);
  const stop = deferred();
  h.app.local.stop = () => stop.promise;
  const ending = h.app.endSession();
  try {
    assert.equal(h.app.pendingFlush, true);
    h.app.openExport();
    if (h.el('exportDialog').open) h.app.exportKind('srt');
    assert.equal(h.downloads.length, 0, 'An export labeled complete must wait for pending final segments.');
  } finally {
    stop.resolve(); await ending;
  }
});
