'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const Core = require('../src/core.js');

// Execute production functions unchanged. Replace only the startup call with
// test access to its closure: the app owns all calculations and state changes.
// This seam deliberately fails if the application's startup shape changes.
const appSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'app.js'), 'utf8');
const startup = '  loadStore();bind();render();initPWA();';
const seam = `  globalThis.reviewApp = {
  bind, render, openNote, saveNote, openSettings, saveSettings, importFile,
  startSession, startSpeech, endSession, openExport, exportKind, mark, addSegment,
  loadStore, newSession, selectSession, displayTC, elapsed, openScanner, applyScan,
  get current(){ return current(); }, get local(){ return local; }, get sessions(){return store.sessions;},
  get active(){ return active; }, get pendingFlush(){ return pendingFlush; }, get recovery(){return recovery;},
  setStore(value){ store=value; active=false; pendingFlush=false; selected=new Set();
    preSync=null; local=null; recovery=false; }
};`;

class Element {
  constructor() {
    this.value = ''; this.hidden = false; this.disabled = false;
    this.textContent = ''; this.innerHTML = ''; this.dataset = {}; this.style = {};
    this.listeners = new Map(); this.children = new Map();
    this.attributes = new Map();
    this.classList = { add() {}, remove() {}, toggle() {}, contains(){return false;} };
    this.scrollTop = 0; this.clientHeight = 200; this.scrollHeight = 200;
  }
  querySelector(selector) {
    if (!this.children.has(selector)) this.children.set(selector, new Element());
    return this.children.get(selector);
  }
  setAttribute(name,value) { this.attributes.set(name, value); } removeAttribute(name) {this.attributes.delete(name);} append() {} remove() {} click() {}
  showModal() { this.open = true; }
  close() { const wasOpen=this.open;this.open = false;if(wasOpen)this.listeners.get('close')?.(); }
  getBoundingClientRect() {return {width:340,height:191,left:0,top:0};}
  addEventListener(name, fn) { this.listeners.set(name, fn); }
}

function session(patch = {}) {
  return {
    id: 'review-session', title: 'Review', createdAt: '2026-10-26T10:00:00.000Z',
    startedAt: null, endedAt: null, duration: 0, fps: '25', startTC: '01:00:00:00',
    language: 'it-IT', lookback: 10, speaker: 'A', speakers: ['A', 'B'],
    segments: [], markers: [], isDemo: false, ...patch,
  };
}

function harness(s = session(), mode = 'manual', {missingIds=[]} = {}) {
  assert.ok(appSource.includes(startup), 'Update the VM startup seam: app boot code changed.');
  const elements = new Map(), storage = new Map(), downloads = [], writes = [], intervals = [];
  const docEvents = new Map(), windowEvents = new Map(), timers = new Map();
  let timerSerial=0, confirmAnswer=true,storageError=null;
  const fetches=[],navigations=[];
  let fetchImpl=async()=>{throw Error('Unexpected network request');};
  let serial = 0, clock = 0, epoch = Date.parse('2026-10-26T10:00:00.875Z');
  class TestDate extends Date {
    constructor(...args) { super(...(args.length ? args : [epoch])); }
    static now() { return epoch; }
  }
  const el = id => {
    if (!elements.has(id)) elements.set(id, new Element());
    return elements.get(id);
  };
  const doc = {
    getElementById: id => missingIds.includes(id)?null:el(id), querySelector: selector => el(selector), querySelectorAll: () => [],
    createElement: () => new Element(), body: new Element(), hidden: false,
    visibilityState: 'visible', addEventListener(name, fn) { docEvents.set(name, fn); },
  };
  const appWindow = { RamblaCore: Core, RAMBLA_BUILD:{version:'1.3.0',build:'111111111111'}, crypto: { randomUUID: () => `review-${++serial}` }, addEventListener(name, fn) {windowEvents.set(name, fn);} };
  const nav={onLine:true};
  class TestURL extends URL {
    static createObjectURL(file){downloads.push(file);return 'blob:review';}
    static revokeObjectURL(){}
  }
  const appLocation={protocol:'https:',href:'https://azza0101.github.io/rambla-log/?existing=yes#markers',replace(url){navigations.push({url,archive:storage.get('rambla-log-v1')});}};
  const context = {
    window: appWindow, document: doc, navigator: nav, performance: { now: () => clock },
    Date: TestDate, console, Map, Set, Math, Number, String, Array, JSON, Error, Promise, Blob,
    File: class { constructor(parts, name, options) { this.parts = parts; this.name = name; this.type = options.type; } },
    URL: TestURL,fetch(...args){fetches.push(args);return fetchImpl(...args);},
    localStorage: { setItem: (key, value) => {if(storageError)throw storageError;storage.set(key, value);writes.push({key,value});}, getItem: key => storage.get(key) || null },
    location: appLocation, setTimeout(fn,ms){const id=++timerSerial;timers.set(id,{fn,at:clock+ms});return id;}, clearTimeout(id){timers.delete(id);}, setInterval(fn) {intervals.push(fn);}, confirm: () => confirmAnswer,
  };
  vm.runInNewContext(appSource.replace(startup, seam), context, { filename: 'app.js' });
  const app = context.reviewApp;
  app.setStore({ version: 1, sessions: [s], activeId: s.id, prefs: { mode } });
  app.bind(); app.render();
  return { app, el, appWindow, navigator:nav, storage, downloads, writes,fetches,navigations,location:appLocation,
    setFetch(fn){fetchImpl=fn;},failStorage(error=Error('QuotaExceededError')){storageError=error;},
    dispatch(name,event={}){return docEvents.get(name)?.(event);},
    confirm(value){confirmAnswer=value;},
    flushTimers(){for(const [id,timer] of [...timers])if(timer.at<=clock){timers.delete(id);timer.fn();}},
    advance(seconds, { suspendPerformance = false } = {}) { if(!suspendPerformance)clock += seconds * 1000;epoch+=seconds*1000; },
    tick() {intervals.forEach(fn=>fn());},
    hide() {doc.hidden=true;doc.visibilityState='hidden';return docEvents.get('visibilitychange')?.();},
    show() {doc.hidden=false;doc.visibilityState='visible';return docEvents.get('visibilitychange')?.();},
    pagehide() {return windowEvents.get('pagehide')?.();},
    click(id) { const button = el(id); if (!button.hidden && !button.disabled) return button.onclick?.({ target: button }); } };
}

function deferred() {
  let resolve;
  const promise = new Promise(done => { resolve = done; });
  return { promise, resolve };
}
const settle = () => new Promise(resolve => setImmediate(resolve));

function fakeLocal(h, destruction) {
  const instances = [];
  h.appWindow.RamblaLocalASR = class {
    constructor(options) { this.options = options; this.running = false; instances.push(this); }
    start() { this.running = true; this.options.onStatus({ state: 'listening', message: 'Ascolto' }); return Promise.resolve(); }
    stop() { this.running = false; return Promise.resolve(); }
    async destroy() { if (destruction) await destruction.promise; this.running = false; }
  };
  return instances;
}

test('editing a past phrase preserves its existing end even when the playhead is much later', () => {
  const s = session({ duration: 53, startedAt: Date.now() - 53000, endedAt: Date.now(),
    segments: [{ id: 'phrase', start: 3, end: 8, text: 'Testo', speaker: 'A' }] });
  const h = harness(s);
  h.app.openNote('segment', 'phrase');
  assert.equal(Number(h.el('noteStart').value), 3);
  assert.equal(Number(h.el('noteEnd').value), 8, 'Opening the editor must not extend a 3–8 second phrase to the current lookback window.');
});

test('new sessions select and persist the phone clock while legacy drafts retain timecode', () => {
  const h = harness();
  h.app.newSession();
  assert.equal(h.app.current.clockSource, 'phone');
  h.click('clockTimecodeButton');
  assert.equal(h.app.current.clockSource, 'timecode');
  h.click('clockPhoneButton');
  const saved = JSON.parse(h.storage.get('rambla-log-v1'));
  assert.equal(saved.sessions.find(s=>s.id===h.app.current.id).clockSource, 'phone');
  assert.equal(h.el('clockPhoneButton').attributes.get('aria-pressed'), 'true');
  h.app.startSession();
  h.click('clockTimecodeButton');
  assert.equal(h.app.current.clockSource, 'phone', 'The reference is locked once capture starts.');
});

test('phone display honors subsecond start and has no fractional-rate NDF drift', () => {
  const h = harness(session({clockSource:'phone',fps:'29.97'}));
  h.app.startSession();
  assert.equal(h.app.current.phoneAnchorMs, Date.parse('2026-10-26T10:00:00.875Z'));
  h.advance(.2);h.app.displayTC();
  assert.equal(h.el('timecode').innerHTML, '10:00:01');
  h.advance(3599.8);h.app.displayTC();
  assert.equal(h.el('timecode').innerHTML, '11:00:00');
  h.app.mark('keep');
  assert.match(h.el('markerList').innerHTML,/10:59:50 → 11:00:00/);
  assert.match(Core.makeEDL(h.app.current),/FCM: NON-DROP FRAME/);
});

test('pausing blocks quick markers and resuming preserves the session, transcript and timeline gap', async () => {
  const h=harness(session({clockSource:'phone'}));
  h.app.startSession();h.advance(10);h.app.mark('keep');
  const id=h.app.current.id;
  await h.click('pauseButton');
  assert.equal(h.app.active,false);
  assert.equal(h.app.current.captureState,'paused');
  assert.equal(h.app.current.pauseReason,'manual');
  assert.equal(h.app.current.endedAt,null);
  h.app.mark('turn');
  assert.equal(h.app.current.markers.length,1);
  h.advance(100,{suspendPerformance:true});
  h.click('resumeButton');h.advance(2);h.app.mark('turn');
  assert.equal(h.app.current.id,id);
  assert.equal(h.app.current.captureState,'active');
  assert.equal(h.app.current.markers.length,2);
  assert.equal(h.app.current.markers[1].start,110,'Quick lookback starts at resume, not inside the pause.');
  assert.equal(h.app.current.markers[1].end,112);
  assert.equal(h.app.current.markers[1].name,'SCARTA');
});

test('hide checkpoints the paused state synchronously before local final transcription drains', async () => {
  const h=harness(session({clockSource:'phone'}),'local');
  fakeLocal(h);h.app.startSession();await settle();h.advance(7);
  const final=deferred();h.app.local.stop=()=>final.promise;
  const pausing=h.hide();
  const saved=JSON.parse(h.storage.get('rambla-log-v1')).sessions[0];
  assert.equal(saved.captureState,'paused');
  assert.equal(saved.pauseReason,'background');
  assert.equal(saved.duration,7);
  assert.equal(h.app.active,false);
  assert.equal(h.app.pendingFlush,true);
  h.show();h.click('resumeButton');
  assert.equal(h.app.active,false,'No microphone may restart while its final queue is pending.');
  final.resolve();await pausing;await settle();
  assert.equal(h.app.pendingFlush,false);
  assert.equal(h.el('resumeButton').hidden,false);
});

test('manual mode also pauses on pagehide and restores the same epoch-anchored session', async () => {
  const h=harness(session({clockSource:'phone'}));
  h.app.startSession();h.advance(8);await h.pagehide();
  const saved=h.storage.get('rambla-log-v1');
  assert.equal(JSON.parse(saved).sessions[0].pauseReason,'background');
  h.advance(300,{suspendPerformance:true});
  h.app.loadStore();h.app.render();
  assert.equal(h.app.current.id,'review-session');
  assert.equal(h.app.recovery,true);
  assert.equal(h.app.current.clockSource,'phone');
  h.click('resumeButton');h.advance(1);h.app.mark('keep');
  assert.equal(h.app.current.markers[0].start,308);
  assert.equal(h.app.current.markers[0].end,309);
});

test('the display timer does not rewrite the whole archive while no data changes', () => {
  const h=harness();h.app.startSession();
  const before=h.writes.length;
  for(let i=0;i<10;i++){h.advance(5);h.tick();}
  assert.equal(h.writes.length,before);
  h.app.mark('keep');
  assert.ok(h.writes.length>before,'Finalized log data is still persisted immediately.');
});

test('a delayed native final is bounded by pause time and ignored after its drained run', async () => {
  const h=harness(session(),'native');
  const runs=[];
  h.appWindow.SpeechRecognition=class {
    constructor(){runs.push(this);}
    start(){} stop(){} abort(){}
  };
  h.app.startSession();h.advance(3);runs[0].onspeechstart();h.advance(2);
  const pausing=h.click('pauseButton');
  h.advance(30,{suspendPerformance:true});
  const event=text=>({resultIndex:0,results:[Object.assign([{transcript:text}],{isFinal:true})]});
  runs[0].onresult(event('Ultime parole'));
  assert.equal(h.app.current.segments[0].start,3);
  assert.equal(h.app.current.segments[0].end,5,'Final arrival time must never extend captured speech into the pause.');
  runs[0].onend();await pausing;
  h.click('resumeButton');
  runs[0].onresult({...event('Risultato scaduto'),resultIndex:1,results:[[],Object.assign([{transcript:'Risultato scaduto'}],{isFinal:true})]});
  assert.equal(h.app.current.segments.length,1);
});

test('local finals retain the pre-pause capture range while stale callbacks cannot enter the resumed run', async () => {
  const h=harness(session(),'local');
  const engines=fakeLocal(h);h.app.startSession();await settle();h.advance(6);
  const final=deferred();engines[0].stop=()=>final.promise;
  const pausing=h.click('pauseButton');h.advance(90,{suspendPerformance:true});
  engines[0].options.onSegment({start:2,end:20,text:'Finale acquisito'});
  assert.equal(h.app.current.segments[0].end,6);
  final.resolve();await pausing;
  h.click('resumeButton');await settle();
  engines[0].options.onSegment({start:95,end:96,text:'Callback scaduto'});
  assert.equal(h.app.current.segments.length,1);
  h.advance(1);
  engines[1].options.onSegment({start:96,end:97,text:'Dopo la pausa'});
  assert.equal(h.app.current.segments[1].start,96);
});

test('editing a manual note in a paused session cannot move the live phone reference', async () => {
  const h=harness(session({clockSource:'phone'}));
  h.app.startSession();h.advance(10);await h.click('pauseButton');
  h.app.openNote();h.el('noteText').value='Nota con intervallo modificato';
  h.el('noteStart').value='200';h.el('noteEnd').value='201';
  h.app.saveNote({preventDefault(){}});
  h.advance(5);h.click('resumeButton');h.advance(1);h.app.displayTC();h.app.mark('keep');
  assert.equal(h.el('timecode').innerHTML,'10:00:16');
  assert.equal(h.app.current.markers.at(-1).start,15);
  assert.equal(h.app.current.markers.at(-1).end,16);
  await h.click('pauseButton');h.advance(30);h.app.loadStore();h.app.render();
  h.click('resumeButton');h.advance(1);h.app.displayTC();
  assert.equal(h.el('timecode').innerHTML,'10:00:47','Restoring manually edited ranges must preserve the epoch clock too.');
});

test('a local start canceled during model loading cannot restart capture after pause', async () => {
  const h=harness(session(),'local'),loading=deferred(),engines=[];
  h.appWindow.RamblaLocalASR=class {
    constructor(options){this.options=options;this.running=false;engines.push(this);}
    async start(){await loading.promise;this.running=true;this.options.onStatus({state:'listening',message:'Ascolto'});}
    stop(){this.running=false;return Promise.resolve();}
    destroy(){this.running=false;return Promise.resolve();}
  };
  h.app.startSession();h.advance(4);await h.click('pauseButton');
  loading.resolve();await settle();
  assert.equal(h.app.active,false);
  assert.equal(h.el('speechRetry').hidden,true);
  assert.equal(engines.filter(e=>e.running).length,0,'The app stops even a delayed external start that resolves after cancellation.');
  h.click('resumeButton');await settle();
  assert.equal(engines.filter(e=>e.running).length,1);
  assert.equal(h.app.current.captureState,'active');
});

test('pausing during a pending local retry prevents the canceled retry from owning a new microphone', async () => {
  const h=harness(session(),'local'),destruction=deferred();
  const engines=fakeLocal(h,destruction);h.app.startSession();await settle();
  engines[0].options.onError({message:'Riattiva'});
  h.click('speechRetry');await settle();
  h.advance(4);await h.click('pauseButton');
  h.advance(30);h.click('resumeButton');destruction.resolve();await settle();
  assert.equal(engines.filter(e=>e.running).length,1);
  assert.equal(engines.filter(e=>e.running)[0],h.app.local);
  assert.equal(h.app.current.captureState,'active');
});

test('late wake-lock permission from a paused run cannot orphan the resumed session lock', async () => {
  const h=harness(),first=deferred(),second=deferred(),released=[];
  const requests=[first,second];
  h.navigator.wakeLock={request:()=>requests.shift().promise};
  const lock=name=>({release(){released.push(name);return Promise.resolve();},addEventListener(){}});
  h.app.startSession();await h.click('pauseButton');h.click('resumeButton');
  second.resolve(lock('current'));await settle();
  first.resolve(lock('stale'));await settle();
  await h.click('pauseButton');
  assert.deepEqual(released.sort(),['current','stale'],'Both native screen locks are released even when the old permission arrives last.');
});

test('an imported SRT can be assigned the destination frame rate and timecode', async () => {
  const h = harness();
  await h.app.importFile({ name: 'camera-29.97.srt', size: 80,
    text: async () => '1\n00:00:01,000 --> 00:00:03,000\nTesto\n' });
  h.app.openSettings();
  assert.equal(h.el('settingsFps').disabled, false, 'SRT does not carry a frame rate; the default must remain changeable.');
  assert.equal(h.el('settingsTC').disabled, false);
  h.el('settingsFps').value = '29.97df';
  h.el('settingsTC').value = '00:00:00;00';
  h.app.saveSettings({ preventDefault() {} });
  assert.equal(h.app.current.fps, '29.97df');
  assert.equal(h.app.current.startTC, '00:00:00;00');
});

test('a local microphone stopped by backpressure remains restartable while the session is active', async () => {
  const h = harness(session(), 'local');
  const instances = fakeLocal(h);
  h.app.startSession(); await settle();
  const events = instances[0].options;
  events.onError({ message: 'Microfono fermato: coda piena', code: 'backpressure' });
  events.onStatus({ state: 'processing', message: 'Elaboro la coda' });
  events.onStatus({ state: 'stopped', message: 'Microfono fermo. Coda elaborata.' });
  assert.equal(h.app.active, true);
  assert.equal(h.el('speechRetry').hidden, false, 'The final stopped status must not remove the only restart action.');
  assert.equal(h.el('speechRetry').disabled, false);
});

test('two rapid retry clicks never create an orphaned local microphone engine', async () => {
  const h = harness(session(), 'local');
  const destruction = deferred();
  const instances = fakeLocal(h, destruction);
  h.app.startSession(); await settle();
  instances[0].options.onError({ message: 'Riavvia', code: 'interrupted' });
  h.click('speechRetry'); h.click('speechRetry');
  destruction.resolve(); await settle();
  const running = instances.filter(instance => instance.running);
  assert.equal(running.length, 1, 'A retry must be single-flight even while the previous engine is being destroyed.');
  assert.equal(running[0], h.app.local, 'Every running microphone must remain owned by the app so Termina can stop it.');
});

test('a live marker receives matching transcription that arrives after the marker tap', () => {
  const s = session();
  const h = harness(s);
  h.app.startSession(); h.advance(10); h.app.mark('highlight');
  h.app.addSegment(s, { start: 2, end: 5, text: 'Momento importante', speaker: 'A' });
  assert.equal(s.markers.length, 1);
  assert.equal(s.markers[0].note, 'Momento importante');
  assert.deepEqual(Array.from(s.markers[0].segmentIds), [s.segments[0].id]);
});

test('a complete SRT cannot be downloaded before the final local transcription flush finishes', async () => {
  const s = session({ segments: [{ id: 'first', start: 1, end: 2, text: 'Prima frase', speaker: 'A' }] });
  const h = harness(s, 'local');
  fakeLocal(h);
  h.app.startSession(); await settle(); h.advance(5);
  const stop = deferred();
  h.app.local.stop = () => stop.promise;
  const ending = h.app.endSession();
  try {
    assert.equal(h.app.pendingFlush, true);
    h.app.openExport();
    if (h.el('exportDialog').open) h.app.exportKind('srt');
    assert.equal(h.downloads.length, 0, 'An export labeled complete must wait for pending final segments.');
  } finally {
    stop.resolve(); await ending;
  }
});

function fakeVoice(h) {
  const engines=[];
  h.appWindow.RamblaVoiceNote=class {
    constructor(options){this.options=options;this.destroyed=false;engines.push(this);}
    async start(){this.options.onStatus({state:'listening',message:'Detta la nota'});}
    async stop(){this.options.onStatus({state:'stopped',message:'Dettatura completata'});}
    async destroy(){this.destroyed=true;}
  };
  return engines;
}

test('voice notes reserve the original moment and persist words without adding them to the scene transcript', async()=>{
  const h=harness(session({clockSource:'phone'}));const engines=fakeVoice(h);
  h.app.startSession();h.advance(15);
  await h.click('voiceNoteButton');
  assert.equal(engines.length,1,'A voice-note engine starts from the dedicated button.');
  h.advance(20);
  engines[0].options.onText({text:'Buona reazione sul secondo attore',interim:''});
  h.el('voiceCategory').value='highlight';
  await h.click('voiceSave');
  const m=h.app.current.markers[0];
  assert.equal(m.start,5);assert.equal(m.end,15);
  assert.equal(m.note,'Buona reazione sul secondo attore');
  assert.equal(m.category,'highlight');assert.equal(m.autoNote,false);
  assert.equal(h.app.current.segments.length,0);
  assert.equal(engines[0].destroyed,true);
  const stored=JSON.parse(h.storage.get('rambla-log-v1')).sessions[0];
  assert.equal(stored.markers[0].note,m.note);
});

test('closing a voice note destroys its microphone and background preserves the confirmed marker text', async()=>{
  const h=harness();const engines=fakeVoice(h);h.app.startSession();h.advance(4);
  await h.click('voiceNoteButton');
  assert.equal(engines.length,1);
  engines[0].options.onText({text:'Controllare il fuoco sul primo piano',interim:''});
  await h.hide();await settle();
  assert.equal(h.app.current.captureState,'paused');
  assert.equal(engines[0].destroyed,true);
  assert.equal(h.app.current.markers[0].note,'Controllare il fuoco sul primo piano');
  assert.equal(h.el('voiceNoteDialog').open,false);
  engines[0].options.onText({text:'Risultato arrivato troppo tardi',interim:''});
  assert.equal(h.app.current.markers[0].note,'Controllare il fuoco sul primo piano');
});

test('voice notes wait for the continuous transcript microphone to drain before opening another', async()=>{
  const h=harness(session(),'local');const main=fakeLocal(h),voices=fakeVoice(h);
  h.app.startSession();await settle();h.advance(8);
  const drain=deferred();main[0].stop=()=>drain.promise;
  const opening=h.click('voiceNoteButton');
  assert.equal(voices.length,0);
  drain.resolve();await opening;
  assert.equal(voices.length,1);
  await h.click('voiceCancel');await settle();
  assert.equal(voices[0].destroyed,true);
  assert.equal(h.app.current.markers.length,0);
  assert.equal(h.app.active,true);
});

test('camera resync appends a forward-only anchor and old markers retain their timecode',async()=>{
  const h=harness();let scanner;
  h.appWindow.RamblaTimecodeCamera=class {
    constructor(options){this.options=options;scanner=this;}
    async start(){} async stop(){} setViewport(){} getROI(){return{x:.1,y:.4,width:.8,height:.2};}
  };
  h.app.startSession();h.advance(10);h.app.mark('keep');h.advance(20);
  const oldTC=Core.framesAt(h.app.current,h.app.current.markers[0].start);
  await h.app.openScanner();
  scanner.options.onReading({timecode:'01:00:32:00',frames:Core.parseTC('01:00:32:00','25'),capturedAt:30000,confidence:95,stable:true,readings:3});
  h.app.applyScan();
  assert.equal(h.app.current.startTC,'01:00:00:00');
  assert.equal(h.app.current.tcAnchors.length,1);
  assert.equal(Core.framesAt(h.app.current,h.app.current.markers[0].start),oldTC);
  h.advance(2);h.app.mark('check');
  assert.equal(h.app.current.markers[1].start,30,'New lookback does not straddle a re-sync boundary.');
  assert.equal(Core.formatTC(Core.framesAt(h.app.current,32),'25'),'01:00:34:00');
});

test('collapsed register counts update without opening the transcript',()=>{
  const h=harness();h.el('logDisclosure').open=false;
  h.app.startSession();h.advance(5);h.app.mark('keep');
  h.app.addSegment(h.app.current,{start:1,end:2,text:'Una frase',speaker:'A'});
  assert.equal(h.el('logMarkerCount').textContent,1);
  assert.equal(h.el('logNoteCount').textContent,1);
  assert.equal(h.el('logDisclosure').open,false);
});

test('canceling a note during the main microphone drain resumes continuous transcription afterward',async()=>{
  const h=harness(session(),'local'),main=fakeLocal(h),voices=fakeVoice(h),drain=deferred();
  h.app.startSession();await settle();h.advance(5);
  main[0].stop=()=>{main[0].running=false;return drain.promise;};
  const opening=h.click('voiceNoteButton'),cancel=h.click('voiceCancel');
  await settle();drain.resolve();await opening;await cancel;await settle();
  assert.equal(h.app.active,true);assert.equal(main.filter(x=>x.running).length,1);
  assert.equal(voices.length,0);assert.equal(h.app.current.markers.length,0);
});

test('local voice-note inference leaves Stop available and cannot restart or edit active capture',async()=>{
  const h=harness(session(),'local');fakeLocal(h);const voices=fakeVoice(h);
  h.app.startSession();await settle();h.advance(5);await h.click('voiceNoteButton');
  voices[0].options.onStatus({state:'processing',message:'Trascrivo audio. Il microfono resta attivo.'});
  assert.equal(h.el('voiceStop').hidden,false);
  assert.ok(h.el('voiceStart').hidden||h.el('voiceStart').disabled);
  assert.equal(h.el('voiceText').readOnly,true);
  await h.click('voiceStart');
  assert.equal(voices[0].destroyed,false);assert.equal(voices.length,1);
});

test('a late native microphone permission cannot overlap the dedicated voice-note microphone',async()=>{
  const h=harness(session(),'native'),runs=[],voices=fakeVoice(h);
  h.appWindow.SpeechRecognition=class{
    constructor(){this.running=false;this.aborts=0;runs.push(this);}
    start(){}stop(){throw Error('InvalidStateError');}
    abort(){this.aborts++;this.running=false;}
    grantPermission(){this.running=true;this.onstart();}
  };
  h.app.startSession();h.advance(5);await h.click('voiceNoteButton');runs[0].grantPermission();
  assert.equal(runs[0].running,false);assert.ok(runs[0].aborts>0);assert.equal(voices.length,1);
});

test('a pending restored microphone permission cannot keep a closed note or paused session locked',async()=>{
  const h=harness(session(),'local'),engines=[],permission=deferred();
  h.appWindow.RamblaLocalASR=class{
    constructor(options){this.options=options;engines.push(this);}
    async start(){if(engines.length>1)await permission.promise;this.options.onStatus({state:'listening',message:'Ascolto'});}
    stop(){return Promise.resolve();}destroy(){return Promise.resolve();}
  };
  fakeVoice(h);h.app.startSession();await settle();h.advance(5);await h.click('voiceNoteButton');
  let closed=false;const closing=h.click('voiceCancel');closing.then(()=>closed=true);
  await settle();await h.click('pauseButton');await settle();
  try{assert.equal(h.el('resumeButton').disabled,false);assert.equal(closed,true);}
  finally{permission.resolve();await closing;await settle();}
});


function sessionTarget(id,menu=false){
  const target=new Element();target.dataset[menu?'sessionMenu':'session']=id;
  target.closest=selector=>selector==='button'||(!menu&&selector==='[data-session]')||(menu&&selector==='[data-session-menu]')?target:null;
  return target;
}
function archiveClick(h,id,menu=false){
  const event={target:sessionTarget(id,menu),detail:1,preventDefault(){this.prevented=true;},stopImmediatePropagation(){this.stopped=true;}};
  h.dispatch('click',event);return event;
}
function submitRename(h,value){h.el('sessionRenameTitle').value=value;h.el('sessionRenameForm').onsubmit?.({preventDefault(){}});}

test('archive rename targets its session without switching or overwriting another session',()=>{
  const h=harness(),other=session({id:'archived',title:'Vecchia sessione',endedAt:1,markers:[{id:'m',start:1,end:2,note:'Conserva'}]});
  h.app.sessions.push(other);h.app.render();
  archiveClick(h,other.id,true);
  assert.equal(h.el('sessionActionsDialog').open,true);
  assert.equal(h.el('sessionActionsTitle').textContent,'Vecchia sessione');
  h.click('sessionRename');submitRename(h,'   ');
  assert.equal(other.title,'Vecchia sessione');assert.equal(h.el('sessionRenameError').hidden,false);
  submitRename(h,'  Riprese nuove  ');
  assert.equal(other.title,'Riprese nuove');assert.equal(h.app.current.id,'review-session');
  assert.equal(other.markers[0].note,'Conserva');
  assert.equal(JSON.parse(h.storage.get('rambla-log-v1')).sessions.find(s=>s.id===other.id).title,'Riprese nuove');
});

test('renaming the recording session preserves capture and its time reference',()=>{
  const h=harness();h.app.startSession();h.advance(10);const started=h.app.current.startedAt;
  archiveClick(h,h.app.current.id,true);h.click('sessionRename');submitRename(h,'Take 2');
  assert.equal(h.app.current.title,'Take 2');assert.equal(h.app.active,true);
  assert.equal(h.app.current.startedAt,started);assert.equal(h.app.current.captureState,'active');
});

test('archive deletion and undo leave another recording session selected and running',()=>{
  const h=harness(),other=session({id:'archived',title:'Da eliminare'});h.app.sessions.push(other);
  h.app.startSession();archiveClick(h,other.id,true);h.click('sessionDelete');
  assert.equal(h.app.sessions.some(s=>s.id===other.id),false);assert.equal(h.app.active,true);
  assert.equal(h.app.current.id,'review-session');
  h.el('toast').querySelector('button').onclick();
  assert.equal(h.app.sessions.find(s=>s.id===other.id),other);assert.equal(h.app.active,true);
  assert.equal(h.app.current.id,'review-session');
});

test('deleting a recording session is blocked even if an old action handler is invoked',()=>{
  const h=harness();h.app.startSession();archiveClick(h,h.app.current.id,true);
  assert.equal(h.el('sessionDelete').disabled,true);
  h.el('sessionDelete').onclick?.();
  assert.equal(h.app.sessions.length,1);assert.equal(h.app.active,true);
});

test('deletion cancellation preserves the archive and deleting its last session stays recoverable',()=>{
  const original=session(),h=harness(original);archiveClick(h,original.id,true);h.confirm(false);h.click('sessionDelete');
  assert.equal(h.app.sessions.length,1);assert.equal(h.app.current,original);
  h.confirm(true);archiveClick(h,original.id,true);h.click('sessionDelete');
  assert.equal(h.app.sessions.some(s=>s.id===original.id),false);assert.equal(h.app.sessions.length,1);
  assert.equal(h.app.current.startedAt,null);
  h.el('toast').querySelector('button').onclick();assert.equal(h.app.sessions.find(s=>s.id===original.id),original);
});

test('holding a session opens actions once and suppresses the following selection click',()=>{
  const h=harness();h.app.sessions.push(session({id:'other'}));
  const target=sessionTarget('other');h.dispatch('pointerdown',{target,pointerId:1,button:0,isPrimary:true,clientX:20,clientY:30});
  h.advance(.49);h.flushTimers();assert.notEqual(h.el('sessionActionsDialog').open,true);
  h.advance(.01);h.flushTimers();assert.equal(h.el('sessionActionsDialog').open,true);
  h.dispatch('pointerup',{pointerId:1});const click=archiveClick(h,'other');
  assert.equal(h.app.current.id,'review-session');assert.equal(click.prevented,true);
  h.el('sessionActionsDialog').close();h.dispatch('pointerdown',{target,pointerId:2,button:0,isPrimary:true,clientX:20,clientY:30});h.dispatch('pointerup',{pointerId:2});archiveClick(h,'other');
  assert.equal(h.app.current.id,'other','An ordinary next tap still selects the session.');
});

test('scrolling, dragging or canceling a session hold cannot open its actions later',()=>{
  for(const cancellation of ['pointermove','pointercancel','scroll']){
    const h=harness();const target=sessionTarget(h.app.current.id);
    h.dispatch('pointerdown',{target,pointerId:1,button:0,isPrimary:true,clientX:10,clientY:10});
    h.dispatch(cancellation,{target,pointerId:1,clientX:10,clientY:30});h.advance(1);h.flushTimers();
    assert.notEqual(h.el('sessionActionsDialog').open,true,cancellation);
  }
});

test('removed speaker controls are not required and editing old notes preserves their speaker',()=>{
  const s=session({speaker:'Giulia',speakers:['Giulia','Intervistatore'],segments:[{id:'old',start:1,end:2,text:'Testo',speaker:'Intervistatore'}]});
  const h=harness(s,'manual',{missingIds:['speakerSelect','settingsSpeakers','noteSpeaker']});
  h.app.openSettings();h.el('settingsTitle').value='Aggiornata';h.app.saveSettings({preventDefault(){}});
  assert.deepEqual(s.speakers,['Giulia','Intervistatore']);assert.equal(s.speaker,'Giulia');
  h.app.openNote('segment','old');h.el('noteText').value='Testo corretto';h.app.saveNote({preventDefault(){}});
  assert.equal(s.segments[0].speaker,'Intervistatore');assert.equal(s.segments[0].text,'Testo corretto');
  h.app.newSession();assert.equal(h.app.current.speaker,'Voce');assert.deepEqual(Array.from(h.app.current.speakers),['Voce']);
});

function updateResponse(build='222222222222'){
  return {ok:true,async json(){return {version:'1.3.0',build};}};
}

test('checking the current app build does not reload and re-enables its button',async()=>{
  const h=harness();h.setFetch(async()=>updateResponse('111111111111'));
  await h.click('updateAppButton');
  assert.equal(h.fetches.length,1);assert.equal(h.fetches[0][1].cache,'no-store');
  assert.match(h.fetches[0][0],/^\.\/version\.json\?check=\d+$/);
  assert.equal(h.navigations.length,0);assert.equal(h.el('updateAppButton').disabled,false);
  assert.match(h.el('toast').querySelector('span').textContent,/già aggiornata/i);
});

test('app update saves the paused session before navigating and preserves its URL context',async()=>{
  const h=harness();h.app.startSession();h.advance(8);h.app.mark('keep');await h.click('pauseButton');
  h.app.current.title='Riprese da conservare';const before=JSON.stringify(h.app.current);
  h.setFetch(async()=>updateResponse());await h.click('updateAppButton');
  assert.equal(h.navigations.length,1);
  const next=new URL(h.navigations[0].url);
  assert.equal(next.origin,'https://azza0101.github.io');assert.equal(next.pathname,'/rambla-log/');
  assert.equal(next.searchParams.get('v'),'222222222222');assert.equal(next.searchParams.get('existing'),'yes');assert.equal(next.hash,'#markers');
  const saved=JSON.parse(h.navigations[0].archive);
  assert.equal(JSON.stringify(saved.sessions[0]),before);assert.equal(saved.activeId,h.app.current.id);
  assert.equal(saved.sessions[0].captureState,'paused');assert.equal(saved.sessions[0].markers.length,1);
});

test('updating cannot pause or reload an active recording',async()=>{
  const h=harness();h.app.startSession();await h.click('updateAppButton');
  assert.equal(h.fetches.length,0);assert.equal(h.navigations.length,0);assert.equal(h.app.active,true);
  assert.match(h.el('toast').querySelector('span').textContent,/pausa/i);
});

test('starting capture while the update check is pending prevents its navigation',async()=>{
  const h=harness(),checking=deferred();h.setFetch(()=>checking.promise);
  const update=h.click('updateAppButton');assert.equal(h.fetches.length,1);h.app.startSession();checking.resolve(updateResponse());await update;
  assert.equal(h.app.active,true);assert.equal(h.navigations.length,0);assert.equal(h.el('updateAppButton').disabled,false);
});

test('offline, failed and malformed update checks keep the current app available',async()=>{
  for(const failure of ['offline','http','invalid-build','invalid-version','network']){
    const h=harness();
    if(failure==='offline')h.navigator.onLine=false;
    h.setFetch(async()=>{
      if(failure==='network')throw Error('Disconnected');
      if(failure==='http')return {ok:false};
      if(failure==='invalid-build')return updateResponse('../elsewhere');
      if(failure==='invalid-version')return {ok:true,async json(){return {version:'',build:'222222222222'};}};
      return updateResponse();
    });
    await h.click('updateAppButton');
    assert.equal(h.navigations.length,0,failure);assert.equal(h.el('updateAppButton').disabled,false,failure);
    assert.equal(h.app.current.id,'review-session',failure);
    assert.equal(h.fetches.length,failure==='offline'?0:1,failure);
  }
});

test('update must save successfully both before checking and immediately before navigation',async()=>{
  for(const timing of ['before-check','after-check']){
    const h=harness(),checking=deferred();h.setFetch(()=>checking.promise);
    if(timing==='before-check')h.failStorage();
    const update=h.click('updateAppButton');
    if(timing==='after-check')h.failStorage();
    checking.resolve(updateResponse());await update;
    assert.equal(h.navigations.length,0,timing);assert.equal(h.el('updateAppButton').disabled,false,timing);
    assert.equal(h.fetches.length,timing==='before-check'?0:1,timing);
    assert.equal(h.el('storageWarning').hidden,false);
    assert.match(h.el('toast').querySelector('span').textContent,/dati non sono salvati/);
  }
});

test('update checking is single-flight even after a render or direct repeat invocation',async()=>{
  const h=harness(),checking=deferred();h.setFetch(()=>checking.promise);
  const update=h.click('updateAppButton');h.app.render();
  assert.equal(h.el('updateAppButton').disabled,true);assert.equal(h.el('updateAppButton').attributes.get('aria-busy'),'true');
  await h.el('updateAppButton').onclick?.();assert.equal(h.fetches.length,1);
  checking.resolve(updateResponse('111111111111'));await update;
  assert.equal(h.el('updateAppButton').disabled,false);assert.equal(h.el('updateAppButton').attributes.get('aria-busy'),'false');
});

test('portable HTML and file pages do not expose app updates',async()=>{
  for(const portable of [true,false]){
    const h=harness();if(portable)h.appWindow.RAMBLA_PORTABLE=true;else h.location.protocol='file:';
    h.app.render();assert.equal(h.el('updateAppButton').hidden,true);
    await h.el('updateAppButton').onclick?.();assert.equal(h.fetches.length,0);assert.equal(h.navigations.length,0);
  }
});
