'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const file = path.join(__dirname, '../src/voice-note.js');
const tick = () => new Promise(resolve => setImmediate(resolve));

// Native recognition and the local audio/model engine are the external
// boundaries. The note's real accumulation, stop and cancellation code runs.
function harness({ native = true, local = true, nativeStarts = true, localStarts = true, cancelLocalDrain = true } = {}) {
  const recognizers = [], locals = [], texts = [], statuses = [], errors = [];
  const timers = new Map();
  let timerId = 0, now = 5000;
  class Recognition {
    constructor() { this.stops = 0; this.aborts = 0; recognizers.push(this); }
    start() { if (nativeStarts) queueMicrotask(() => this.onstart?.()); }
    stop() { this.stops++; }
    abort() { this.aborts++; }
    result(values) {
      const results = values.map(([transcript, isFinal]) => Object.assign([{ transcript }], { isFinal }));
      this.onresult?.({ resultIndex: 0, results });
    }
    end() { this.onend?.(); }
  }
  class Local {
    constructor(callbacks) { this.callbacks = callbacks; this.active = false; this.destroyed = false; this.stops = 0; locals.push(this); }
    start(options) {
      this.options = options;
      this.callbacks.onStatus?.({ state: 'loading', message: 'Carico il modello locale.' });
      return new Promise((resolve, reject) => {
        this.startTicket = { resolve, reject };
        if (localStarts) queueMicrotask(() => this.ready());
      });
    }
    ready() {
      this.active = true;
      this.callbacks.onStatus?.({ state: 'listening', message: 'Ascolto locale.' });
      this.startTicket?.resolve({ getTracks: () => [] });
    }
    segment(text) { this.callbacks.onSegment?.({ start: 0, end: 1, text }); }
    stop() {
      this.stops++;
      this.active = false;
      this.callbacks.onStatus?.({ state: 'processing', message: 'Elaboro la coda.' });
      return new Promise(resolve => { this.stopResolve = resolve; });
    }
    finishStop() {
      this.callbacks.onStatus?.({ state: 'stopped', message: 'Coda completa.' });
      this.stopResolve?.();
    }
    async destroy() {
      this.destroyed = true;
      this.active = false;
      if (cancelLocalDrain) this.stopResolve?.();
      this.callbacks.onStatus?.({ state: 'stopped', message: 'Motore chiuso.' });
    }
  }
  const context = {
    console, Error, Map, Promise, Date, queueMicrotask,
    performance: { now: () => now },
    setTimeout(fn, delay) { const id = ++timerId; timers.set(id, { fn, delay }); return id; },
    clearTimeout(id) { timers.delete(id); },
  };
  if (native) context.SpeechRecognition = Recognition;
  if (local) context.RamblaLocalASR = Local;
  context.window = context;
  assert.ok(fs.existsSync(file), 'The voice-note engine has not been written yet');
  vm.runInNewContext(fs.readFileSync(file, 'utf8'), context, { filename: file });
  const note = new context.RamblaVoiceNote({
    onText: value => texts.push({ ...value }),
    onStatus: value => statuses.push({ ...value }),
    onError: error => errors.push(error),
  });
  return {
    note, recognizers, locals, texts, statuses, errors,
    advance(ms) { now += ms; },
    timeout() {
      const entry = Array.from(timers.entries()).find(([, timer]) => timer.delay === 2500);
      assert.ok(entry, 'A native stop must have a bounded final-result wait');
      timers.delete(entry[0]);
      entry[1].fn();
    },
  };
}

test('the voice-note constructor is passive and is also available through CommonJS', async () => {
  const h = harness();
  assert.equal(typeof require(file), 'function');
  assert.equal(h.recognizers.length, 0);
  assert.equal(h.locals.length, 0);
  assert.equal(h.texts.length, 0);
  await h.note.destroy();
});

test('native notes accumulate final result indices once and replace interim text', async () => {
  const h = harness();
  await h.note.start({ mode: 'native', language: 'it-IT' });
  const recognition = h.recognizers[0];
  assert.equal(recognition.lang, 'it-IT');
  assert.equal(recognition.continuous, true);
  assert.equal(recognition.interimResults, true);
  recognition.result([['Prima frase.', true], ['una parola', false]]);
  assert.deepEqual(h.texts.at(-1), { text: 'Prima frase.', interim: 'una parola' });
  recognition.result([['Prima frase.', true], ['una parola corretta', false]]);
  assert.deepEqual(h.texts.at(-1), { text: 'Prima frase.', interim: 'una parola corretta' });
  recognition.result([['Prima frase.', true], ['Seconda frase.', true]]);
  recognition.result([['Prima frase.', true], ['Seconda frase.', true]]);
  assert.deepEqual(h.texts.at(-1), { text: 'Prima frase. Seconda frase.', interim: '' });
  await h.note.stop({ flush: false });
  await h.note.start({ mode: 'native', language: 'en-GB' });
  h.recognizers[1].result([['New note.', true]]);
  assert.deepEqual(h.texts.at(-1), { text: 'New note.', interim: '' });
  await h.note.destroy();
});

test('native stop waits for its last final result and onend before resolving', async () => {
  const h = harness();
  await h.note.start({ mode: 'native' });
  const recognition = h.recognizers[0];
  recognition.result([['Ultime parole', false]]);
  let finished = false;
  const stopping = h.note.stop({ flush: true });
  stopping.then(() => { finished = true; });
  assert.equal(h.note.stop({ flush: true }), stopping);
  await tick();
  assert.equal(finished, false);
  assert.equal(recognition.stops, 1);
  recognition.result([['Ultime parole confermate.', true]]);
  assert.equal(finished, false);
  recognition.end();
  const result = await stopping;
  assert.equal(result.text, 'Ultime parole confermate.');
  assert.equal(result.interim, '');
  assert.deepEqual(h.texts.at(-1), { text: 'Ultime parole confermate.', interim: '' });
  assert.equal(h.statuses.at(-1).state, 'stopped');
  assert.ok(recognition.aborts > 0, 'Cleanup releases the native recognizer after its final result');
  await h.note.destroy();
});

test('a native stop timeout releases capture and keeps only confirmed words', async () => {
  const h = harness();
  await h.note.start({ mode: 'native' });
  const recognition = h.recognizers[0];
  recognition.result([['Confermato.', true], ['provvisorio', false]]);
  const stopping = h.note.stop({ flush: true });
  h.timeout();
  const result = await stopping;
  assert.equal(result.text, 'Confermato.');
  assert.equal(result.interim, '');
  assert.deepEqual(h.texts.at(-1), { text: 'Confermato.', interim: '' });
  assert.ok(recognition.aborts > 0);
  await h.note.destroy();
});

test('closing a note cancels pending native permission and rejects every late callback', async () => {
  const h = harness({ nativeStarts: false });
  const starting = h.note.start({ mode: 'native' });
  const rejected = assert.rejects(starting, { name: 'AbortError' });
  const recognition = h.recognizers[0];
  const lateStart = recognition.onstart, lateResult = recognition.onresult, lateError = recognition.onerror;
  const stopping = h.note.stop({ flush: true });
  await h.note.destroy();
  await Promise.all([rejected, stopping]);
  const texts = h.texts.length, statuses = h.statuses.length, errors = h.errors.length;
  const aborted = recognition.aborts;
  lateStart();
  lateResult({ resultIndex: 0, results: [Object.assign([{ transcript: 'Non deve entrare.' }], { isFinal: true })] });
  lateError({ error: 'network' });
  assert.ok(recognition.aborts > aborted, 'A late permission grant must be aborted again');
  assert.equal(h.texts.length, texts);
  assert.equal(h.statuses.length, statuses);
  assert.equal(h.errors.length, errors);
});

test('unavailable native recognition reports an Italian error without starting a local model', async () => {
  const h = harness({ native: false });
  await assert.rejects(h.note.start({ mode: 'native' }), /browser|trascrizione.*disponib/i);
  assert.equal(h.locals.length, 0);
  assert.equal(h.errors.length, 1);
  assert.equal(h.statuses.at(-1).state, 'error');
  await h.note.destroy();
});

test('native permission denial rejects startup and reports the microphone problem once', async () => {
  const h = harness({ nativeStarts: false });
  const starting = h.note.start({ mode: 'native' });
  const rejected = assert.rejects(starting, /microfono|permess/i);
  h.recognizers[0].onerror({ error: 'not-allowed' });
  await rejected;
  assert.equal(h.errors.length, 1);
  assert.equal(h.statuses.at(-1).state, 'error');
  assert.ok(h.recognizers[0].aborts > 0);
  await h.note.destroy();
});

test('local notes drain the final chunk before destroying their engine or resolving stop', async () => {
  const h = harness();
  await h.note.start({ mode: 'local', language: 'it-IT' });
  const local = h.locals[0];
  h.advance(2000);
  assert.equal(local.options.getElapsed(), 2);
  local.segment('Prima frase.');
  let finished = false;
  const stopping = h.note.stop({ flush: true });
  stopping.then(() => { finished = true; });
  await tick();
  assert.equal(finished, false);
  assert.equal(local.active, false);
  assert.equal(local.destroyed, false);
  local.segment('Ultimo blocco.');
  local.finishStop();
  const result = await stopping;
  assert.equal(result.text, 'Prima frase. Ultimo blocco.');
  assert.deepEqual(h.texts.at(-1), { text: 'Prima frase. Ultimo blocco.', interim: '' });
  assert.equal(local.destroyed, true);
  assert.equal(h.statuses.at(-1).state, 'stopped');
  await h.note.destroy();
});

test('closing during a local permission request cannot resurrect capture or emit late words', async () => {
  const h = harness({ localStarts: false });
  const starting = h.note.start({ mode: 'local' });
  const rejected = assert.rejects(starting, { name: 'AbortError' });
  const local = h.locals[0];
  await h.note.destroy();
  await rejected;
  const texts = h.texts.length, statuses = h.statuses.length, errors = h.errors.length;
  local.ready();
  local.segment('Risultato dopo la chiusura.');
  local.callbacks.onError(new Error('Errore dopo la chiusura.'));
  await tick();
  assert.equal(local.active, false);
  assert.equal(h.texts.length, texts);
  assert.equal(h.statuses.length, statuses);
  assert.equal(h.errors.length, errors);
});

test('destroy resolves an already waiting local stop without depending on another model result', async () => {
  const h = harness({ cancelLocalDrain: false });
  await h.note.start({ mode: 'local' });
  h.locals[0].segment('Testo già acquisito.');
  const stopping = h.note.stop({ flush: true });
  await h.note.destroy();
  const result = await stopping;
  assert.equal(result.text, 'Testo già acquisito.');
  assert.equal(h.locals[0].active, false);
  assert.equal(h.locals[0].destroyed, true);
});
