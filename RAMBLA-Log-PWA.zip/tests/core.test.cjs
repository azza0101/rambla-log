'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const corePath = path.join(__dirname, '..', 'src', 'core.js');
function core() {
  assert.ok(fs.existsSync(corePath), 'The export/timecode implementation has not been written yet');
  return require(corePath);
}
function session(patch = {}) {
  return {
    id: 'session-1', title: 'Intervista perché', createdAt: '2026-10-26T10:00:00.000Z',
    startedAt: null, endedAt: null, duration: 12, fps: '25', startTC: '01:00:00:00',
    language: 'it-IT', lookback: 10, speaker: 'Speaker A', speakers: ['Speaker A', 'Speaker B'],
    segments: [
      { id: 's1', start: 1.25, end: 3.5, text: 'È una città viva.', speaker: 'Speaker A' },
      { id: 's2', start: 5, end: 7, text: 'Perché restare?\nPer le persone.', speaker: 'Speaker B' },
    ],
    markers: [{ id: 'm1', start: 2.4, end: 6.4, name: 'Buona frase', note: 'Da tenere', color: 'Blue', category: 'quote', segmentIds: ['s1'] }],
    isDemo: false,
    ...patch,
  };
}

test('the same core runs in a browser without CommonJS globals', () => {
  core();
  const context = { window: {} };
  vm.runInNewContext(fs.readFileSync(corePath, 'utf8'), context);
  assert.equal(context.window.RamblaCore.parseTC('01:00:00:00', '25'), 90000);
});

test('fractional rates use the exact NTSC ratio for elapsed seconds', () => {
  const c = core();
  for (const [id, frames] of [['23.976', 24000], ['29.97', 30000], ['29.97df', 30000], ['59.94', 60000], ['59.94df', 60000]]) {
    assert.equal(c.secondsToFrames(1001, id), frames, id);
    assert.equal(c.framesToSeconds(frames, id), 1001, id);
  }
  assert.throws(() => c.rateInfo('23.98'), /fps|frame|frequenza/i);
});

test('integer-rate timecodes retain the frame boundary and hour offset', () => {
  const c = core();
  for (const [id, firstSecond, hour] of [['24', 24, 86400], ['25', 25, 90000], ['30', 30, 108000], ['50', 50, 180000], ['60', 60, 216000]]) {
    assert.equal(c.parseTC('00:00:01:00', id), firstSecond);
    assert.equal(c.parseTC('01:00:00:00', id), hour);
    assert.equal(c.formatTC(firstSecond - 1, id), '00:00:00:' + String(firstSecond - 1).padStart(2, '0'));
  }
});

test('29.97 drop-frame skips labels at ordinary minutes but not every tenth minute', () => {
  const c = core();
  const vectors = [[1799, '00:00:59;29'], [1800, '00:01:00;02'], [17981, '00:09:59;29'], [17982, '00:10:00;00'], [107892, '01:00:00;00']];
  for (const [frames, tc] of vectors) {
    assert.equal(c.formatTC(frames, '29.97df'), tc);
    assert.equal(c.parseTC(tc, '29.97df'), frames);
  }
  assert.equal(c.parseTC('00:01:00:02', '29.97df'), 1800, 'EDL uses a colon with the FCM flag');
});

test('59.94 drop-frame skips four labels while retaining ten-minute boundaries', () => {
  const c = core();
  for (const [frames, tc] of [[3599, '00:00:59;59'], [3600, '00:01:00;04'], [35963, '00:09:59;59'], [35964, '00:10:00;00'], [215784, '01:00:00;00']]) {
    assert.equal(c.formatTC(frames, '59.94df'), tc);
    assert.equal(c.parseTC(tc, '59.94df'), frames);
  }
});

test('fractional NDF timecodes are frame labels, not wall-clock time', () => {
  const c = core();
  assert.equal(c.secondsToFrames(3600, '29.97'), 107892);
  assert.equal(c.formatTC(107892, '29.97'), '00:59:56:12');
  assert.equal(c.parseTC('00:59:56:12', '29.97'), 107892);
  assert.equal(c.secondsToFrames(-1, '25'), -25);
});

test('invalid or impossible timecodes are rejected instead of wrapped or clamped', () => {
  const c = core();
  for (const tc of ['24:00:00:00', '00:60:00:00', '00:00:60:00', '00:00:00:25', '-1:00:00:00', '1:00:00:00', '00:00:00;00', '00:00:00:00x']) {
    assert.throws(() => c.parseTC(tc, '25'), /timecode|fotogramm|frame/i, tc);
  }
  assert.throws(() => c.parseTC('00:01:00;00', '29.97df'), /drop|timecode/i);
  assert.throws(() => c.parseTC('00:01:00;03', '59.94df'), /drop|timecode/i);
  for (const n of [0.5, NaN, Infinity]) assert.throws(() => c.formatTC(n, '25'));
  assert.throws(() => c.secondsToFrames(Infinity, '25'));
});

test('timecode display wraps midnight in both directions for a camera timecode anchor', () => {
  const c = core();
  assert.equal(c.formatTC(2160000, '25'), '00:00:00:00');
  assert.equal(c.formatTC(-1, '25'), '23:59:59:24');
  assert.equal(c.formatTC(2589408, '29.97df'), '00:00:00;00');
  assert.equal(c.formatTC(-1, '29.97df'), '23:59:59;29');
});

test('SRT time formatting carries rounded milliseconds across second and minute boundaries', () => {
  const c = core();
  assert.equal(c.srtTime(0.9996), '00:00:01,000');
  assert.equal(c.srtTime(59.9996), '00:01:00,000');
  assert.equal(c.srtTime(3661.012), '01:01:01,012');
  assert.throws(() => c.srtTime(-0.01));
});

test('SRT import reads BOM, CRLF, UTF-8 text and multiline cues without losing text', () => {
  const c = core();
  const imported = c.parseSRT('\uFEFF1\r\n00:00:01,250 --> 00:00:03,500\r\nÈ una città viva.\r\n\r\n2\r\n00:00:05,000 --> 00:00:07,000\r\nPerché restare?\r\nPer le persone.\r\n');
  assert.deepEqual(imported, [
    { id: 'srt-1', start: 1.25, end: 3.5, text: 'È una città viva.', speaker: '' },
    { id: 'srt-2', start: 5, end: 7, text: 'Perché restare?\nPer le persone.', speaker: '' },
  ]);
});

test('SRT import preserves overlapping cues instead of silently deleting speech', () => {
  const c = core();
  const cues = c.parseSRT('1\n00:00:01,000 --> 00:00:03,000\nUno\n\n1\n00:00:02,000 --> 00:00:04,000\nDue\n');
  assert.equal(cues.length, 2);
  assert.notEqual(cues[0].id, cues[1].id);
  assert.equal(cues[1].start, 2);
});

test('malformed SRT fails with a useful error rather than returning a partial transcript', () => {
  const c = core();
  for (const value of ['', 'solo testo', '1\n00:60:00,000 --> 01:00:02,000\nA', '1\n00:00:03,000 --> 00:00:01,000\nA', '1\n00:00:01,000 --> 00:00:01,000\nA', '1\n00:00:01,000 --> 00:00:02,000', '1\n00:00:01,000 --> 00:00:02,000\nA\n\nBROKEN']) {
    assert.throws(() => c.parseSRT(value), /srt|sottotitol|cue/i);
  }
});

test('session validation preserves Unicode and duplicate times, drops unknown fields and does not mutate input', () => {
  const c = core();
  const raw = session({ duration: 1, unexpected: { anything: true } });
  raw.markers.push({ ...raw.markers[0], id: 'm2', color: 'ResolveColorCyan' });
  const before = JSON.stringify(raw);
  const clean = c.validateSession(JSON.parse(JSON.stringify(raw)));
  assert.equal(clean.title, 'Intervista perché');
  assert.equal(clean.duration, 7);
  assert.equal(clean.markers.length, 2);
  assert.equal(clean.markers[1].color, 'Cyan');
  assert.equal(Object.hasOwn(clean, 'unexpected'), false);
  assert.equal(JSON.stringify(raw), before);
  assert.notEqual(clean.segments, raw.segments);
});

test('session JSON import rejects malformed JSON, unsupported shapes and invalid ranges', () => {
  const c = core();
  assert.throws(() => c.validateSession('{"bad":'), /json/i);
  for (const raw of [null, [], {}, session({ fps: 'wrong' }), session({ duration: -1 }), session({ startTC: 'not TC' }), session({ markers: 'not an array' }), session({ segments: [{ id: 'x', start: 5, end: 1, text: 'A', speaker: '' }] }), session({ markers: [{ id: 'm', start: -1, end: 2, name: 'Bad' }] })]) {
    assert.throws(() => c.validateSession(raw));
  }
  const duplicate = session();
  duplicate.segments.push({ ...duplicate.segments[0] });
  assert.throws(() => c.validateSession(duplicate), /id|duplicat/i);
  assert.equal(c.validateSession(JSON.stringify(session())).id, 'session-1');
});

test('session validation keeps valid camera sync provenance and rejects impossible OCR metadata', () => {
  const c = core();
  const sync = { method: 'camera', timecode: '12:34:56:12', at: '2026-10-26T12:34:56.000Z', readings: 3, confidence: 92.5 };
  assert.deepEqual(c.validateSession(session({ sync })).sync, sync);
  assert.throws(() => c.validateSession(session({ sync: { ...sync, timecode: '12:34:56:99' } })));
});

test('legacy sessions retain their timecode reference and infer recoverable capture state', () => {
  const c=core();
  const legacy=c.validateSession(session());
  assert.equal(legacy.clockSource,'timecode');
  assert.equal(legacy.captureState,'draft');
  assert.equal(c.validateSession(session({startedAt:1000})).captureState,'active');
  assert.equal(c.validateSession(session({startedAt:1000,endedAt:2000})).captureState,'ended');
});

test('phone clock and paused-state metadata round-trip without losing the millisecond anchor', () => {
  const value=session({clockSource:'phone',phoneAnchorMs:1793008800875,startedAt:1793008800875,
    captureState:'paused',pauseReason:'background',pausedAt:1793008807875});
  const clean=core().validateSession(JSON.stringify(value));
  assert.equal(clean.clockSource,'phone');
  assert.equal(clean.phoneAnchorMs,1793008800875);
  assert.equal(clean.captureState,'paused');
  assert.equal(clean.pauseReason,'background');
  assert.equal(clean.pausedAt,1793008807875);
  assert.equal(clean.segments.length,2);
  assert.equal(clean.markers.length,1);
});

test('malformed clock or paused metadata cannot create an inconsistent recovered session', () => {
  const valid={clockSource:'phone',phoneAnchorMs:1000,startedAt:1000,captureState:'paused',pauseReason:'manual',pausedAt:2000};
  for(const patch of [{clockSource:'camera'}, {phoneAnchorMs:'tomorrow'}, {captureState:'recording'},
    {pauseReason:'unknown'}, {pausedAt:999}, {startedAt:null}, {endedAt:3000}]) {
    assert.throws(()=>core().validateSession(session({...valid,...patch})));
  }
});

test('EDL range markers use one-frame events and an independent duration in frames', () => {
  const result = core().makeEDL(session());
  assert.equal(result, 'TITLE: Intervista perché\nFCM: NON-DROP FRAME\n\n001  001      V     C        01:00:02:10 01:00:02:11 01:00:02:10 01:00:02:11\n[quote] Da tenere\n |C:ResolveColorBlue |M:Buona frase |D:100\n\n');
});

test('EDL alignment options change the timeline anchor without changing marker duration', () => {
  const result = core().makeEDL(session(), { timelineTC: '00:00:00:00', offsetSeconds: -1.4 });
  assert.match(result, /00:00:01:00 00:00:01:01 00:00:01:00 00:00:01:01/);
  assert.match(result, /\|D:100\n/);
});

test('EDL keeps coincident markers and exposes a warning rather than silently dropping a note', () => {
  const s = session();
  s.markers.push({ ...s.markers[0], id: 'm2', name: 'Seconda nota' });
  const result = core().makeEDL(s);
  assert.equal((result.match(/^\d+\s+001\s+V\s+C/gm) || []).length, 2);
  assert.match(result, /WARNING.*coincident/i);
  assert.match(result, /Seconda nota/);
});

test('EDL exports point markers with at least one frame of duration', () => {
  const s = session({ markers: [{ id: 'm0', start: 0, end: 0, name: 'Inizio', note: '', color: 'Green', category: '', segmentIds: [] }] });
  assert.match(core().makeEDL(s), /\|C:ResolveColorGreen \|M:Inizio \|D:1/);
});

test('EDL does not hide negative alignment or a timecode crossing the 24-hour limit', () => {
  const c = core();
  assert.throws(() => c.makeEDL(session(), { offsetSeconds: -3 }), /negativ|prima|zero/i);
  assert.throws(() => c.makeEDL(session(), { timelineTC: '23:59:58:00' }), /24|limite/i);
  assert.throws(() => c.makeEDL(session(), { offsetSeconds: Infinity }));
});

test('drop-frame EDL declares DROP FRAME and uses legal frame labels', () => {
  const s = session({ fps: '29.97df', startTC: '00:00:00;00', duration: 70, markers: [{ id: 'm', start: 60.06, end: 61.061, name: 'Minuto', note: '', color: 'Cyan', category: '', segmentIds: [] }] });
  const result = core().makeEDL(s);
  assert.match(result, /^FCM: DROP FRAME$/m);
  assert.match(result, /00:01:00:02 00:01:00:03 00:01:00:02 00:01:00:03/);
  assert.match(result, /\|D:30\n/);
});

test('EDL user text cannot create extra event or metadata lines', () => {
  const s = session({ title: 'Nome\nFCM: DROP FRAME' });
  s.markers[0].name = 'È buono |M:falso';
  s.markers[0].note = 'Riga uno\n001 001 V C |C:ResolveColorRed';
  const result = core().makeEDL(s);
  assert.equal((result.match(/^FCM:/gm) || []).length, 1);
  assert.equal((result.match(/^\d+\s+001\s+V\s+C/gm) || []).length, 1);
  assert.equal((result.match(/\|M:/g) || []).length, 1);
  assert.equal((result.match(/\|C:/g) || []).length, 1);
  assert.match(result, /È buono/);
});

test('SRT export keeps session-relative milliseconds and all original speech', () => {
  assert.equal(core().makeSRT(session()), '1\n00:00:01,250 --> 00:00:03,500\nÈ una città viva.\n\n2\n00:00:05,000 --> 00:00:07,000\nPerché restare?\nPer le persone.\n');
});

test('selected SRT includes only segments linked from markers without repeating shared segments', () => {
  const s = session();
  s.markers.push({ ...s.markers[0], id: 'm2' });
  const result = core().makeSRT(s, { selectedOnly: true });
  assert.equal(result, '1\n00:00:01,250 --> 00:00:03,500\nÈ una città viva.\n');
});

test('CSV includes the transcript and marker log, preserves Unicode and escapes spreadsheet formulas', () => {
  const s = session();
  s.markers[0].name = '=HYPERLINK("https://example.invalid","click")';
  s.markers[0].note = 'Dice "ciao", perché sì';
  const result = core().makeCSV(s);
  assert.match(result, /È una città viva\./);
  assert.match(result, /Dice ""ciao"", perché sì/);
  assert.match(result, /'=HYPERLINK/);
  assert.match(result, /marker/);
  assert.match(result, /segment/);
});

test('plain text export contains both transcript and marker notes, with relative timing', () => {
  const result = core().makeTXT(session());
  for (const fragment of ['Intervista perché', '25', '01:00:00:00', '00:00:01.250', 'Speaker A', 'È una città viva.', 'Buona frase', 'Da tenere']) assert.ok(result.includes(fragment), fragment);
});
