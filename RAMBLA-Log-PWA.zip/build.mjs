import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url));
const files={STYLE:'style.css',CORE:'core.js',LOCAL_ASR:'local-asr.js',TIMECODE_CAMERA:'timecode-camera.js',VOICE_NOTE:'voice-note.js',APP:'app.js'};
const fontRoot=path.join(root,'assets/fonts');
let fontCSS=await readFile(path.join(fontRoot,'fonts.css'),'utf8');
for(const font of ['space-grotesk-latin.woff2','unbounded-latin.woff2']){
  const data=await readFile(path.join(fontRoot,font));
  if(data.subarray(0,4).toString()!=='wOF2')throw Error(`Invalid WOFF2 font: ${font}`);
  fontCSS=fontCSS.replace(`url("${font}")`,`url("data:font/woff2;base64,${data.toString('base64')}")`);
}
if(/url\((?!["']?data:)/.test(fontCSS))throw Error('Font stylesheet contains an external font URL');
const fontLicenses=(await Promise.all(['FONT-SOURCES.txt','Space-Grotesk-OFL.txt','Unbounded-OFL.txt'].map(file=>readFile(path.join(fontRoot,file),'utf8')))).join('\n\n');
let html=await readFile(path.join(root,'src/index.html'),'utf8');
for(const [key,file] of Object.entries(files)){
  let text=await readFile(path.join(root,'src',file),'utf8');
  if(key==='STYLE')text=fontCSS+'\n'+text;
  html=html.replace(`/*__${key}__*/`,()=>text.replace(/<\/script/gi,'<\\/script'));
}
// Keep font attribution in the portable HTML as well as in the PWA package.
html=html.replace('</head>',()=>`<!--\nBundled font licenses\n${fontLicenses.replace(/-->/g,'-- >')}\n-->\n</head>`);
if(/\/\*__[A-Z_]+__\*\//.test(html))throw Error('Unreplaced template');
const hash=createHash('sha256').update(html).digest('hex').slice(0,12);
await mkdir(path.join(root,'dist'),{recursive:true});
await mkdir(path.join(root,'output'),{recursive:true});
for(const asset of ['icon.svg','icon-192.png','icon-512.png'])await copyFile(path.join(root,'assets',asset),path.join(root,'dist',asset));
await writeFile(path.join(root,'dist/index.html'),html);
const portable=html.replace('<head>','<head><script>window.RAMBLA_PORTABLE=true;</script>').replace(/<link rel="(?:manifest|apple-touch-icon|icon)"[^>]*>/g,'');
await writeFile(path.join(root,'dist/RAMBLA-Log.html'),portable);
await writeFile(path.join(root,'output/RAMBLA-Log.html'),portable);
await writeFile(path.join(root,'dist/manifest.webmanifest'),JSON.stringify({id:'./',name:'RAMBLA Log',short_name:'RAMBLA Log',description:'Orologio iPhone, timecode camera, trascrizioni e marker per Resolve.',lang:'it',start_url:'./',scope:'./',display:'standalone',background_color:'#0a0a0a',theme_color:'#0a0a0a',icons:[{src:'./icon-192.png',sizes:'192x192',type:'image/png',purpose:'any maskable'},{src:'./icon-512.png',sizes:'512x512',type:'image/png',purpose:'any maskable'}]},null,2));
await writeFile(path.join(root,'dist/FONT-LICENSES.txt'),fontLicenses);
await writeFile(path.join(root,'dist/sw.js'),`'use strict';
const CACHE='rambla-log-${hash}';
const ASSETS=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png','./icon.svg'];
// Let an installed update wait for the existing clients to close. Never force
// a controller change or reload while a recording session may still be open.
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS))));
self.addEventListener('activate',event=>event.waitUntil(Promise.all([caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('rambla-log-')&&k!==CACHE).map(k=>caches.delete(k)))),self.clients.claim()])));
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==self.location.origin)return;
 if(event.request.mode==='navigate')event.respondWith(fetch(event.request).then(response=>{if(response.ok&&response.headers.get('content-type')?.includes('text/html')){const clone=response.clone();caches.open(CACHE).then(c=>c.put('./index.html',clone));}return response;}).catch(()=>caches.match('./index.html')));
 else if(ASSETS.some(asset=>new URL(asset,self.registration.scope).href===url.href))event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request)));
});
`);
await copyFile(path.join(root,'LICENSE'),path.join(root,'dist/LICENSE.txt'));
console.log(JSON.stringify({built:true,bytes:Buffer.byteLength(html),version:hash,portable:'output/RAMBLA-Log.html'}));
