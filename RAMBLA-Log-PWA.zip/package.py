"""Package the built web app and editable source without private workspace files."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import shutil

ROOT = Path(__file__).resolve().parent
DIST = ROOT / "dist"
OUTPUT = ROOT / "output"
OUTPUT.mkdir(exist_ok=True)

guide = (ROOT / "README.md").read_text(encoding="utf-8")
(DIST / "LEGGIMI.txt").write_text(guide, encoding="utf-8")
(DIST / ".nojekyll").write_text("", encoding="utf-8")

runtime_names = {
    "index.html", "RAMBLA-Log.html", "manifest.webmanifest", "sw.js",
    "icon.svg", "icon-192.png", "icon-512.png", "LICENSE.txt", "LEGGIMI.txt",
    ".nojekyll", "FONT-LICENSES.txt", "version.json",
}
archive_path = OUTPUT / "RAMBLA-Log-PWA.zip"
with ZipFile(archive_path, "w", ZIP_DEFLATED) as bundle:
    for filename in sorted(runtime_names):
        file = DIST / filename
        if file.exists():
            bundle.write(file, filename)
    for folder in ("src", "assets", "tests", "docs"):
        for file in sorted((ROOT / folder).rglob("*")):
            if file.is_file() and not any(part.startswith(".") for part in file.relative_to(ROOT).parts):
                bundle.write(file, file.relative_to(ROOT))
    for filename in ("build.mjs", "package.py", "package.json", "README.md", "LICENSE"):
        bundle.write(ROOT / filename, filename)

shutil.copyfile(archive_path, DIST / archive_path.name)
with ZipFile(archive_path) as bundle:
    assert bundle.testzip() is None, "Archive CRC verification failed"
print(f"Packaged {archive_path.stat().st_size:,} bytes · {len(bundle.namelist())} files")
