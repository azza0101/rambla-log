# Verification — 2026-10-26

## Version 1.2

- Implemented behavior: the Registro starts closed and updates marker/note counts without opening. Voice-note capture reserves the selected or lookback interval at the tap, drains continuous transcription before taking microphone ownership, and stores editable text/category in a marker note. The note is exported in EDL; no audio file is created.
- Timecode updates append forward-only `tcAnchors`; the original `startTC` remains unchanged. Existing marker positions remain intact. EDL selects the anchor at each marker's start and preserves its duration across later corrections; relative SRT/CSV/TXT exports remain unchanged. FPS and the initial reference are locked after anchors exist. Core tests cover successive corrections, ranges crossing a correction, backup validation, midnight and export limits.
- OCR implementation and unit coverage: fixed 5.5:1 crop mapped to the visible camera source; one exposure slider, with verified hardware settings or real software pixel correction. Contrast/polarity normalization and adaptive threshold fallback use at most two passes on one capture, counting as one observation. Exactly eight valid digits are required. Advancing sequences need at least 3 readings at confidence ≥60, 4 at ≥50, or 5 at ≥40; separator-free readings also need 5. Frozen timecodes are rejected. Exposure/orientation changes discard in-flight results. Software correction explicitly cannot restore clipped whites.
- Real Tesseract browser benchmark: **10 synthetic cases; raw 8/10 exact, current production selection 9/10 exact, 0 accepted incorrect timecodes**. The seven-segment stress case remains rejected. A small/thin-character regression was reproduced and corrected, then the same fixtures were rerun. Evidence: `docs/ocr-benchmark-results.json`, `correctedRun.summary`. Raw and processed results use the same tolerant parser; this is an image-processing comparison, not an end-to-end comparison with 1.1. The production selection applies the current two-pass rule to measured OCR outputs. It does not test physical camera capture or multi-frame synchronization.
- Independent review reproduced four asynchronous application regressions and verified each RED→GREEN: canceling during the main microphone drain; Stop/retry/edit state during local note inference; a late native microphone permission overlapping dictation; and a pending restored microphone permission leaving a closed note or paused session locked. The focused application suite passed **27 tests** after those fixes.
- Final full suite: **119 passed, 0 failed**, exit 0. The final run includes all four independent review regressions.
- Browser UI: **390 × 664**, controls fit without page overflow and the register stays closed. **320 × 568 timecode**, body/scroll dimensions both320×568; all six pads (~95×71px), Nota/Nota vocale (145×44px), and the timecode action (~138×44px) fit. The marking panel measures249px with249px scroll content. The existing mode/speaker controls move into Settings only at widths≤620px/heights≤580px.
- Browser workflow: created a session, started manual logging, added a Highlight marker, opened the voice-note sheet with a fixed interval, handled the expected microphone denial in the HTTP preview, edited its text/category and saved. The closed register showed2markers/1note; saved marker text and unchanged interval were inspected in the DOM. Scanner dialog showed the fixed rectangle, one exposure control and explicit HTTPS guidance. These interactions do not verify physical dictation.
- Browser limitation: the remote UI controller stopped responding while checking disclosure interaction, then timed out on recovery. Expansion and the final published visual inspection were not completed; no claim of those checks is made. The disclosure uses native HTML details/summary. Deployment and file integrity are verified separately through GitHub and HTTP.
- Physical iPhone camera/microphone, standalone iOS PWA behavior and direct Resolve import remain unverified. Browser timings and synthetic OCR results are not iPhone performance or optical-accuracy measurements.

## Version 1.1

- Fresh full suite: 71 passed, 0 failed, including source migration, exact phone-clock milliseconds, fractional-rate wall time, pause/resume timeline gaps, synchronous background checkpoint, reload recovery, no periodic archive writes, late ASR finals, canceled local starts/retries, and stale wake-lock permissions.
- Independent read-only review: 46 focused core/app tests passed; 99 application DOM references found with no duplicate IDs. Legacy Svolta names and exact EDL positions preserved. Recovery copy corrected to match the close action. No blocking findings remained.
- Browser desktop: observed dark #0a0a0a canvas, Space Grotesk body, Unbounded 700 headings, and no horizontal overflow. Existing version-1 session with two markers and a note restored successfully.
- Browser mobile: 390 px and 320 px iframe viewports; new phone session, exact HH:MM:SS display, SCARTA marker, pause, reload, resume, and retained marker count verified. At 320 px, marker controls measure 90×84 CSS px and pause/stop 137×48 px; no horizontal overflow. Bright colors confirmed through rendered styles.
- Font assets: both WOFF2 signatures verified and included in the generated HTML; 22,320-byte Space Grotesk and 50,892-byte Unbounded. Both OFL licenses included. No external font fetch is required.
- Physical iPhone background audio and Resolve import remain outside this browser verification. The product explicitly pauses capture when hidden and preserves the time reference.

## Version 1.0 browser verification
- Desktop rendering inspected.
- 390 × 844 iframe viewport: mobile layout inspected, session created, name/FPS saved, manual logging started, retroactive marker created, note saved, session stopped, export dialog inspected.
- Tesseract 6.0.1 real worker/model: PASS. Recognized 01:00:00:00 / 01:00:01:13 / 01:00:03:11 from synthetic PNGs at advancing capture times, confidence88, exact input frames, stable only on third reading, worker resources released. No physical camera used.
- Whisper tiny q8 real worker/model: PASS on 11 s public HF WAV. Model loaded6.54s, inference4.41s, expected semantic fragments present, worker terminated. This is a cloud-browser measurement, not iPhone performance.
- A first Whisper QA attempt exposed unconditional CacheStorage use on HTTP: fixed to capability-check and rerun passed.
- Browser download-event instrumentation did not observe an event in a framed QA page; file contents and exports are covered by module tests. No claim of an iPhone file-sharing roundtrip.

## Independent review
Six reproduced application regressions fixed, RED→GREEN: past phrase end preserved; imported SRT FPS editable; local engine restart after backpressure; no duplicate retry microphone; delayed transcripts update live markers; exports wait for final flush.

## Not verified here
Physical iPhone camera/microphone and standalone PWA behavior, camera display readability, optical sync accuracy, direct DaVinci Resolve import, Unicode/collision behavior in Resolve, iOS native share sheet.
