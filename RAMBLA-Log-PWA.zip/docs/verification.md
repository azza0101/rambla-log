# Verification — 2026-10-26

## Version 1.1

- Fresh full suite: 71 passed, 0 failed, including source migration, exact phone-clock milliseconds, fractional-rate wall time, pause/resume timeline gaps, synchronous background checkpoint, reload recovery, no periodic archive writes, late ASR finals, canceled local starts/retries, and stale wake-lock permissions.
- Independent read-only review: 46 focused core/app tests passed; 99 application DOM references found with no duplicate IDs. Legacy Svolta names and exact EDL positions preserved. Recovery copy corrected to match the close action. No blocking findings remained.
- Browser desktop: observed dark #0a0a0a canvas, Space Grotesk body, Unbounded 700 headings, and no horizontal overflow. Existing version-1 session with two markers and a note restored successfully.
- Browser mobile: 390 px and 320 px iframe viewports; new phone session, exact HH:MM:SS display, SCARTA marker, pause, reload, resume, and retained marker count verified. At 320 px, marker controls measure 90×84 CSS px and pause/stop 137×48 px; no horizontal overflow. Bright colors confirmed through rendered styles.
- Font assets: both WOFF2 signatures verified and included in the generated HTML; 22,320-byte Space Grotesk and 50,892-byte Unbounded. Both OFL licenses included. No external font fetch is required.
- Physical iPhone background audio and Resolve import remain outside this browser verification. The product explicitly pauses capture when hidden and preserves the time reference.

## Version 1.0 browser verification
- Desktop rendering inspected.
- 390 × 844 iframe viewport: mobile layout inspected, session created, name/FPS saved, manual logging started, retroactive marker created, note saved, session stopped, export dialog inspected.
- Tesseract 6.0.1 real worker/model: PASS. Recognized 01:00:00:00 / 01:00:01:13 / 01:00:03:11 from synthetic PNGs at advancing capture times, confidence88, exact input frames, stable only on third reading, worker resources released. No physical camera used.
- Whisper tiny q8 real worker/model: PASS on 11 s public HF WAV. Model loaded6.54s, inference4.41s, expected semantic fragments present, worker terminated. This is a cloud-browser measurement, not iPhone performance.
- A first Whisper QA attempt exposed unconditional CacheStorage use on HTTP: fixed to capability-check and rerun passed.
- Browser download-event instrumentation did not observe an event in a framed QA page; file contents and exports are covered by module tests. No claim of an iPhone file-sharing roundtrip.

## Independent review
Six reproduced application regressions fixed, RED→GREEN: past phrase end preserved; imported SRT FPS editable; local engine restart after backpressure; no duplicate retry microphone; delayed transcripts update live markers; exports wait for final flush.

## Not verified here
Physical iPhone camera/microphone and standalone PWA behavior, camera display readability, optical sync accuracy, direct DaVinci Resolve import, Unicode/collision behavior in Resolve, iOS native share sheet.
