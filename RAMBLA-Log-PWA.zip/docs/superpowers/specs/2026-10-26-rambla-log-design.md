# RAMBLA Log — design

User request: a free iPhone alternative to the shown Earwig app, optionally an HTML web app, exporting files DaVinci Resolve can read.

Builder decisions: a buildless, mobile-first, Italian PWA with a downloadable single HTML and installable HTTPS version. No paid API, backend transcription, account-dependent processing or proprietary artwork. Sites provides the private HTTPS launch URL. All session data remain in browser storage; native speech can be processed by the OS provider and is explicitly described as such.

Core flow: configure session, FPS and initial camera timecode; start a continuous session clock; optionally transcribe speech with Safari recognition or local experimental Whisper; mark the previous 5/10/20 seconds with categories; select transcript lines for range markers; add/edit notes and speaker labels manually; finish and export Resolve marker EDL, SRT, CSV, JSON backup and text log. Allow importing SRT/JSON, retaining histories, and demonstration data that is explicitly labeled and separate from real sessions. Manual logging remains available without a microphone.

Timecode (user steering): read the camera display LIVE through the iPhone camera; FPS manual. Local Tesseract OCR runs on an adjustable ROI and requires at least three consistent advancing readings. Timestamp the frame capture before OCR; infer the current camera clock by adding processing elapsed time. Stop camera after optical lock and free-run on a monotonic phone clock. Permit rescanning while live; update session origin, not marker-relative positions. Never call this frame-accurate LTC/genlock. Display/camera buffering and later device drift remain. Static REC RUN timecodes cannot verify advancement; advise FREE RUN or resync each take. Session elapsed time is independent of delayed speech results. Manual initial TC remains available. Export offset is configurable; native speech timestamps are estimates.

Persistence: save every finalized change, detect write failures, validate imported data, export backups. Never silently resume microphone recording after reload; recovery offers continuing the original clock or finishing at last saved time. Offline local logging after successful PWA caching. Native transcription support varies on iOS; no promise of screen-off/background operation. Local Whisper is opt-in with disclosed download and device limits.

Visual direction: restrained warm off-white editorial interface, black large timecode, coral live status, six distinct marker colors. Mobile large touch targets and fixed bottom recording controls. Desktop two-column logger with a narrow settings/navigation rail. No branded Earwig visuals.

Alternatives considered by builder: native Swift app would need signing/distribution; paid cloud speech violates the free operating-cost goal; browser APIs plus optional client-side model fit the explicit HTML request. No pending design decision prevents implementation.

Verification: model-independent timecode/export tests, malformed input checks, responsive browser UI, persistent sessions, marker selection, downloads, offline service-worker scope. Actual microphone recognition on physical iPhone and direct Resolve import must be reported as not exercised here.
