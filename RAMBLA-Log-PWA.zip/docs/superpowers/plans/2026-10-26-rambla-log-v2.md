# RAMBLA Log 1.1

## Requested outcome

Update the existing public GitHub Pages app with a prominent iPhone clock source, SCARTA marker, pause/resume, immediate lightweight persistence, and the RAMBLA dark identity. The user has authorized autonomous implementation and publication to the existing repository.

## Decisions

- New sessions default to the phone clock, shown as HH:MM:SS. Existing sessions preserve their timecode origin. The source is selected before capture; optical synchronization remains available for timecode sessions.
- Pausing suspends capture, not the absolute time reference. Relative marker positions retain elapsed gaps so Resolve alignment remains meaningful after a break.
- Leaving the visible page checkpoints synchronously and pauses capture. Returning or reloading preserves the session and provides Resume. Background microphone continuity is not promised on iOS.
- Save confirmed phrases, markers, settings and lifecycle changes immediately. Avoid rewriting the full archive on every clock tick.
- Use RAMBLA's observed #0a0a0a dark canvas, near-white text, teal and lavender accents. Space Grotesk for body, Unbounded 700 for display text. Bundle the fonts for offline use.
- Keep the current local storage key and accept old JSON backups. No existing session data is reset during the update.

## Ownership and steps

- [x] Session state, core validation, timing, ASR transitions, regression tests — session_v2 agent.
- [x] Dark theme, font assets, PWA/icon build — brand_v2 agent.
- [x] HTML controls, help, integration and documentation — root.
- [x] Fresh full tests, responsive browser checks, pause/reload/resume/export review — root and independent reviewer.
- [ ] Build distribution and source ZIP; push with expected-head lease to azza0101/rambla-log; verify Pages deployment and live UI — root.

## Verification focus

Phone clock seconds and fractional origin; old-session migration; pauses and background gaps; stop while paused; reload recovery; native/local final-result and loading races; manual marker mode; no per-tick storage; narrow-screen controls; contrast, focus and real bundled fonts; valid export offsets.
