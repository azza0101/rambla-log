# RAMBLA Log Implementation Plan

> For agentic workers: use executing-plans; delegated modules have bounded ownership. This is work already authorized by the user's request, with builder-selected defaults.

**Goal:** deliver a free working iPhone logging web app plus portable HTML, with Resolve-compatible export.

**Architecture:** dependency-free core and UI; opt-in optional local speech module; statically published PWA; no application server.

**Tech Stack:** HTML, CSS, JavaScript, browser storage, native SpeechRecognition, optional Transformers.js WASM, Node built-in test runner.

**Spec:** docs/superpowers/specs/2026-10-26-rambla-log-design.md

## Global Constraints

- Italian interface, 25 fps default, no API keys or usage charges.
- Timecode offsets and accurate integer frames; explicit native timing estimates.
- Fail microphone gracefully, never fake recognition, preserve actual notes.
- Single HTML generated from source and packaged PWA; GitHub Pages HTTPS hosting as subsequently requested by the user.

## Review Focus

- Native STT unavailable or revoked mid-session: keep clock and markers usable, clear error.
- Reload during live session: mark interruption; never silently record again.
- Negative offsets, fractional frame rates, day rollover: validate or reject invalid exports.
- JSON/SRT import contains malformed values or HTML: validation, textContent, no execution.
- Mobile keyboard, small screen and file share cancellation: controls reachable and no data loss.

## Tasks

- [x] 1. Export/timecode module: meaningful timecode and EDL/SRT/CSV tests first; implement pure API under `src/core.js`; export meaningful output fixtures. Owner delegated.
- [x] 2. Optional local ASR module: implement `RamblaLocalASR` with load/start/stop/destroy and callback events, use actual audio PCM, never fabricate success. Owner delegated.
- [x] 3. UI/state: `src/app.js`, `src/style.css`, `src/index.html`; core handles numeric behavior, root handles user flow and storage validation.
- [x] 4. PWA/build: `build.mjs`, `dist/index.html`, `dist/sw.js`, manifest and icons, portable output. Root.
- [x] 5. Check modules, browser mobile flow, fix observed issues, independent code review, publish GitHub Pages and save downloadable bundle. Verified public app: https://azza0101.github.io/rambla-log/ (initial commit fb1a160f5c62174aae8d592a4d78571b714cd3fd).
